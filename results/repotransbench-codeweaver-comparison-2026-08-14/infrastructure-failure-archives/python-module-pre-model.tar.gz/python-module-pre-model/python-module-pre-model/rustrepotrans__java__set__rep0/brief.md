# RustRepoTrans incremental task: incubator-milagro-crypto:big::set

Implement exactly one missing Rust function in the immutable project scaffold:

```rust
pub fn set(&mut self, i: usize, x: Chunk)
```

The source-language function and the paper-provided dependency context are
under `source/`. First copy `scaffold/` to `pipeline/target`, then replace only
the explicit `panic!("RustRepoTrans translation required")` body. Preserve all
other target code and public interfaces.

## Hard constraints

- Never edit `source/` or `scaffold/`.
- Do not weaken, delete, skip, mock, or rewrite any tests.
- Do not recover or search for the withheld golden Rust body.
- Run the configured full-project build and test suite before claiming success.
