# RepoTransBench reconstruction: neural-dialogue-metrics/Distinct-N

Translate the complete Python repository under `source/` to Java. The immutable
`scaffold/` contains the released Maven build and fixed Java test contract but
contains no released Java implementation. First copy it to `pipeline/target`;
create the production Java sources there.

## Hard constraints

- Preserve the source repository's behavior; do not edit `source/`.
- Do not weaken, delete, skip, mock, or rewrite the fixed tests.
- Use the released Maven/JUnit contract exactly as supplied.
- Run the configured build and all fixed tests before claiming success.
- This is an auditable historical `v1.0` Python-to-Java task. Do not claim that
  it represents the paper's currently advertised 1,897-repository release.
