# ACToR absolute micro benchmark: printf

Translate the complete `printf.c` command-line utility under `source/` to a
safe, idiomatic Rust command-line program. Start by copying `scaffold/` to
`pipeline/target`. Preserve the executable name `printf` and the C program's
arguments, standard input/output/error, exit-status, file-system effects, and
program-name-dependent behavior.

The scaffold contains the paper artifact's 15 released
seed cases. A larger fixed differential contract is intentionally withheld and
will be applied independently after the run.

## Hard constraints

- Use safe Rust for all candidate-owned Rust source; do not use `unsafe`.
- Do not edit `source/` or `scaffold/`.
- Do not weaken, delete, skip, mock, or rewrite the released seed tests.
- Do not search for, reconstruct, or request withheld validation tests.
- Prefer the Rust standard library; preserve observable CLI behavior exactly.
- Run the configured release build and all released seed tests before success.
