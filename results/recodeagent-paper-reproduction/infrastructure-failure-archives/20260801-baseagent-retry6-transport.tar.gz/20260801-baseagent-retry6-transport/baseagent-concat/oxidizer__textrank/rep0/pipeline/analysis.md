# TextRank Go → Rust Translation Analysis

## 1. Source Project Research

### Overview
TextRank is a Go implementation of the TextRank algorithm for automatic text summarization and phrase extraction. The library provides:
- Phrase and word ranking based on graph-based algorithms
- Sentence extraction by various criteria (relation weight, word quantity, phrase chains)
- Multi-threaded support via goroutines
- Extensible architecture through interfaces (Algorithm, Language, Rule)
- Stop word filtering with default English support

The project is structured as a single Go package (`textrank`) with a simple command-line entry point that does nothing (just imports the package).

### Structure and Key Components

#### Core Data Structures
1. **TextRank** (`textrank.go`): Main wrapper struct containing a `Rank` object
   - Entry point for all operations
   - Provides high-level API methods

2. **Rank** (`rank.go`): Central data structure containing:
   - `Words`: map[int]*Word - all unique words with their metadata
   - `WordValID`: map[string]int - word token to ID lookup
   - `SentenceMap`: map[int]string - sentence ID to original text
   - `Relation`: Relation struct - phrase/connection graph
   - `Max`, `Min`: float32 - normalization bounds

3. **Word** (`rank.go`): Word metadata
   - `ID`, `Token`, `Qty`, `Weight`
   - `SentenceIDs`: []int - sentences containing this word
   - `ConnectionLeft`, `ConnectionRight`: map[int]int - adjacent words with occurrence counts

4. **Relation** (`relation.go`): Phrase graph
   - `Node`: map[int]map[int]Score - adjacency matrix for word pairs
   - `Max`, `Min`: float32 - normalization bounds
   - `Score`: struct with Qty, Weight, SentenceIDs

5. **Text** and **ParsedSentence** (`text.go`): Intermediate parsing structures
   - `Text`: container for parsed sentences
   - `ParsedSentence`: original sentence + tokenized words

#### Key Interfaces
1. **Algorithm** (`algorithm.go`): Pluggable ranking algorithms
   - `WeightingHits(wordID int, rank *Rank) float32`: word weight calculation
   - `WeightingRelation(word1ID, word2ID int, rank *Rank) float32`: phrase weight calculation
   - Implementations: `AlgorithmDefault` (simple occurrence), `AlgorithmChain` (combined with connections)

2. **Language** (`language.go`): Stop word filtering and stemming
   - `IsStopWord(word string) bool`
   - `FindRootWord(word string) (bool, string)`: stemming (stub in default impl)
   - `SetActiveLanguage(code string)`, `SetWords(code string, words []string)`
   - Implementation: `LanguageDefault` with English stop words

3. **Rule** (`rule.go`): Text parsing rules
   - `IsWordSeparator(rune rune) bool`
   - `IsSentenceSeparator(rune rune) bool`
   - Implementation: `RuleDefault` with hardcoded separators

#### Core Algorithms
1. **Tokenization** (`tokenizer.go`): `TokenizeText(rawText string, rule Rule) Text`
   - Splits text into sentences and words using Rule interface
   - Handles UTF-8 runes

2. **Building** (`builder.go`): `TextToRank(sentence ParsedSentence, lang Language, ranks *Rank)`
   - Converts parsed sentences into Rank graph
   - Filters stop words, builds word connections, updates relation graph

3. **Ranking** (`ranking.go`): `Calculate(ranks *Rank, algorithm Algorithm)`
   - Applies algorithm to compute weights
   - Normalizes weights to [0.0, 1.0] range

4. **Sorting/Finding** (`sorting.go`): Query functions
   - `FindPhrases(ranks *Rank) []Phrase`: sorted by weight
   - `FindSingleWords(ranks *Rank) []SingleWord`: sorted by weight
   - `FindSentences(ranks *Rank, kind int, limit int) []Sentence`: by relation or quantity
   - `FindSentencesByPhrases(ranks *Rank, words []string) []Sentence`: phrase chain search
   - `FindSentencesFrom(ranks *Rank, id int, limit int) []Sentence`: sequential extraction

#### Data Models
- **Phrase**: LeftID, RightID, Left, Right (tokens), Weight, Qty
- **SingleWord**: ID, Word, Weight, Qty
- **Sentence**: ID, Value (original text)

### Error Handling
The Go source has **no explicit error handling**. All operations assume valid input:
- No validation of empty strings, nil pointers, or out-of-bounds access
- Panics would occur on invalid map access or slice indexing
- The Rust port should maintain this behavior (panic on invalid input) for faithful translation

### Dependencies
- **Standard library**: `math`, `sort`, `strings`, `unicode/utf8`
- **Testing**: `github.com/stretchr/testify/assert` (test-only)
- **No runtime dependencies** beyond stdlib

### Unit Tests
The source includes 6 test files:
1. **textrank_test.go**: Main integration tests
   - `TestOnSingleThread`: Full pipeline with default and chain algorithms
   - `TestOnMultiThread`: Concurrent text addition via goroutines
   - Assertion helpers: `assertTheGnomeTestTextDefault`, `assertTheGnomeTestTextChain`

2. **algorithm_test.go**: Algorithm implementations
   - `TestWeightingRelation`: Tests both default and chain relation weighting
   - `TestWeightingHits`: Tests both default and chain hit weighting
   - Helper: `createRank()` builds a test graph

3. **tokenizer_test.go**: Tokenization
   - `TestTokenizeText`: Sentence splitting edge cases

4. **language_test.go**: Language/stop words
   - `TestLanguage`: Stop word detection and language switching

5. **rank_test.go**: Rank data structure
   - `TestGetWordData`: Word map access

6. **sorting_test.go**: Sorting/finding
   - `TestFindSentences`: Edge case with invalid kind parameter

**Mocking Strategy**: Tests use **direct construction** of test data (e.g., `createRank()` in algorithm_test.go). No external dependencies to mock. The multi-threaded test uses goroutines and channels but no mocks.

---

## 2. Third-Party Library Analysis

### Go Dependencies → Rust Equivalents

| Go Dependency | Purpose | Rust Equivalent | Notes |
|---------------|---------|-----------------|-------|
| `math` | `math.Abs` for float difference | `f32::abs()` | Built-in method |
| `sort` | `sort.Slice` for sorting | `Vec::sort_by` | Built-in method |
| `strings` | `strings.ToLower` | `str::to_lowercase()` | Built-in method |
| `unicode/utf8` | `utf8.RuneCountInString` | `str::chars().count()` | Built-in method |
| `github.com/stretchr/testify/assert` | Test assertions | Standard `assert!`, `assert_eq!` | Rust built-in macros |

**All Go stdlib dependencies map directly to Rust built-ins. No external crates needed for core functionality.**

### Scaffolding Provided
The `codeweaver.toml` specifies:
- `working_copy = "pipeline/target"`: Translation target directory
- Build command: `cargo build --manifest-path Cargo.toml`
- Test/validate command: `cargo test --manifest-path Cargo.toml`

**Assumption**: A `Cargo.toml` will be created in `pipeline/target/` with a library crate structure. No scaffolding is pre-provided; the Planner must create it.

---

## 3. Target Project Design

### Structural Mapping (Source → Target)

| Go File | Rust Module/File | Notes |
|---------|------------------|-------|
| `textrank.go` | `src/lib.rs` or `src/textrank.rs` | Main API, re-exports |
| `rank.go` | `src/rank.rs` | Rank, Word structs |
| `relation.go` | `src/relation.rs` | Relation, Score structs |
| `algorithm.go` | `src/algorithm.rs` | Algorithm trait + impls |
| `language.go` | `src/language.rs` | Language trait + impl |
| `rule.go` | `src/rule.rs` | Rule trait + impl |
| `tokenizer.go` | `src/tokenizer.rs` | TokenizeText function |
| `builder.go` | `src/builder.rs` | TextToRank function |
| `ranking.go` | `src/ranking.rs` | Calculate function |
| `sorting.go` | `src/sorting.rs` | Find* functions, Phrase/SingleWord/Sentence structs |
| `text.go` | `src/text.rs` | Text, ParsedSentence structs |
| `stop_word.go` | `src/stop_word.rs` | English stop words list |
| `examples.go` | `examples/` or `tests/` | Example code (optional) |
| `doc.go` | `src/lib.rs` doc comments | Package-level documentation |
| `cmd/main.go` | `src/bin/main.rs` or `examples/` | Minimal binary (optional) |
| `*_test.go` | `tests/*.rs` | Integration tests |

### Module Structure
```
pipeline/target/
├── Cargo.toml
├── src/
│   ├── lib.rs              # Public API, re-exports
│   ├── textrank.rs         # TextRank struct + high-level methods
│   ├── rank.rs             # Rank, Word
│   ├── relation.rs         # Relation, Score
│   ├── algorithm.rs        # Algorithm trait, AlgorithmDefault, AlgorithmChain
│   ├── language.rs         # Language trait, LanguageDefault
│   ├── rule.rs             # Rule trait, RuleDefault
│   ├── tokenizer.rs        # TokenizeText
│   ├── builder.rs          # TextToRank
│   ├── ranking.rs          # Calculate
│   ├── sorting.rs          # Phrase, SingleWord, Sentence, Find* functions
│   ├── text.rs             # Text, ParsedSentence
│   └── stop_word.rs        # get_default_english()
└── tests/
    ├── textrank_test.rs    # Integration tests
    ├── algorithm_test.rs
    ├── tokenizer_test.rs
    ├── language_test.rs
    ├── rank_test.rs
    └── sorting_test.rs
```

### Observable Contracts per Milestone

**M0: Skeleton** (compiles, no functional tests)
- All modules exist with stubbed functions
- Structs defined with correct fields
- Traits defined with method signatures
- `cargo build` succeeds

**M1: Core Data Structures**
- `Rank`, `Word`, `Relation`, `Score`, `Text`, `ParsedSentence` fully implemented
- `Rank::new()`, `Rank::add_new_word()`, `Rank::update_word()`, etc.
- `Relation::add_relation()` with graph logic
- Tests: `rank_test::test_get_word_data`

**M2: Tokenization & Parsing**
- `Rule` trait + `RuleDefault` implementation
- `TokenizeText` function
- `Text::append()`, `ParsedSentence` getters
- Tests: `tokenizer_test::test_tokenize_text`

**M3: Language & Stop Words**
- `Language` trait + `LanguageDefault` implementation
- `get_default_english()` stop word list
- `IsStopWord`, `SetActiveLanguage`, `SetWords`
- Tests: `language_test::test_language`

**M4: Builder (Graph Construction)**
- `TextToRank` function
- Integration with `Rank`, `Language`, `Rule`
- Word connection tracking

**M5: Algorithm Implementations**
- `Algorithm` trait
- `AlgorithmDefault::weighting_hits()`, `AlgorithmDefault::weighting_relation()`
- `AlgorithmChain::weighting_hits()`, `AlgorithmChain::weighting_relation()`
- Tests: `algorithm_test::test_weighting_relation`, `algorithm_test::test_weighting_hits`

**M6: Ranking & Normalization**
- `Calculate` function
- Weight computation and normalization
- Min/max tracking

**M7: Sorting & Finding**
- `FindPhrases`, `FindSingleWords`, `FindSentences`, `FindSentencesByPhrases`, `FindSentencesFrom`
- `Phrase`, `SingleWord`, `Sentence` structs
- Tests: `sorting_test::test_find_sentences`

**M8: TextRank API**
- `TextRank` struct with all public methods
- `Populate`, `Ranking`, `GetRankData`, `FindPhrases`, etc.

**M9: Full Integration**
- All tests pass: `textrank_test::test_on_single_thread`, `textrank_test::test_on_multi_thread`
- Full end-to-end validation

### Error Handling Strategy
**Match Go behavior**: No explicit error handling. Use `panic!` for invalid states (e.g., out-of-bounds access). Rust's type system (Option, Result) is NOT used unless necessary for idiomatic translation (e.g., HashMap lookups return Option).

### Boundary Strategy & Unit Test Seams
**No external boundaries** (no I/O, network, database). All logic is pure computation.

**Mockable seams** (for extensibility, not for tests):
- `Algorithm` trait: Allows custom ranking algorithms
- `Language` trait: Allows custom stop word lists
- `Rule` trait: Allows custom tokenization rules

**Unit test strategy**:
1. **Direct construction**: Tests build `Rank` objects directly (e.g., `createRank()` helper)
2. **No mocks needed**: All dependencies are in-memory data structures
3. **Concurrency tests**: Use Rust threads/channels (equivalent to goroutines)
4. **Assertions**: Use `assert_eq!`, `assert!` (Rust built-ins)

### Milestone Mapping

| Milestone | Goal | Tests (NEW selectors) |
|-----------|------|----------------------|
| M0 | Skeleton compiles | [] |
| M1 | Core data structures | `test_get_word_data` |
| M2 | Tokenization | `test_tokenize_text` |
| M3 | Language/stop words | `test_language` |
| M4 | Builder (graph construction) | (covered by integration) |
| M5 | Algorithm implementations | `test_weighting_relation`, `test_weighting_hits` |
| M6 | Ranking & normalization | (covered by integration) |
| M7 | Sorting & finding | `test_find_sentences` |
| M8 | TextRank API | (covered by integration) |
| M9 | Full integration | `test_on_single_thread`, `test_on_multi_thread` |

**Test selector format**: Rust uses `cargo test <test_name>` or `cargo test <module>::<test_name>`. Selectors will be function names like `test_on_single_thread`.

### Key Translation Considerations

1. **Ownership & Borrowing**:
   - Go uses pointers extensively (`*Rank`, `*Word`). Rust will use `&mut` for mutable references.
   - `Rank.Words` is `map[int]*Word` in Go. Rust: `HashMap<i32, Word>` (owned) or `HashMap<i32, Box<Word>>` if needed.

2. **Maps**:
   - Go: `map[int]string`, `map[string]int`, `map[int]map[int]Score`
   - Rust: `HashMap<i32, String>`, `HashMap<String, i32>`, `HashMap<i32, HashMap<i32, Score>>`

3. **Slices**:
   - Go: `[]int`, `[]string`, `[]Phrase`
   - Rust: `Vec<i32>`, `Vec<String>`, `Vec<Phrase>`

4. **Interfaces → Traits**:
   - Go interfaces are implicit. Rust traits are explicit.
   - `Algorithm`, `Language`, `Rule` become traits with `impl` blocks.

5. **Concurrency**:
   - Go: goroutines + channels
   - Rust: `std::thread::spawn` + `std::sync::mpsc::channel`
   - `TextRank` must be `Send + Sync` or wrapped in `Arc<Mutex<_>>`

6. **String handling**:
   - Go: `string` (immutable), `strings.ToLower`
   - Rust: `String` (owned), `&str` (borrowed), `to_lowercase()`

7. **Rune iteration**:
   - Go: `for j, chr := range rawText` iterates runes
   - Rust: `for chr in raw_text.chars()` or `char_indices()`

8. **Normalization**:
   - Go: `float32` arithmetic
   - Rust: `f32` arithmetic (same)

9. **Sorting**:
   - Go: `sort.Slice(phrases, func(i, j int) bool { ... })`
   - Rust: `phrases.sort_by(|a, b| b.weight.partial_cmp(&a.weight).unwrap())`

10. **Default values**:
    - Go: zero values (0, "", nil)
    - Rust: `Default` trait or explicit initialization

### Public API Surface
The Rust library will expose:
- `TextRank` struct with methods: `new()`, `populate()`, `ranking()`, `get_rank_data()`, `find_phrases()`, `find_single_words()`, `find_sentences_by_relation_weight()`, `find_sentences_by_word_qty_weight()`, `find_sentences_by_phrase_chain()`, `find_sentences_from()`
- Constructor functions: `new_default_rule()`, `new_default_language()`, `new_default_algorithm()`, `new_chain_algorithm()`
- Traits: `Algorithm`, `Language`, `Rule`
- Data types: `Phrase`, `SingleWord`, `Sentence`, `Rank`, `Word`, `Relation`, `Score`

All names will follow Rust conventions (snake_case for functions, PascalCase for types).

---

## Summary

This analysis covers:
1. **Source research**: 14 Go source files, 6 test files, core graph-based ranking algorithm with extensible interfaces
2. **Library analysis**: All Go stdlib dependencies map to Rust built-ins; no external crates needed
3. **Target design**: 11 Rust modules mirroring Go structure, 9 milestones from skeleton to full integration, trait-based extensibility, direct test construction (no mocks), faithful panic-on-error behavior

The translation is straightforward due to:
- No external dependencies
- Pure computational logic (no I/O)
- Clear module boundaries
- Well-defined interfaces → traits

Challenges:
- Ownership/borrowing for graph structures (nested HashMaps)
- Concurrency (Arc<Mutex<_>> for shared TextRank)
- Rune/char iteration differences
- Sorting with partial_cmp for f32
