# ReCodeAgent reproduction -- commons-fileupload (AlphaTrans)

This project is part of a reproduction of the ReCodeAgent paper (arXiv:2604.07341) benchmark suite, run through CodeWeaver. Translate **commons-fileupload** faithfully from Java to Python.

## Hard constraints
- Read the Java source under `source/` (read-only reference; do not edit it).
- Correctness is judged ONLY by the configured build/unit-test/validate commands against your own translation -- do not weaken, skip, or rewrite the oracle to make it pass.
- Do not fabricate a passing result: a milestone/parity claim must be backed by the actual command output.

## Scope
This is one project (`alphatrans__commons-fileupload`) of the reproduction's benchmark matrix; translate only this project's source tree.
