# Analysis Document: rhbloom C to Rust Translation

## 1. Source Project Research

### Overview
**rhbloom** is a Robin Hood Bloom Filter implementation in C that provides a space-efficient probabilistic data structure for membership testing. The key innovation is that it starts as a Robin Hood hash table and dynamically upgrades to a full Bloom filter when the hash table reaches a threshold size. This hybrid approach optimizes memory usage for smaller datasets while maintaining the space efficiency of Bloom filters for larger datasets.

**Core functionality:**
- Add 64-bit keys to the filter
- Test whether keys probably exist in the filter
- Dynamic growth from hash table to Bloom filter
- Clear filter without deallocating memory
- Query memory size and upgrade status

### Directory Structure and File Responsibilities

```
source/
├── rhbloom.h          # Public API header (8 functions)
├── rhbloom.c          # Core implementation (266 lines)
├── test.c             # Unit tests and benchmarks (205 lines)
├── makefile           # Build configuration
├── README.md          # Documentation
├── LICENSE            # MIT license
└── coverage_report.json
```

**rhbloom.h** - Public API header defining:
- `struct rhbloom` (opaque)
- Constructor: `rhbloom_new(size_t n, double p)` - create filter for n items with false positive rate p
- Constructor with allocator: `rhbloom_new_with_allocator(size_t n, double p, malloc_fn, free_fn)`
- Destructor: `rhbloom_free(struct rhbloom*)`
- Operations: `rhbloom_add()`, `rhbloom_test()`, `rhbloom_clear()`
- Queries: `rhbloom_memsize()`, `rhbloom_upgraded()`

**rhbloom.c** - Implementation with:
- `struct rhbloom` definition (lines 17-31) - internal state with allocator function pointers, Robin Hood hash table fields (count, nbuckets, buckets), and Bloom filter fields (k, m, bits)
- Macros for DIB/key packing (lines 34-36) - pack distance-from-ideal-bucket and 56-bit key into uint64
- `rhbloom_new_with_allocator()` (lines 38-72) - calculates optimal Bloom filter parameters (m bits, k hashes) using standard formulas, rounds m to power of 2
- `rhbloom_new()` (lines 77-79) - wrapper using standard malloc/free
- `rhbloom_free()` (lines 82-94) - deallocates bits, buckets, and struct
- `rhbloom_mix()` (lines 96-105) - mix13 hash function for key distribution
- `rhbloom_testadd()` (lines 107-133) - unified test/add for Bloom filter mode using k hash functions
- `rhbloom_grow()` (lines 137-175) - doubles hash table or upgrades to Bloom filter when threshold reached
- `rhbloom_addkey()` (lines 177-199) - Robin Hood insertion into hash table
- `rhbloom_add()` (lines 203-219) - public add: mixes key, checks for growth, delegates to addkey or testadd
- `rhbloom_test()` (lines 223-243) - public test: mixes key, delegates to testadd or hash table lookup
- `rhbloom_memsize()` (lines 246-250) - returns total memory usage
- `rhbloom_upgraded()` (lines 253-255) - returns true if using Bloom filter mode
- `rhbloom_clear()` (lines 258-265) - zeros bits or buckets without deallocation

**test.c** - Test suite with:
- `murmurhash2()` (lines 14-39) - hash function for test data generation
- `hash()` (lines 41-43) - wrapper converting int to uint64 hash
- `now()` (lines 45-49) - monotonic clock for benchmarking
- `commaize()` (lines 51-70) - format numbers with thousand separators
- `bench_print()` (lines 72-79) - print benchmark results
- `test_step()` (lines 81-114) - core test logic: adds n+1 items, verifies all present, tests n items not added, validates false positive rate within 10% of target
- `test()` (lines 116-129) - comprehensive test: sweeps n from 0 to 100,000 (step 1000) and p from 0.01 to 0.70 (step 0.05), tests each configuration twice (before and after clear)
- `bench()` (lines 131-196) - performance benchmark with configurable N and P
- `main()` (lines 198-205) - entry point dispatching to test or bench

### Key Structures and Interfaces

**struct rhbloom** (internal representation):
```c
struct rhbloom {
    void*(*malloc)(size_t);  // Custom allocator (or stdlib malloc)
    void(*free)(void*);      // Custom deallocator (or stdlib free)
    
    // Robin Hood hash table fields (active when bits == NULL)
    size_t count;            // Number of keys in hash table
    size_t nbuckets;         // Hash table capacity (power of 2)
    uint64_t *buckets;       // Hash table array
    
    // Bloom filter fields (active when bits != NULL)
    size_t k;                // Number of hash functions (bits per key)
    size_t m;                // Total bits in filter (power of 2)
    uint8_t *bits;           // Bit array
};
```

**DIB/Key Packing** - Each hash table bucket stores a 64-bit value:
- Upper 8 bits: DIB (distance from ideal bucket) - 0 means empty
- Lower 56 bits: Key value
- Macros: `RHBLOOM_KEY(x)`, `RHBLOOM_DIB(x)`, `RHBLOOM_SETKEYDIB(key, dib)`

**API Surface** (8 public functions):
1. `rhbloom_new(n, p)` - Create filter for n items with false positive rate p
2. `rhbloom_new_with_allocator(n, p, malloc, free)` - Create with custom allocator
3. `rhbloom_free(rhbloom)` - Deallocate filter
4. `rhbloom_add(rhbloom, key)` - Add key, returns false on OOM
5. `rhbloom_test(rhbloom, key)` - Test membership, returns true if probably present
6. `rhbloom_clear(rhbloom)` - Clear all entries without deallocation
7. `rhbloom_memsize(rhbloom)` - Get memory usage in bytes
8. `rhbloom_upgraded(rhbloom)` - Check if upgraded to Bloom filter mode

### Data Models and Observable Output Contract

**State Machine:**
1. **Empty state** - After construction: count=0, nbuckets=0, buckets=NULL, bits=NULL
2. **Hash table mode** - After first add: buckets allocated, bits=NULL, grows by doubling
3. **Bloom filter mode** - After upgrade: bits allocated, buckets=NULL (deallocated)

**Upgrade Condition:**
- Triggers when `nbuckets * 8 >= m >> 3` (hash table would exceed Bloom filter size)
- All existing keys are rehashed into the Bloom filter
- Hash table is deallocated

**Observable Behaviors:**
- `rhbloom_add()` returns true on success, false on OOM
- `rhbloom_test()` returns false for keys never added (no false negatives)
- `rhbloom_test()` may return true for keys not added (false positives at rate ≤ p)
- `rhbloom_upgraded()` returns false initially, true after upgrade (irreversible)
- `rhbloom_memsize()` returns `sizeof(struct rhbloom) + (bits ? m/8 : nbuckets*8)`
- `rhbloom_clear()` preserves allocated memory, resets to empty state in current mode

**Test Oracle Contract** (from test.c):
- For each (n, p) configuration where n ∈ [0, 100000] step 1000, p ∈ [0.01, 0.70] step 0.05:
  - Add n+1 keys (0 through n)
  - Before upgrade: each key must test positive immediately after add
  - After upgrade: all n+1 keys must test positive
  - Test n keys not added (n+1 through 2n+1): false positive rate must be within p ± 0.1
  - Clear and repeat the test
- Benchmark validates: add, test(yes), test(no) operations complete without assertion failures

### Error Handling

**Memory Allocation Failures:**
- `rhbloom_new_with_allocator()` returns NULL if malloc fails (line 60-62)
- `rhbloom_grow()` returns false if malloc fails (lines 144-146, 158-160)
- `rhbloom_add()` returns false if grow fails (line 212)
- All other operations assume valid non-NULL rhbloom pointer (no null checks)

**Invalid Input Handling:**
- Minimum n is clamped to 16 (line 41)
- No validation of p (caller must provide valid probability 0 < p < 1)
- No validation of key values (all uint64 values accepted)

**No Exceptions:** Pure C code, all errors communicated via return values (NULL or false).

### Dependencies

**Standard Library (libc):**
- `<stdlib.h>` - malloc, free, size_t
- `<stdbool.h>` - bool, true, false
- `<stdint.h>` - uint64_t, uint8_t, UINT64_C
- `<math.h>` - log, pow, round (for Bloom filter parameter calculation)
- `<string.h>` - memset (for clearing memory)
- `<stdio.h>` - printf, assert (test.c only)
- `<time.h>` - clock_gettime (test.c only)

**No External Dependencies:** The library is self-contained with no third-party dependencies.

### Unit Test Analysis

**Test Structure:**
- `test()` function runs comprehensive property-based tests
- `test_step()` is the core test harness validating:
  - No false negatives (every added key tests positive)
  - Upgrade happens (eventually transitions to Bloom filter mode)
  - All added keys remain testable after upgrade
  - False positive rate is within tolerance
- Tests run twice per configuration: initial run and after clear

**Mocking Strategy:**
- No mocking in source tests - they test the real implementation
- Custom allocator support (`rhbloom_new_with_allocator`) enables testing OOM scenarios
- Tests are deterministic (use murmurhash2 with fixed seed)

**Test Coverage:**
- Functional: add, test, clear, upgrade, memsize
- Edge cases: n=0, small n, large n, various p values
- State transitions: hash table → Bloom filter
- Persistence: clear preserves structure

**Benchmark Coverage:**
- Performance: add, test(yes), test(no) operations
- Validates false positive rate matches theory
- Measures memory usage

---

## 2. Third-Party Library Analysis

### C Standard Library → Rust Standard Library

**Memory Management:**
- **C:** `malloc()`, `free()` from `<stdlib.h>`
- **Rust:** Rust's ownership system with `Vec<T>` and `Box<T>`
- **Usage:** C code uses custom allocator function pointers for flexibility
- **Recommendation:** Use Rust's standard `Vec<u64>` and `Vec<u8>` for buckets and bits. The scaffold does not provide custom allocator support, so use standard Rust allocation.
- **Scaffold Status:** ✅ Provided - `Vec` is in std prelude

**Mathematical Functions:**
- **C:** `log()`, `pow()`, `round()` from `<math.h>`
- **Rust:** `f64::ln()`, `f64::powf()`, `f64::round()` from std
- **Usage:** Used in `rhbloom_new_with_allocator()` to calculate Bloom filter parameters (m and k)
- **Recommendation:** Use Rust's built-in f64 methods
- **Scaffold Status:** ✅ Provided - f64 methods are in std prelude

**Memory Operations:**
- **C:** `memset()` from `<string.h>`
- **Rust:** `Vec::clear()` + `Vec::resize()`, or `fill()` method
- **Usage:** Used in `rhbloom_clear()` and `rhbloom_grow()` to zero memory
- **Recommendation:** Use `vec.fill(0)` or `vec.clear()` + `vec.resize(n, 0)`
- **Scaffold Status:** ✅ Provided - Vec methods are in std prelude

**Integer Types:**
- **C:** `uint64_t`, `uint8_t`, `size_t` from `<stdint.h>`, `<stdlib.h>`
- **Rust:** `u64`, `u8`, `usize` from std
- **Usage:** Core data types throughout
- **Recommendation:** Direct mapping: uint64_t → u64, uint8_t → u8, size_t → usize
- **Scaffold Status:** ✅ Provided - primitive types

**Boolean Type:**
- **C:** `bool`, `true`, `false` from `<stdbool.h>`
- **Rust:** `bool`, `true`, `false` from std
- **Usage:** Return types for test/add operations
- **Recommendation:** Direct mapping
- **Scaffold Status:** ✅ Provided - bool is primitive

### Test Dependencies

**Hashing (murmurhash2):**
- **C:** Custom implementation in test.c
- **Rust:** Custom implementation in test.rs (already provided in scaffold)
- **Usage:** Generate deterministic test keys
- **Recommendation:** Use the provided implementation in scaffold/src/bin/test.rs
- **Scaffold Status:** ✅ Provided - murmurhash2 already implemented in test.rs

**Timing:**
- **C:** `clock_gettime(CLOCK_MONOTONIC)` from `<time.h>`
- **Rust:** `std::time::Instant`
- **Usage:** Benchmark timing
- **Recommendation:** Use `Instant::now()` and `elapsed()`
- **Scaffold Status:** ✅ Provided - test.rs already uses Instant

**Formatting:**
- **C:** `printf()`, `snprintf()` from `<stdio.h>`
- **Rust:** `println!()`, `format!()` macros
- **Usage:** Test output and benchmark results
- **Recommendation:** Use Rust's standard formatting macros
- **Scaffold Status:** ✅ Provided - test.rs already uses println!

### Summary: No New Dependencies Required

All functionality needed for the translation is available in Rust's standard library or already provided in the scaffold. The scaffold provides:
- ✅ `RHBloom` struct skeleton with correct fields
- ✅ Method signatures matching the C API
- ✅ Complete test harness in `src/bin/test.rs`
- ✅ All test utilities (murmurhash2, commaize, bench_print, etc.)

**No additional crates need to be added to Cargo.toml.**

---

## 3. Target Project Design

### Overview and Translation Requirements

**Functional Equivalence:**
The Rust port must reproduce the exact behavior of the C implementation as validated by the test oracle in `scaffold/src/bin/test.rs`. This includes:
- Identical Bloom filter parameter calculation (m, k values)
- Identical hash mixing algorithm (mix13)
- Identical Robin Hood hash table probing
- Identical upgrade threshold and behavior
- False positive rates within tolerance (p ± 0.1)

**Constraints from Project Brief:**
- ✅ Source code under `source/` is read-only reference
- ✅ Scaffold under `scaffold/` defines the public interface - DO NOT CHANGE
- ✅ Correctness judged by: `cargo test --manifest-path Cargo.toml`
- ✅ Implementation goes in `pipeline/target/` (working copy)

**Scaffold Interface Contract:**
The scaffold defines `RHBloom` struct and methods that must be implemented:
- `new(n: usize, p: f64) -> Self`
- `add(&mut self, key: u64) -> bool`
- `test(&self, key: u64) -> bool`
- `clear(&mut self)`
- `memsize(&self) -> usize`
- `upgraded(&self) -> bool`
- Helper methods: `mix(key: u64) -> u64`, `testadd(&mut self, key: u64, add: bool) -> bool`, `addkey(&mut self, key: u64) -> bool`, `grow(&mut self) -> bool`, `free(&mut self)`

### Source → Target Structural Mapping

**File Structure Mapping:**
```
source/rhbloom.h + rhbloom.c  →  scaffold/src/rhbloom.rs
source/test.c                  →  scaffold/src/bin/test.rs (already provided)
```

**Type Mappings:**
- `struct rhbloom` → `struct RHBloom`
- `size_t` → `usize`
- `uint64_t` → `u64`
- `uint8_t` → `u8`
- `double` → `f64`
- `bool` → `bool`
- `void*(*malloc)(size_t)` → (eliminated - use Vec)
- `void(*free)(void*)` → (eliminated - use Vec)

**Function Mappings:**
- `rhbloom_new(n, p)` → `RHBloom::new(n, p)`
- `rhbloom_new_with_allocator(...)` → (eliminated - not in scaffold)
- `rhbloom_free(rhbloom)` → `RHBloom::free(&mut self)` (or Drop trait)
- `rhbloom_add(rhbloom, key)` → `RHBloom::add(&mut self, key)`
- `rhbloom_test(rhbloom, key)` → `RHBloom::test(&self, key)`
- `rhbloom_clear(rhbloom)` → `RHBloom::clear(&mut self)`
- `rhbloom_memsize(rhbloom)` → `RHBloom::memsize(&self)`
- `rhbloom_upgraded(rhbloom)` → `RHBloom::upgraded(&self)`
- `rhbloom_mix(key)` → `RHBloom::mix(key)` (static method)
- `rhbloom_testadd(rhbloom, key, add)` → `RHBloom::testadd(&mut self, key, add)`
- `rhbloom_addkey(rhbloom, key)` → `RHBloom::addkey(&mut self, key)`
- `rhbloom_grow(rhbloom)` → `RHBloom::grow(&mut self)`

**Macro Mappings:**
- `RHBLOOM_KEY(x)` → inline expression `(x << 8) >> 8` or helper function
- `RHBLOOM_DIB(x)` → inline expression `(x >> 56) as usize` or helper function
- `RHBLOOM_SETKEYDIB(key, dib)` → inline expression `(key & 0x00FFFFFFFFFFFFFF) | ((dib as u64) << 56)` or helper function

**Idiom Mappings:**
- **Null pointers** → `Vec::is_empty()` or check `Vec::len() == 0`
  - C: `if (!rhbloom->bits)` → Rust: `if self.bits.is_empty()`
  - C: `if (!rhbloom->buckets)` → Rust: `if self.buckets.is_empty()`
- **Manual memory management** → Rust ownership with Vec
  - C: `malloc()` → Rust: `Vec::with_capacity()` or `vec![0; n]`
  - C: `free()` → Rust: automatic (Drop)
  - C: `memset(ptr, 0, size)` → Rust: `vec.fill(0)` or `vec.clear(); vec.resize(n, 0)`
- **Pointer arithmetic** → Rust indexing
  - C: `rhbloom->buckets[i]` → Rust: `self.buckets[i]`
  - C: `rhbloom->bits[j>>3] |= 1<<(j&7)` → Rust: `self.bits[j>>3] |= 1<<(j&7)`
- **Function pointers** → Eliminated (use standard Vec allocation)
- **Return NULL on error** → Return default/empty struct (or use Option/Result if needed)
  - C: `return 0;` (NULL) → Rust: `return Self { ... }` with empty vecs
  - C: `return false;` → Rust: `return false;`

### Module Structure for Target Project

```
pipeline/target/
├── Cargo.toml              # Package manifest (from scaffold)
├── Cargo.lock              # Dependency lock (from scaffold)
└── src/
    ├── lib.rs              # Library root: `pub mod rhbloom;`
    ├── rhbloom.rs          # RHBloom implementation (TRANSLATE HERE)
    └── bin/
        └── test.rs         # Test harness (from scaffold, DO NOT MODIFY)
```

**rhbloom.rs Structure:**
```rust
// Constants for DIB/key packing
const KEY_MASK: u64 = 0x00FFFFFFFFFFFFFF;
const DIB_SHIFT: u32 = 56;

// Helper functions for DIB/key manipulation
fn get_key(x: u64) -> u64 { ... }
fn get_dib(x: u64) -> usize { ... }
fn set_key_dib(key: u64, dib: usize) -> u64 { ... }

// Main struct
pub struct RHBloom {
    count: usize,
    nbuckets: usize,
    buckets: Vec<u64>,
    k: usize,
    m: usize,
    bits: Vec<u8>,
}

// Implementation
impl RHBloom {
    // Public API
    pub fn new(n: usize, p: f64) -> Self { ... }
    pub fn add(&mut self, key: u64) -> bool { ... }
    pub fn test(&self, key: u64) -> bool { ... }
    pub fn clear(&mut self) { ... }
    pub fn memsize(&self) -> usize { ... }
    pub fn upgraded(&self) -> bool { ... }
    pub fn free(&mut self) { ... }
    
    // Internal helpers
    pub fn mix(key: u64) -> u64 { ... }
    pub fn testadd(&mut self, key: u64, add: bool) -> bool { ... }
    pub fn addkey(&mut self, key: u64) -> bool { ... }
    pub fn grow(&mut self) -> bool { ... }
}
```

### Output/Contract Mapping

**Test Oracle Validation:**
The test harness in `scaffold/src/bin/test.rs` defines the contract:

1. **test() function** - Comprehensive property test:
   - Input: n ∈ [0, 100000] step 1000, p ∈ [0.01, 0.70] step 0.05
   - For each (n, p): create filter, run test_step, clear, run test_step again
   - Expected: all assertions pass, "PASSED" printed

2. **test_step() validation**:
   - Add n+1 keys (hash(0) through hash(n))
   - Before upgrade: `!upgraded() → !test(key)` before add, `test(key)` after add
   - After all adds: `upgraded() == true`
   - All n+1 added keys must test positive
   - Test n keys not added: false positive rate within p ± 0.1
   - Expected: no panics, all assertions pass

3. **bench() function** - Performance validation:
   - Add N keys, verify all test positive
   - Test N keys not added, count false positives
   - Clear and repeat
   - Expected: no assertion failures, reasonable false positive rate

**Observable Outputs:**
- `new(n, p)` creates filter with calculated m and k values
- `add(key)` returns true (or false on OOM, but tests don't expect OOM)
- `test(key)` returns true for added keys, false/true for non-added keys
- `upgraded()` returns false initially, true after upgrade
- `memsize()` returns struct size + vector sizes
- `clear()` resets to empty state in current mode

### Boundary and Error-Handling Strategy

**Memory Allocation:**
- C uses custom allocator function pointers
- Rust uses Vec which handles allocation automatically
- OOM in C returns NULL/false; in Rust, Vec allocation panics by default
- **Strategy:** Accept Rust's panic-on-OOM behavior (tests don't expect OOM handling)

**Null Pointer Checks:**
- C checks `if (!rhbloom->bits)` to determine mode
- Rust checks `if self.bits.is_empty()` or `self.bits.len() == 0`
- **Strategy:** Use `Vec::is_empty()` for mode detection

**Invalid Input:**
- C clamps n to minimum 16
- Rust should do the same: `let n = n.max(16);`
- **Strategy:** Replicate C's input validation exactly

**Error Propagation:**
- C returns false on allocation failure
- Rust can return false or panic
- **Strategy:** Match C's return values where possible; accept panics for OOM

**No Unsafe Code Needed:**
- All operations can be implemented with safe Rust
- Vec provides safe indexing and bounds checking
- Bit manipulation is safe with proper masking

### Unit Test Strategy

**Test Structure:**
The scaffold provides a complete test harness in `src/bin/test.rs` that mirrors the C test suite:
- `test()` function with `#[test]` attribute for `cargo test`
- `bench()` function for performance testing (run via `main()`)
- All test utilities already implemented (murmurhash2, hash, commaize, bench_print)

**Mockable Seams:**
No mocking required for this project:
- The implementation is self-contained with no external dependencies
- Tests use deterministic hashing (murmurhash2 with fixed seed)
- No I/O, network, or system calls to mock

**Test Execution:**
- Unit tests: `cargo test` runs the `test()` function
- Benchmarks: `cargo run --bin test bench [N] [P]` runs performance tests
- Both use the same `RHBloom` implementation

**Test Coverage Mapping:**

| C Test | Rust Test | Coverage |
|--------|-----------|----------|
| test() loops over n, p | test() loops over n, p | Functional correctness |
| test_step() validates add/test | test_step() validates add/test | Core operations |
| Checks !upgraded() before | Checks !upgraded() before | State transitions |
| Checks upgraded() after | Checks upgraded() after | Upgrade behavior |
| Validates false positive rate | Validates false positive rate | Probabilistic guarantees |
| Tests clear() | Tests clear() | Clear operation |
| bench() measures performance | bench() measures performance | Performance validation |

**No New Tests Required:**
The scaffold's test suite is complete and mirrors the C tests. Translation should focus on making the existing tests pass without modification.

### Milestone Mapping

The translation can be completed in a single milestone since the codebase is small and cohesive:

**Milestone 1: Complete RHBloom Implementation**

**Scope:** Implement all methods in `src/rhbloom.rs` to pass the full test suite.

**Components to translate:**
1. **Parameter calculation** (from `rhbloom_new_with_allocator`):
   - Calculate m (total bits) using formula: `m = n * ln(p) / ln(1 / 2^ln(2))`
   - Calculate k (hashes per key): `k = round((m/n) * ln(2))`
   - Round m up to power of 2
   - Adjust k proportionally

2. **Constructor** (`new`):
   - Implement parameter calculation
   - Initialize struct with empty vectors
   - Set k and m fields

3. **Hash mixing** (`mix`):
   - Implement mix13 algorithm exactly as in C
   - Three rounds of XOR-shift-multiply

4. **Bloom filter operations** (`testadd`):
   - Extract 56-bit key
   - Loop k times setting/testing bits
   - Use mix13 formula for subsequent hash values

5. **Robin Hood operations** (`addkey`):
   - Implement Robin Hood insertion with DIB swapping
   - Handle collisions by probing with wraparound

6. **Growth logic** (`grow`):
   - Check upgrade condition: `nbuckets * 8 >= m >> 3`
   - If upgrading: allocate bits, rehash all keys into Bloom filter
   - If growing: double buckets, rehash all keys into new table

7. **Public operations** (`add`, `test`):
   - Mix key with `mix()`
   - Delegate to appropriate mode (hash table or Bloom filter)
   - Handle growth trigger in `add()`

8. **Utility operations** (`clear`, `memsize`, `upgraded`, `free`):
   - `clear`: zero bits or buckets without deallocation
   - `memsize`: return struct size + vector capacities
   - `upgraded`: return `!bits.is_empty()`
   - `free`: clear vectors (or no-op, Drop handles it)

**Unit Tests Covered:**
- All tests in `src/bin/test.rs::test()` (comprehensive property tests)
- All assertions in `test_step()` (add, test, upgrade, clear)
- Benchmark validation in `bench()` (performance and correctness)

**Validation Command:**
```bash
cd pipeline/target && cargo test --manifest-path Cargo.toml
```

**Success Criteria:**
- All tests pass without modification to test.rs
- False positive rates within tolerance (p ± 0.1)
- No panics or assertion failures
- Output includes "PASSED" from test() function

**Implementation Order:**
1. Helper functions (get_key, get_dib, set_key_dib)
2. mix() - needed by all operations
3. new() - parameter calculation
4. testadd() - Bloom filter core
5. addkey() - hash table core
6. grow() - state transition
7. add() - public API orchestration
8. test() - public API query
9. clear(), memsize(), upgraded(), free() - utilities

This single milestone approach is appropriate because:
- The codebase is small (266 lines of C → ~300 lines of Rust)
- All components are tightly coupled (can't test add without grow, etc.)
- The test suite validates the complete system, not individual components
- No intermediate milestones are defined in the project configuration

---

## Summary

This analysis document provides the authoritative design for translating rhbloom from C to Rust:

**Section 1: Source Project Research** analyzed the C implementation, identifying:
- A hybrid Robin Hood hash table / Bloom filter with dynamic upgrade
- 8 public API functions and 5 internal helpers
- Comprehensive test suite with property-based testing across 1400 configurations
- No external dependencies beyond libc and libm

**Section 2: Third-Party Library Analysis** determined:
- All required functionality is in Rust's standard library
- The scaffold already provides complete test infrastructure
- No additional crates needed in Cargo.toml
- Direct mappings for all C standard library functions

**Section 3: Target Project Design** specified:
- One-to-one structural mapping preserving the C architecture
- RHBloom struct with Vec-based storage replacing manual allocation
- Complete method mapping from C functions to Rust methods
- Single milestone implementation strategy
- Validation via the provided test harness without modification

The translation should implement `src/rhbloom.rs` following this design, ensuring all tests in `src/bin/test.rs` pass without modification to the test file.
