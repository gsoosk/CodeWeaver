# Tisp C-to-Rust Port: Analysis Document

## 1. Source Project Research

### Overview

**Tisp** (Tiny Lisp) is a minimal, embeddable Lisp interpreter written in C. It implements a functional programming language with:
- Dynamic typing with first-class functions and macros
- Multiple numeric types (integers, decimals, rationals)
- S-expression syntax with syntactic sugar extensions
- A REPL and file execution modes
- Extensible library system (tib modules)

The interpreter follows a classic read-eval-print loop architecture with:
1. **Reader**: Parses text into internal AST (Val structures)
2. **Evaluator**: Executes the AST using environment-based variable resolution
3. **Printer**: Converts values back to readable text

### Directory Structure and File Responsibilities

```
source/
├── tisp.h              # Main header: type definitions, function declarations
├── tisp.c              # Core interpreter: reader, evaluator, printer, environment
├── main.c              # CLI entry point and REPL
├── test.c              # Unit test suite (613 lines, 527 test cases)
├── tibs_tsp.h          # Generated: embedded Tisp library code as C array
├── Makefile            # Build system
└── tib/                # Standard library modules (C primitives + Tisp code)
    ├── core.c          # Core primitives (car, cdr, cons, quote, eval, cond, etc.)
    ├── string.c        # String manipulation primitives
    ├── math.c          # Arithmetic and mathematical functions
    ├── io.c            # File I/O and printing primitives
    ├── os.c            # OS interaction (cd, pwd, system calls)
    ├── core.tsp        # Core Tisp library functions
    ├── list.tsp        # List manipulation functions
    ├── math.tsp        # Mathematical utilities
    ├── io.tsp          # I/O utilities
    ├── os.tsp          # OS utilities
    └── doc.tsp         # Documentation utilities
```

### Key Structures and Interfaces

#### Core Data Types (tisp.h)

**TspType enum** (bitflags):
- `TSP_NONE` (void), `TSP_NIL` (false/empty list)
- `TSP_INT`, `TSP_DEC`, `TSP_RATIO` (numeric types)
- `TSP_STR`, `TSP_SYM` (strings and symbols)
- `TSP_PRIM`, `TSP_FORM` (C-implemented functions/special forms)
- `TSP_FUNC`, `TSP_MACRO` (Tisp-implemented procedures)
- `TSP_PAIR` (cons cells, building block of lists)
- `TSP_REC` (records/hash tables)

**Val struct** (tagged union):
```c
struct Val {
    TspType t;
    union {
        char *s;                                           // STRING, SYMBOL
        struct { double num, den; } n;                     // NUMBER
        struct { char *name; Prim pr; } pr;                // PRIMITIVE, FORM
        struct { char *name; Val args, body; Rec env; } f; // FUNCTION, MACRO
        struct { Val car, cdr; } p;                        // PAIR
        Rec r;                                             // REC
    } v;
};
```

**Rec struct** (hash table with chaining):
```c
struct Rec {
    int size, cap;
    struct Entry {
        char *key;
        Val val;
    } *items;
    struct Rec *next;  // For environment chaining
};
```

**Tsp struct** (interpreter state):
```c
struct Tsp {
    char *file;        // Current input string
    size_t filec;      // Current position in file
    Val none, nil, t;  // Singleton values
    Rec env, strs, syms; // Global environment and interned strings/symbols
    void **libh;       // Dynamic library handles
    size_t libhc;
};
```

#### API Surface

**Constructor functions** (mk_* family):
- `mk_int(int)`, `mk_dec(double)`, `mk_rat(int, int)` - numeric values
- `mk_str(Tsp, char*)`, `mk_sym(Tsp, char*)` - interned strings/symbols
- `mk_pair(Val, Val)` - cons cells
- `mk_list(Tsp, int, ...)` - variadic list constructor
- `mk_prim(TspType, Prim, char*)` - primitive functions
- `mk_func(TspType, char*, Val, Val, Rec)` - user-defined functions/macros
- `mk_rec(Tsp, Rec, Val)` - records

**Reader functions**:
- `tisp_read(Tsp)` - read one complete expression
- `tisp_read_sexpr(Tsp)` - read S-expression
- `tisp_read_sugar(Tsp, Val)` - parse syntactic sugar
- `tisp_read_line(Tsp, int)` - read indented line
- `read_pair(Tsp, char)` - read list until delimiter

**Evaluator functions**:
- `tisp_eval(Tsp, Rec, Val)` - evaluate expression in environment
- `tisp_eval_list(Tsp, Rec, Val)` - evaluate each element of list
- `tisp_eval_body(Tsp, Rec, Val)` - evaluate sequence, return last (tail-call optimized)
- `eval_proc(Tsp, Rec, Val, Val)` - apply procedure to arguments

**Printer**:
- `tisp_print(FILE*, Val)` - print value to file

**Environment management**:
- `tisp_env_init(size_t)` - create new interpreter state
- `tisp_env_add(Tsp, char*, Val)` - add global binding
- `tisp_env_lib(Tsp, char*)` - load embedded library code
- `rec_new(size_t, Rec)`, `rec_add(Rec, char*, Val)`, `rec_get(Rec, char*)` - record operations
- `rec_extend(Rec, Val, Val)` - create new environment frame

**Utility functions**:
- `tsp_type_str(TspType)` - type name for error messages
- `tsp_lstlen(Val)` - list length (negative for improper lists)
- `vals_eq(Val, Val)` - structural equality
- `frac_reduce(int*, int*)` - simplify rational numbers
- `hash(char*)` - string hashing for records

### Data Models and Observable Output

**Input**: Tisp source code (text)
**Output**: Printed representation of evaluated values

**Value printing format** (tisp_print):
- Integers: `"42"`, `"-7"`
- Decimals: `"3.14"`, `"1.0"` (always includes decimal point)
- Rationals: `"3/4"`, `"-1/2"` (reduced form)
- Strings: raw text (no quotes in output)
- Symbols: raw text
- Nil: `"Nil"`
- Void: `"Void"`
- Pairs/Lists: `"(1 2 3)"`, `"(1 . 2)"` (improper list notation)
- Functions: `"#<function:name>"` or `"#<function>"`
- Primitives: `"#<primitive:name>"`
- Records: `"{ key: value ... }"`

**Error handling**: Errors print to stderr with format `"; tisp: error: <message>\n"` and return NULL from functions.

### Error Handling

The C implementation uses **macros for error reporting**:
- `tsp_warn(M)` / `tsp_warnf(M, ...)` - print error to stderr and return NULL
- `tsp_arg_num(ARGS, NAME, NARGS)` - validate exact argument count
- `tsp_arg_min(ARGS, NAME, NARGS)` - validate minimum argument count
- `tsp_arg_max(ARGS, NAME, NARGS)` - validate maximum argument count
- `tsp_arg_type(ARG, NAME, TYPE)` - validate argument type

Error propagation: Functions return `NULL` on error, which propagates up the call stack. The evaluator checks for NULL after each operation.

### Dependencies

**C Standard Library**:
- `stdio.h` - I/O operations
- `stdlib.h` - Memory allocation, exit
- `string.h` - String manipulation
- `ctype.h` - Character classification
- `stdarg.h` - Variadic functions
- `stdint.h` - Fixed-width integers
- `math.h` - Mathematical functions (in tib/math.c)
- `time.h` - Timing (in test.c and tib/os.c)
- `unistd.h` - POSIX functions (chdir, getcwd, read, write)
- `fcntl.h` - File control (in tib/io.c)
- `dlfcn.h` - Dynamic loading (in tib/io.c)
- `limits.h` - System limits (PATH_MAX)
- `signal.h` - Signal handling (in main.c)
- `libgen.h` - Path manipulation (in main.c)
- `assert.h` - Assertions (in test.c and tib/math.c)

**No external dependencies** - the project is self-contained.

### Unit Test Strategy in Source

**test.c** implements a comprehensive test suite:
- 527 test cases organized into 40+ sections
- Each test: `{input_string, expected_output_string}`
- Test runner: `tisp_test(Tsp, input, expect, output)` reads, evaluates, prints to file, compares output
- Sections: self-evaluating values, comments, whitespace, quote, cons/car/cdr, eval, cond, equality, def, functions, control flow, logic, lists, quasiquote, stack operations, numbers, arithmetic, comparison, etc.
- Tests validate both correctness and output format
- No mocking - tests run against the full interpreter

**Test execution**:
1. Initialize interpreter with `tisp_env_init(1024)`
2. Load standard libraries: `tib_env_core`, `tib_env_math`, `tib_env_string`, `tisp_env_lib(tibs)`
3. For each test: read input, eval, print to temp file, compare with expected
4. Report: `correct/total` per section and overall

**Key test patterns**:
- Self-evaluation: numbers, strings, booleans
- Primitives: car, cdr, cons, quote, eval, cond, =
- Functions: def, Func, apply, map
- Arithmetic: +, -, *, /, mod with mixed types
- Type conversions: Int, Dec, numerator, denominator
- List operations: length, nth, head, tail, reverse, append
- Higher-order: map, filter, compose

---

## 2. Third-Party Library Analysis

### C Standard Library Usage

**Memory Management** (`stdlib.h`):
- `malloc`, `calloc`, `realloc`, `free` - manual memory management
- **Rust equivalent**: `Box`, `Vec`, `String` (automatic memory management)
- **Scaffolding**: Not provided - translator must use Rust's ownership system

**String Handling** (`string.h`):
- `strlen`, `strcmp`, `strncmp`, `strcpy`, `strcat`, `strspn`, `strcspn`, `strchr`
- **Rust equivalent**: `String`, `&str` methods (`.len()`, `.eq()`, `.starts_with()`, etc.)
- **Scaffolding**: Not provided - use Rust's built-in string types

**I/O** (`stdio.h`):
- `FILE*`, `fopen`, `fclose`, `fread`, `fwrite`, `fprintf`, `fputs`, `fflush`, `perror`
- **Rust equivalent**: `std::fs::File`, `std::io::{Read, Write, BufReader, BufWriter}`
- **Scaffolding**: Partially provided - `tisp_print` signature uses `&mut std::fs::File`

**Character Classification** (`ctype.h`):
- `isdigit`, `tolower`, `isalpha`
- **Rust equivalent**: `char::is_ascii_digit()`, `char::to_ascii_lowercase()`, `char::is_alphabetic()`
- **Scaffolding**: Not provided - use Rust's char methods

**Math** (`math.h`):
- `abs`, `fabs`, `sqrt`, `pow`, `exp`, `log`, `sin`, `cos`, `tan`, `floor`, `ceil`, `round`
- **Rust equivalent**: `i32::abs()`, `f64::abs()`, `f64::sqrt()`, `f64::powf()`, etc.
- **Scaffolding**: Not provided - use Rust's numeric methods

**POSIX** (`unistd.h`, `fcntl.h`):
- `chdir`, `getcwd`, `read`, `write`, `open`, `close`
- **Rust equivalent**: `std::env::set_current_dir()`, `std::env::current_dir()`, `std::fs::File` methods
- **Scaffolding**: Not provided - use Rust's std library

**Dynamic Loading** (`dlfcn.h`):
- `dlopen`, `dlsym`, `dlclose`
- **Rust equivalent**: `libloading` crate (external dependency)
- **Scaffolding**: Not provided - may need to add dependency or stub out

**Signal Handling** (`signal.h`):
- `sigaction`, `SIG_IGN`, `SIGINT`
- **Rust equivalent**: `signal-hook` crate or `libc` bindings
- **Scaffolding**: Not provided - may need to add dependency or simplify

### Recommendations

1. **Memory Management**: Use Rust's ownership system (`Box<Val>`, `Rc<Val>`, or `Arc<Val>` for shared references). Consider `Rc<RefCell<Val>>` for interior mutability if needed.

2. **String Interning**: The C code interns strings and symbols in hash tables. Rust equivalent: use `HashMap<String, Rc<Val>>` or consider `string-interner` crate.

3. **Hash Tables**: C uses custom open-addressing hash table. Rust equivalent: `std::collections::HashMap` (already provided in scaffolding as `Rec` struct with `Vec<Entry>`).

4. **Error Handling**: Replace C's NULL-return pattern with Rust's `Result<Val, String>` or `Option<Val>`. The scaffolding uses `Option<Val>` for most functions.

5. **Variadic Functions**: `mk_list` uses C varargs. Rust equivalent: use slice `&[Val]` or `Vec<Val>`.

6. **File I/O**: Use `std::fs::File` and `std::io` traits. Scaffolding already uses `&mut std::fs::File` for `tisp_print`.

7. **Dynamic Loading**: Either add `libloading` crate or stub out dynamic library support (not critical for core functionality).

8. **Signal Handling**: Either add `signal-hook` crate or simplify (SIGINT handling in main.c is not critical for tests).

### What Scaffolding Already Provides

The scaffolding at `scaffold/` provides:
- **Module structure**: `lib.rs` with modules `core`, `io`, `math`, `os`, `string`, `tisp`
- **Type definitions**: `TspType` enum, `Val` struct, `Rec` struct, `Tsp` struct, `Entry` struct
- **Function signatures**: All major functions declared with `unimplemented!()` bodies
- **Test harness**: `src/bin/test.rs` with test runner and first 53 test cases
- **Cargo.toml**: Basic Rust project configuration

**Do NOT reinvent**:
- The type system (use provided `TspType`, `Val`, `ValUnion`, `Rec`, `Tsp`, `Entry`)
- The module structure (use provided `core`, `io`, `math`, `os`, `string`, `tisp`)
- The test harness structure (use provided `test.rs`)

**DO implement**:
- All function bodies (currently `unimplemented!()`)
- Additional helper functions as needed
- Proper error handling with `Option`/`Result`
- Memory management with Rust ownership

---

## 3. Target Project Design

### Overview and Translation Requirements

**Goal**: Faithful translation of Tisp from C to Rust, preserving:
- Functional equivalence: same input → same output
- API compatibility: same function names and signatures (adapted to Rust idioms)
- Test oracle: all 527 test cases in test.c must pass when translated to Rust

**Constraints**:
- Use provided scaffolding structure (do not change public interfaces)
- Conform to Rust's ownership and borrowing rules
- Replace C's manual memory management with Rust's automatic management
- Replace NULL-return errors with `Option<Val>` or `Result<Val, String>`

### Source→Target Structural Mapping

#### Module Mapping

| C File | Rust Module | Responsibility |
|--------|-------------|----------------|
| `tisp.h` | `src/tisp.rs` | Type definitions, core API |
| `tisp.c` (lines 1-400) | `src/tisp.rs` | Value constructors, utilities |
| `tisp.c` (lines 400-690) | `src/tisp.rs` | Reader implementation |
| `tisp.c` (lines 690-810) | `src/tisp.rs` | Evaluator implementation |
| `tisp.c` (lines 810-890) | `src/tisp.rs` | Printer implementation |
| `tisp.c` (lines 890-953) | `src/tisp.rs` | Environment management |
| `tib/core.c` | `src/core.rs` | Core primitives (car, cdr, cons, etc.) |
| `tib/string.c` | `src/string.rs` | String manipulation primitives |
| `tib/math.c` | `src/math.rs` | Math primitives |
| `tib/io.c` | `src/io.rs` | I/O primitives |
| `tib/os.c` | `src/os.rs` | OS interaction primitives |
| `main.c` | `src/bin/main.rs` (new) | CLI entry point |
| `test.c` | `src/bin/test.rs` | Test harness (already scaffolded) |

#### Type Mapping

| C Type | Rust Type | Notes |
|--------|-----------|-------|
| `Val` (pointer) | `Val` (owned) or `Box<Val>` | Scaffolding uses owned `Val` |
| `Rec` (pointer) | `Rec` (owned) or `Box<Rec>` | Scaffolding uses owned `Rec` |
| `Tsp` (pointer) | `Tsp` (owned) or `&mut Tsp` | Pass by mutable reference |
| `char*` | `String` or `&str` | Use `String` for owned, `&str` for borrowed |
| `int` | `i32` | |
| `size_t` | `usize` | |
| `double` | `f64` | |
| `FILE*` | `&mut std::fs::File` | Already in scaffolding |
| `NULL` | `None` | For `Option<T>` |
| `void` | `()` | |
| `Prim` (function pointer) | `fn(Tsp, Rec, Val) -> Val` | Scaffolding uses this signature |

#### Idiom Mapping

| C Pattern | Rust Pattern | Example |
|-----------|--------------|---------|
| `if (!ptr)` | `if ptr.is_none()` | NULL checks → Option checks |
| `return NULL` | `return None` | Error signaling |
| `malloc/free` | `Box::new` / automatic drop | Memory management |
| `realloc` | `Vec::push` / `Vec::resize` | Dynamic arrays |
| `strcmp(a, b) == 0` | `a == b` | String comparison |
| `strlen(s)` | `s.len()` | String length |
| `strchr(s, c)` | `s.contains(c)` or `s.find(c)` | Character search |
| `isdigit(c)` | `c.is_ascii_digit()` | Character classification |
| `fprintf(f, ...)` | `write!(f, ...)` | Formatted output |
| `va_list` | `&[Val]` or `Vec<Val>` | Variadic arguments |
| `struct { ... } *p` | `Box<struct { ... }>` | Heap allocation |
| `p->field` | `p.field` | Field access (no -> in Rust) |
| `enum` (bitflags) | `enum` + `as u32` | Type flags |
| `union` | `enum` with variants | Tagged unions |

### Module Structure for Target Project

```
tisp_proj/
├── Cargo.toml
├── src/
│   ├── lib.rs              # Module declarations
│   ├── tisp.rs             # Core interpreter (types, reader, eval, print, env)
│   ├── core.rs             # Core primitives (car, cdr, cons, quote, eval, cond, etc.)
│   ├── string.rs           # String primitives
│   ├── math.rs             # Math primitives
│   ├── io.rs               # I/O primitives
│   ├── os.rs               # OS primitives
│   └── bin/
│       ├── main.rs         # CLI entry point (to be created)
│       └── test.rs         # Test harness (already scaffolded)
└── tests/                  # Integration tests (optional)
```

### Output/Contract Mapping

The test oracle (`test.c` → `test.rs`) defines the contract:
- **Input**: Tisp source code strings
- **Output**: Printed representation of evaluated values
- **Contract**: For each test case `(input, expected)`, `tisp_eval(tisp_read(input))` must print exactly `expected`

**Critical output formats** (must match exactly):
- Integers: no leading zeros, negative sign if needed
- Decimals: always include `.0` if integer value, scientific notation for very large/small
- Rationals: reduced form, negative sign on numerator only
- Strings: raw text (no quotes)
- Lists: space-separated, parentheses, dot notation for improper lists
- Nil: exactly `"Nil"`
- Void: exactly `"Void"`

### Boundary and Error-Handling Strategy

**Error Handling**:
- C uses `NULL` return + stderr messages
- Rust uses `Option<Val>` for functions that can fail
- Error messages: print to stderr with same format `"; tisp: error: <message>\n"`
- Propagate errors with `?` operator or explicit `if let None = ... { return None; }`

**Boundary Strategy**:
- **Reader boundary**: `tisp_read` parses text → `Option<Val>`
- **Evaluator boundary**: `tisp_eval` evaluates AST → `Option<Val>`
- **Printer boundary**: `tisp_print` formats value → writes to `File`
- **Primitive boundary**: Each primitive function validates arguments, returns `Option<Val>`

**No external boundaries** to mock - the interpreter is self-contained. File I/O in `tib/io.c` uses real files (not critical for core tests).

### Unit-Test Strategy

**Mockable Seams**:
- Not needed - the test suite runs against the full interpreter
- File I/O in `tib/io.c` could be mocked with a trait, but not required for core tests

**Test Structure**:
- Use provided `test.rs` harness
- Translate all 527 test cases from `test.c` to Rust
- Test runner: `tisp_test(st, input, expect, output)` reads, evals, prints, compares
- Tests organized into sections (self, comments, quote, cons, etc.)

**Test Execution**:
1. Initialize: `let mut st = tisp::tisp_env_init(1024);`
2. Load libraries: `tib_env_core(&mut st); tib_env_math(&mut st); ...`
3. For each test: `tisp_test(&mut st, input, expect, false)`
4. Report: `correct/total` per section and overall

**Source Tests → Target Tests**:
- Direct translation: C test array → Rust const array
- Same test runner logic
- Same assertion: `assert_eq!(correct, total)`

**New Tests**:
- Not required - the 527 existing tests provide comprehensive coverage
- Could add Rust-specific tests for memory safety, but not in scope

### Milestone Mapping

**Milestone 1: Core Data Structures and Utilities** (Foundation)
- Implement `Val`, `Rec`, `Tsp`, `Entry` types (already defined in scaffolding)
- Implement value constructors: `mk_int`, `mk_dec`, `mk_rat`, `mk_str`, `mk_sym`, `mk_pair`, `mk_list`, `mk_prim`, `mk_func`, `mk_rec`
- Implement utilities: `tsp_type_str`, `tsp_lstlen`, `vals_eq`, `frac_reduce`, `hash`
- Implement record operations: `rec_new`, `rec_add`, `rec_get`, `rec_extend`, `rec_grow`, `entry_get`
- **Tests**: Self-evaluating values (numbers, strings, booleans, nil, void) - ~20 tests
- **Validation**: `cargo test` with first 20 test cases

**Milestone 2: Reader** (Parsing)
- Implement `skip_ws`, `is_sym`, `is_op`, `isnum`
- Implement `read_sign`, `read_int`, `read_num`, `read_sci`
- Implement `esc_char`, `esc_str`, `read_str`, `read_sym`
- Implement `read_pair`, `tisp_read_sexpr`, `tisp_read`, `tisp_read_sugar`, `tisp_read_line`
- **Tests**: Comments, whitespace, quote, cons - ~50 tests
- **Validation**: `cargo test` with first 70 test cases

**Milestone 3: Evaluator** (Execution)
- Implement `tisp_eval`, `tisp_eval_list`, `tisp_eval_body`, `eval_proc`
- Implement `prepend_bt` (backtrace)
- **Tests**: eval, cond, eq - ~30 tests
- **Validation**: `cargo test` with first 100 test cases

**Milestone 4: Printer** (Output)
- Implement `tisp_print`
- **Tests**: All output-dependent tests
- **Validation**: `cargo test` with first 150 test cases

**Milestone 5: Environment** (Global State)
- Implement `tisp_env_init`, `tisp_env_add`, `tisp_env_lib`
- **Tests**: def, defined? - ~20 tests
- **Validation**: `cargo test` with first 170 test cases

**Milestone 6: Core Primitives** (tib/core.c → core.rs)
- Implement primitives: `prim_car`, `prim_cdr`, `prim_cons`, `form_quote`, `prim_eval`, `prim_eq`, `form_cond`, `prim_typeof`
- Implement forms: `form_Func`, `form_Macro`, `form_def`, `form_set`, `form_undefine`, `form_defined`, `prim_load`, `prim_error`, `prim_version`
- Load `tib_env_core`
- **Tests**: car, cdr, cons, quote, eval, cond, eq, def, Func - ~100 tests
- **Validation**: `cargo test` with first 270 test cases

**Milestone 7: Math Primitives** (tib/math.c → math.rs)
- Implement arithmetic: `prim_add`, `prim_sub`, `prim_mul`, `prim_div`, `prim_mod`
- Implement comparison: `prim_lt`, `prim_le`, `prim_gt`, `prim_ge`
- Implement math functions: `prim_abs`, `prim_sgn`, `prim_max`, `prim_min`, `prim_sqrt`, `prim_exp`, `prim_log`, `prim_sin`, `prim_cos`, `prim_tan`, `prim_floor`, `prim_ceil`, `prim_round`, `prim_truncate`
- Implement conversions: `prim_Int`, `prim_Dec`, `prim_numerator`, `prim_denominator`
- Load `tib_env_math`
- **Tests**: arithmetic, compare, abs, sgn, max/min, round, conversions - ~150 tests
- **Validation**: `cargo test` with first 420 test cases

**Milestone 8: String Primitives** (tib/string.c → string.rs)
- Implement `val_string`, `prim_string`, `prim_symbol`, `prim_display`, `prim_displayln`, `prim_print`, `prim_println`
- Load `tib_env_string`
- **Tests**: string operations - ~20 tests
- **Validation**: `cargo test` with first 440 test cases

**Milestone 9: I/O Primitives** (tib/io.c → io.rs)
- Implement `prim_read`, `prim_write`, `prim_open`, `prim_close`, `prim_parse`
- Load `tib_env_io`
- **Tests**: I/O operations - ~20 tests
- **Validation**: `cargo test` with first 460 test cases

**Milestone 10: OS Primitives** (tib/os.c → os.rs)
- Implement `prim_cd`, `prim_pwd`, `prim_system`, `prim_time`
- Load `tib_env_os`
- **Tests**: OS operations - ~10 tests
- **Validation**: `cargo test` with first 470 test cases

**Milestone 11: Embedded Tisp Library** (tibs.tsp.h → embedded string)
- Embed Tisp library code (core.tsp, list.tsp, math.tsp, io.tsp, os.tsp, doc.tsp) as Rust string
- Implement `tisp_env_lib` to parse and evaluate embedded code
- **Tests**: All library-dependent tests (list operations, quasiquote, stack, etc.) - ~57 tests
- **Validation**: `cargo test` with all 527 test cases

**Milestone 12: CLI Entry Point** (main.c → main.rs)
- Implement `main` function with argument parsing
- Implement REPL mode
- Implement file execution mode
- Implement `-c` command mode
- **Tests**: Manual testing of CLI
- **Validation**: `cargo run -- -c "(+ 1 2)"` → `3`

### Summary

This design preserves the C implementation's structure while adapting to Rust idioms:
- **1-to-1 module mapping**: Each C file maps to a Rust module
- **Type safety**: Replace C's manual memory management with Rust's ownership
- **Error handling**: Replace NULL returns with `Option<Val>`
- **Test-driven**: 527 test cases define the contract
- **Incremental**: 12 milestones, each validated by passing tests
- **Scaffolding-conformant**: Uses provided types and signatures

The translation is **faithful** (same semantics) but **idiomatic** (Rust patterns). The test oracle ensures correctness at each milestone.
