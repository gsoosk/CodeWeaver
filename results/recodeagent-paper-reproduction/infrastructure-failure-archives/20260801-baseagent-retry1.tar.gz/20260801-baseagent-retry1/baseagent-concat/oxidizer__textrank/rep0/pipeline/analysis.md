# TextRank Go → Rust Translation Analysis

## 1. Source Project Research

### Overview
TextRank is a Go implementation of the TextRank algorithm for automatic text summarization and keyword extraction. The library analyzes text to find the most important words, phrases, and sentences based on word occurrence and relationship weights. It supports multiple languages through configurable stop-word lists and provides pluggable algorithms for ranking.

### Project Structure
The source is organized as a single Go package (`textrank`) with the following components:

**Core Components:**
- `textrank.go` - Main API wrapper providing the public interface
- `rank.go` - Core data structures (`Rank`, `Word`) for the graph representation
- `relation.go` - Phrase/relation tracking (`Relation`, `Score`)
- `algorithm.go` - Ranking algorithms (`Algorithm` interface, `AlgorithmDefault`, `AlgorithmChain`)
- `ranking.go` - Weight calculation and normalization logic
- `builder.go` - Converts parsed text into the rank graph
- `tokenizer.go` - Text parsing into sentences and words
- `text.go` - Parsed text data structures (`Text`, `ParsedSentence`)
- `rule.go` - Tokenization rules (`Rule` interface, `RuleDefault`)
- `language.go` - Stop-word filtering (`Language` interface, `LanguageDefault`)
- `stop_word.go` - Default English stop-word list
- `sorting.go` - Query/finder functions for phrases, words, and sentences

**Entry Point:**
- `cmd/main.go` - Minimal main that imports the package (no actual CLI logic)

### Key Interfaces and Contracts

**Algorithm Interface:**
```go
type Algorithm interface {
    WeightingHits(wordID int, rank *Rank) float32
    WeightingRelation(word1ID int, word2ID int, rank *Rank) float32
}
```
Two implementations: `AlgorithmDefault` (basic occurrence-based) and `AlgorithmChain` (considers word connections).

**Language Interface:**
```go
type Language interface {
    IsStopWord(word string) bool
    FindRootWord(word string) (bool, string)
    SetActiveLanguage(code string)
    SetWords(code string, words []string)
}
```
Implementation: `LanguageDefault` with configurable stop-word lists per language.

**Rule Interface:**
```go
type Rule interface {
    IsWordSeparator(rune rune) bool
    IsSentenceSeparator(rune rune) bool
}
```
Implementation: `RuleDefault` with fixed separator arrays.

### Data Models

**Rank** - Central graph structure:
- `Max`, `Min` (float32) - normalization bounds for word weights
- `Relation` - phrase graph
- `SentenceMap` (map[int]string) - sentence ID → original text
- `Words` (map[int]*Word) - word ID → Word object
- `WordValID` (map[string]int) - token → word ID lookup

**Word** - Node in the word graph:
- `ID`, `Token`, `Qty`, `Weight`
- `SentenceIDs` ([]int) - sentences containing this word
- `ConnectionLeft`, `ConnectionRight` (map[int]int) - adjacent word IDs → occurrence count

**Relation** - Phrase graph:
- `Max`, `Min` (float32) - normalization bounds for phrase weights
- `Node` (map[int]map[int]Score) - adjacency matrix for word pairs

**Score** - Edge in the phrase graph:
- `Qty` (int) - phrase occurrence count
- `Weight` (float32) - normalized weight
- `SentenceIDs` ([]int) - sentences containing this phrase

### Error Handling
The Go source uses **no explicit error handling**. All operations are assumed to succeed. Invalid inputs (e.g., out-of-bounds sentence IDs) may cause panics or silent incorrect results.

### Dependencies
From `go.mod`:
- `github.com/stretchr/testify v1.2.1` - for unit tests (assertions)
- Standard library only for implementation (`math`, `strings`, `unicode/utf8`, `sort`)

### Unit Tests and Mocking Strategy

**Test Files:**
- `textrank_test.go` - Integration tests (`TestOnSingleThread`, `TestOnMultiThread`)
- `algorithm_test.go` - Algorithm weighting tests
- `tokenizer_test.go` - Tokenization test
- `language_test.go` - Stop-word filtering test
- `rank_test.go` - Rank data structure test
- `sorting_test.go` - Finder function test

**Test Characteristics:**
- **No mocking** - tests use real implementations
- **No external dependencies** - all tests are self-contained
- **Deterministic** - tests use fixed text samples and verify exact outputs
- **Thread safety test** - `TestOnMultiThread` uses goroutines and channels

**Key Test Data:**
The main integration test (`TestOnSingleThread`) uses a ~500-word text about GNOME Shell extensions and verifies:
- Top phrases (e.g., "gnome shell" with weight 1.0, qty 5)
- Top words (e.g., "gnome" with weight 1.0, qty 12)
- Sentence ranking by different criteria
- Phrase chain search

---

## 2. Third-Party Library Analysis

### Go Dependencies → Rust Equivalents

| Go Dependency | Purpose | Rust Equivalent | Notes |
|---------------|---------|-----------------|-------|
| `github.com/stretchr/testify` | Test assertions | Built-in `assert_eq!`, `assert!` macros | Rust's standard test framework is sufficient |
| `math` | `math.Abs` for float operations | `f32::abs()` | Built-in method |
| `strings` | `strings.ToLower` | `str::to_lowercase()` | Built-in method |
| `unicode/utf8` | `utf8.RuneCountInString` | `str::chars().count()` | Built-in iterator |
| `sort` | `sort.Slice` | `Vec::sort_by` | Built-in method |

**No external crates needed** - the entire implementation can use Rust's standard library.

### Scaffolding Provided
According to `codeweaver.toml`, the working copy is at `pipeline/target` and must support:
- `cargo build --manifest-path Cargo.toml`
- `cargo test --manifest-path Cargo.toml`

**Scaffolding to create:**
- `Cargo.toml` with a library crate
- Module structure mirroring the Go package

---

## 3. Target Project Design

### Structural Mapping (Go → Rust)

| Go File | Rust Module/File | Notes |
|---------|------------------|-------|
| `textrank.go` | `src/lib.rs` or `src/textrank.rs` | Public API, re-exports |
| `rank.go` | `src/rank.rs` | `Rank`, `Word` structs |
| `relation.go` | `src/relation.rs` | `Relation`, `Score` structs |
| `algorithm.go` | `src/algorithm.rs` | `Algorithm` trait, implementations |
| `ranking.go` | `src/ranking.rs` | `calculate()`, `normalize()` |
| `builder.go` | `src/builder.rs` | `text_to_rank()`, `add_word()`, `add_sentence()` |
| `tokenizer.go` | `src/tokenizer.rs` | `tokenize_text()`, `find_words()` |
| `text.go` | `src/text.rs` | `Text`, `ParsedSentence` |
| `rule.go` | `src/rule.rs` | `Rule` trait, `RuleDefault` |
| `language.go` | `src/language.rs` | `Language` trait, `LanguageDefault` |
| `stop_word.go` | `src/stop_word.rs` | `get_default_english()` |
| `sorting.go` | `src/sorting.rs` | Finder functions, `Phrase`, `SingleWord`, `Sentence` |
| `*_test.go` | `src/*/tests.rs` or `#[cfg(test)] mod tests` | Inline test modules |

### Module Structure

```
pipeline/target/
├── Cargo.toml
└── src/
    ├── lib.rs              # Public API (re-exports, TextRank struct)
    ├── rank.rs             # Rank, Word
    ├── relation.rs         # Relation, Score
    ├── algorithm.rs        # Algorithm trait + impls
    ├── ranking.rs          # calculate(), normalize()
    ├── builder.rs          # text_to_rank()
    ├── tokenizer.rs        # tokenize_text()
    ├── text.rs             # Text, ParsedSentence
    ├── rule.rs             # Rule trait + RuleDefault
    ├── language.rs         # Language trait + LanguageDefault
    ├── stop_word.rs        # English stop words
    └── sorting.rs          # Finders, Phrase, SingleWord, Sentence
```

### Naming Conventions

**Preserve Go names where idiomatic:**
- Struct names: `TextRank`, `Rank`, `Word`, `Relation`, `Score`, `Phrase`, `SingleWord`, `Sentence`
- Method names: Convert Go's `CamelCase` to Rust's `snake_case` (e.g., `FindPhrases` → `find_phrases`)
- Constants: `ByQty`, `ByRelation` → `BY_QTY`, `BY_RELATION` (Rust convention)

**Type adaptations:**
- Go `map[K]V` → Rust `HashMap<K, V>` or `BTreeMap<K, V>` (use `HashMap` for performance)
- Go `[]T` → Rust `Vec<T>`
- Go `int` → Rust `usize` (for IDs/indices) or `i32` (for counts)
- Go `float32` → Rust `f32`
- Go `string` → Rust `String` (owned) or `&str` (borrowed)

### Observable Contracts per Milestone

**M0 - Skeleton (compiles, no logic):**
- `cargo build` succeeds
- All public types and functions exist with stub implementations
- No tests pass yet

**M1 - Tokenization:**
- `tokenize_text()` parses text into sentences and words
- `Rule` trait and `RuleDefault` work correctly
- Test: `TestTokenizeText` passes

**M2 - Language/Stop Words:**
- `Language` trait and `LanguageDefault` filter stop words
- English stop-word list loaded
- Test: `TestLanguage` passes

**M3 - Rank Graph Construction:**
- `Rank`, `Word`, `Relation`, `Score` data structures
- `text_to_rank()` builds the graph from parsed text
- Tests: `TestGetWordData`, `algorithm_test::createRank` helper works

**M4 - Algorithm & Ranking:**
- `Algorithm` trait with `AlgorithmDefault` and `AlgorithmChain`
- `calculate()` computes and normalizes weights
- Tests: `TestWeightingRelation`, `TestWeightingHits` pass

**M5 - Sorting/Finders:**
- `find_phrases()`, `find_single_words()`, `find_sentences()`, etc.
- Test: `TestFindSentences` passes

**M6 - Full Integration:**
- `TextRank` API wrapper
- All finder methods
- Tests: `TestOnSingleThread`, `TestOnMultiThread` pass

### Error Handling Strategy

**Rust approach:**
- Use `Result<T, E>` for operations that can fail (e.g., invalid sentence IDs)
- Use `Option<T>` for lookups that may not find a value
- **However**, to match Go's behavior exactly, we may need to panic or return default values in some cases
- For this translation, **prefer matching Go's behavior** (no explicit error handling) to maintain parity

**Boundary strategy:**
- No external I/O or network calls
- All inputs are in-memory strings and configuration
- No mockable boundaries needed - tests use real implementations

### Unit Test Strategy

**Approach:**
- Translate each `*_test.go` file to inline `#[cfg(test)] mod tests` in the corresponding Rust module
- Use Rust's built-in `assert_eq!`, `assert!` macros (no external test crate needed)
- Preserve exact test logic and assertions from Go

**Mockable Seams:**
- **Not needed** - the Go tests don't use mocks
- The `Algorithm`, `Language`, and `Rule` traits already provide the abstraction points
- Tests instantiate real implementations (`AlgorithmDefault`, `LanguageDefault`, `RuleDefault`)

**Thread Safety:**
- Rust's ownership system ensures thread safety by default
- The `TestOnMultiThread` test will use `std::thread` and `std::sync::mpsc` channels
- `TextRank` will need to use `Arc<Mutex<Rank>>` or similar for shared mutable state

### Milestone Mapping

| Milestone | Goal | Tests |
|-----------|------|-------|
| M0 | Skeleton compiles | (none - build only) |
| M1 | Tokenization works | `tokenizer_test::TestTokenizeText` |
| M2 | Language/stop words work | `language_test::TestLanguage` |
| M3 | Rank graph builds | `rank_test::TestGetWordData` |
| M4 | Algorithms compute weights | `algorithm_test::TestWeightingRelation`, `algorithm_test::TestWeightingHits` |
| M5 | Finders retrieve results | `sorting_test::TestFindSentences` |
| M6 | Full integration | `textrank_test::TestOnSingleThread`, `textrank_test::TestOnMultiThread` |

**Cumulative nature:** Each milestone builds on the previous. M6 requires all prior functionality to work.

**Test selectors:** Rust uses `cargo test <test_name>` or `cargo test <module>::<test_name>`. The exact selectors will be determined after examining the test structure in detail during the Scoper phase.
