# BOSTree C-to-Rust Translation Analysis

## 1. Source Project Research

### Overview
BOSTree is a self-balancing order statistic AVL tree implementation in C. It combines:
- **AVL tree**: A self-balancing binary search tree where the heights of left and right subtrees differ by at most 1
- **Order statistics**: Augmented with `select(i)` (find i-th smallest element) and `rank(node)` (return node's position) operations, both running in O(log n)
- **Map semantics**: Stores separate key and value pointers for each node

The implementation maintains child counts for each node to enable efficient order statistic operations. It uses weak reference counting for node lifecycle management.

### Directory Structure and File Responsibilities

```
source/
├── bostree.h           # Public API header (157 lines)
├── bostree.c           # Core implementation (611 lines)
└── tests/
    ├── test_helpers.h  # Test utility header
    ├── test_helpers.c  # Tree sanity validation (92 lines)
    ├── sanity.c        # Basic insert/remove test (54 lines)
    ├── remove_bug.c    # Regression test for node removal bug (61 lines)
    ├── remove_bug_2.c  # Regression test for reparenting bug (47 lines)
    └── timing.c        # Performance/stress test with 10M operations (83 lines)
```

**bostree.h**: Defines the public API with 13 functions:
- Tree lifecycle: `bostree_new`, `bostree_destroy`
- Queries: `bostree_node_count`, `bostree_lookup`, `bostree_select`, `bostree_rank`
- Mutations: `bostree_insert`, `bostree_remove`
- Traversal: `bostree_next_node`, `bostree_previous_node`
- Reference management: `bostree_node_weak_ref`, `bostree_node_weak_unref`
- Debug: `bostree_print` (conditional on `!NDEBUG`)

**bostree.c**: Implements the AVL tree with order statistics:
- Private helpers: `_imax`, `_bostree_balance`, `_bostree_rotate_left`, `_bostree_rotate_right`
- AVL rotations handle both single and double rotations (left-right, right-left cases)
- Node removal is complex (260+ lines) with two main cases:
  1. Node has children on both sides: bubble up a replacement from deeper subtree
  2. Node has one or no children: simple replacement
- Debug printing outputs DOT format for visualization

**test_helpers.c**: Comprehensive sanity checker that validates:
- Node count consistency (manual traversal vs. reported count)
- Rank/select bidirectional consistency
- Lookup correctness
- Next/previous node traversal
- Parent-child relationship integrity
- Depth calculation accuracy
- Child count accuracy
- AVL balance property (|left_depth - right_depth| ≤ 1)

### Key Structures and API Surface

#### BOSTree (opaque)
```c
struct _BOSTree {
    BOSNode *root_node;
    BOSTree_cmp_function cmp_function;
    BOSTree_free_function free_function;
};
```

#### BOSNode (public)
```c
struct _BOSNode {
    unsigned int left_child_count;   // Count of nodes in left subtree
    unsigned int right_child_count;  // Count of nodes in right subtree
    unsigned int depth;              // Cached depth for AVL balancing
    
    struct _BOSNode *left_child_node;
    struct _BOSNode *right_child_node;
    struct _BOSNode *parent_node;
    
    void *key;                       // Generic key pointer
    void *data;                      // Generic data pointer
    
    unsigned char weak_ref_count;    // Reference counter (starts at 1)
    unsigned char weak_ref_node_valid; // 0 if removed from tree
};
```

#### Function Types
```c
typedef int (*BOSTree_cmp_function)(const void *, const void *);
typedef void (*BOSTree_free_function)(BOSNode *node);
```

### Data Models and Observable Output Contract

**Invariants maintained by the implementation:**
1. **AVL property**: For every node, |depth(left) - depth(right)| ≤ 1
2. **BST property**: For every node, all left descendants < node < all right descendants
3. **Order statistics**: `left_child_count` and `right_child_count` are accurate
4. **Depth caching**: Each node's `depth` equals max(depth(left_child), depth(right_child)) + 1
5. **Parent consistency**: If node.parent exists, node is one of parent's children
6. **Rank/select duality**: `bostree_select(bostree_rank(node)) == node`
7. **Traversal consistency**: `bostree_next_node(select(i)) == select(i+1)`

**Observable outputs (tested by test_helpers.c):**
- `bostree_node_count()`: Returns total nodes = root.left_child_count + root.right_child_count + 1
- `bostree_select(i)`: Returns i-th node in in-order traversal (0-indexed)
- `bostree_rank(node)`: Returns node's position in in-order traversal
- `bostree_lookup(key)`: Returns node with matching key or NULL
- `bostree_next_node(node)`: Returns next node in in-order or NULL
- `bostree_previous_node(node)`: Returns previous node in in-order or NULL
- After insert: tree remains balanced, counts updated, node accessible
- After remove: tree remains balanced, counts updated, node inaccessible

### Error Handling

The C implementation uses:
- **Assertions**: `assert()` for internal invariants (e.g., weak_ref_count bounds)
- **NULL returns**: Functions return NULL for "not found" cases
- **No explicit error codes**: Assumes valid inputs (no defensive programming for invalid trees/nodes)
- **Memory allocation**: Uses `malloc()` without checking for failure (assumes success)

### Dependencies

**Standard C library only:**
- `<stdlib.h>`: `malloc`, `free`, `rand`, `srand`, `atol`
- `<string.h>`: `memset`, `strcmp`, `strdup`
- `<assert.h>`: `assert`
- `<stdio.h>`: `printf`, `fprintf` (debug/test only)
- `<sys/timeb.h>`: `ftime`, `struct timeb` (timing test only)
- `<time.h>`: `time` (timing test only)
- `<unistd.h>`: `fsync` (debug print only)

**No external libraries** beyond libc.

### Source Unit Tests and Mocking Strategy

The C tests do **not** use mocking—they test the actual implementation directly:

1. **sanity.c**: Sequential insert A-Z, validate after each, then sequential remove A-Z, validate after each
2. **remove_bug.c**: For each letter A-Y, create fresh tree A-Y, remove that letter, validate
3. **remove_bug_2.c**: Create tree A-Y, remove G then H, validate E still exists
4. **timing.c**: Insert 10M random 32-char keys, validate every 1M, then remove all randomly, validate every 1M

**Validation approach**: `test_tree_sanity()` exhaustively checks all invariants by:
- Traversing the entire tree
- Verifying every node's metadata (depth, counts, parent links)
- Checking AVL balance property
- Confirming rank/select/lookup/next/previous consistency

**No mocking boundaries** because:
- The tree is self-contained (no I/O, no external services)
- Tests use `strcmp` as the comparison function (standard library)
- Memory allocation failures are not tested
- The free function is either NULL or a simple `free(key); free(data)` wrapper

---

## 2. Third-Party Library Analysis

### C Dependencies

#### Standard C Library (libc)
**Usage in source:**
- Memory management: `malloc`, `free`, `memset`
- String operations: `strcmp`, `strdup`
- Assertions: `assert`
- I/O (debug/test): `printf`, `fprintf`, `fsync`
- Time (test): `time`, `ftime`
- Random (test): `rand`, `srand`

**Rust equivalent:** Rust standard library (`std`)
- Memory: Rust's ownership system + `Box`, `Rc`, `RefCell`
- Strings: `String`, `&str`, `str::cmp`
- Assertions: `assert!`, `panic!`
- I/O: `println!`, `eprintln!`
- Time: `std::time::{Instant, SystemTime}`
- Random: **External crate needed** (see below)

#### Random Number Generation (test only)
**C usage:** `rand()`, `srand()` from `<stdlib.h>`

**Rust equivalent:** `rand` crate (version 0.9.0)
- **Already provided in scaffold's Cargo.toml**
- Usage: `rand::rngs::StdRng`, `rand::SeedableRng`, `rand::Rng`
- The scaffold's timing.rs already uses this correctly

### Recommended Rust Counterparts

| C Dependency | Rust Counterpart | Status |
|--------------|------------------|--------|
| `malloc`/`free` | `Box`, `Rc<RefCell<T>>` | **Provided by std** |
| `strcmp` | `str::cmp`, `Ord` trait | **Provided by std** |
| `assert` | `assert!`, `panic!` | **Provided by std** |
| `printf` | `println!`, `eprintln!` | **Provided by std** |
| `time`/`ftime` | `std::time::Instant` | **Provided by std** |
| `rand`/`srand` | `rand` crate | **Already in scaffold** |

### Scaffolding Analysis

**The scaffold already provides:**
1. **Type definitions** in `src/bostree.rs`:
   - `BOSTree` struct with `Rc<RefCell<BOSNode>>` for shared ownership
   - `BOSNode` struct with `Weak<RefCell<BOSNode>>` for parent (avoids cycles)
   - Function type aliases: `BOSTreeCmpFunction`, `BOSTreeFreeFunction`
   - Key/data specialized to `String` and `Option<String>` (not generic `void*`)

2. **Test infrastructure** in `src/lib.rs`:
   - `test_tree_sanity()` function (Rust port of test_helpers.c)
   - Comprehensive validation matching C version

3. **Test binaries** in `src/bin/`:
   - `remove_bug.rs`: Port of remove_bug.c
   - `remove_bug_2.rs`: Port of remove_bug_2.c
   - `timing.rs`: Port of timing.c with `rand` crate usage

4. **Build configuration** in `Cargo.toml`:
   - `rand = "0.9.0"` dependency
   - Test targets configured

**What NOT to add:**
- ❌ No additional crates needed
- ❌ Do not change the public API in bostree.rs
- ❌ Do not modify the test scaffolds (they are the oracle)
- ❌ Do not add generic type parameters (scaffold uses concrete `String` types)

---

## 3. Target Project Design

### Overview and Translation Requirements

**Functional equivalence measured by:**
- All three test binaries must pass: `remove_bug`, `remove_bug_2`, `timing`
- Each test includes `test_tree_sanity()` validation
- The timing test must complete 10M insertions + 10M deletions without errors

**Translation constraints from the brief:**
- Preserve the scaffold's public interface (do not modify `src/bostree.rs` signatures)
- Implement all `unimplemented!()` functions in `src/bostree.rs`
- Do not modify `src/lib.rs` (test_tree_sanity) or `src/bin/*.rs` (test oracles)
- Use the scaffold's `Rc<RefCell<BOSNode>>` ownership model

### Source→Target Structural Mapping

#### Module Structure
```
C source/                    Rust target/
├── bostree.h          →    src/bostree.rs (public API)
├── bostree.c          →    src/bostree.rs (implementation)
└── tests/
    ├── test_helpers.c →    src/lib.rs (already provided)
    ├── sanity.c       →    (not ported; covered by other tests)
    ├── remove_bug.c   →    src/bin/remove_bug.rs (already provided)
    ├── remove_bug_2.c →    src/bin/remove_bug_2.rs (already provided)
    └── timing.c       →    src/bin/timing.rs (already provided)
```

**One-to-one function mapping:**

| C Function | Rust Method/Function | Notes |
|------------|---------------------|-------|
| `bostree_new` | `BOSTree::bostree_new` | Constructor, returns `Self` |
| `bostree_destroy` | (implicit) | Rust's `Drop` trait handles cleanup |
| `bostree_node_count` | `BOSTree::bostree_node_count` | Method on tree |
| `bostree_insert` | `BOSTree::bostree_insert` | Returns `Rc<RefCell<BOSNode>>` |
| `bostree_remove` | `BOSTree::bostree_remove` | Takes `&Rc<RefCell<BOSNode>>` |
| `bostree_node_weak_ref` | `bostree_node_weak_ref` | Free function |
| `bostree_node_weak_unref` | `BOSTree::bostree_node_weak_unref` | Method (needs tree for free_function) |
| `bostree_lookup` | `BOSTree::bostree_lookup` | Returns `Option<Rc<RefCell<BOSNode>>>` |
| `bostree_select` | `BOSTree::bostree_select` | Returns `Option<Rc<RefCell<BOSNode>>>` |
| `bostree_next_node` | `bostree_next_node` | Free function |
| `bostree_previous_node` | `bostree_previous_node` | Free function |
| `bostree_rank` | `bostree_rank` | Free function |
| `bostree_print` | `BOSTree::bostree_print` | Conditional on `cfg(debug_assertions)` |

**Private helper functions to implement:**
- `_imax(i1: i32, i2: i32) -> i32`: Max of two integers
- `_bostree_balance(node: &Rc<RefCell<BOSNode>>) -> i32`: Calculate balance factor
- `_bostree_rotate_left(tree: &mut BOSTree, node: &Rc<RefCell<BOSNode>>) -> Rc<RefCell<BOSNode>>`
- `_bostree_rotate_right(tree: &mut BOSTree, node: &Rc<RefCell<BOSNode>>) -> Rc<RefCell<BOSNode>>`

#### Idiom Mappings

| C Idiom | Rust Idiom | Notes |
|---------|------------|-------|
| `void*` pointers | `String` / `Option<String>` | Scaffold specializes to strings |
| `NULL` | `None` / `Option<T>` | Rust's type-safe null |
| `malloc` / `free` | `Rc::new(RefCell::new(...))` | Reference-counted smart pointers |
| Raw pointers | `Rc<RefCell<T>>` / `Weak<RefCell<T>>` | Shared ownership, weak for parent |
| `assert()` | `assert!()` | Rust macro |
| `strcmp` | `str::cmp()` or `Ord` trait | String comparison |
| Function pointers | `fn(&str, &str) -> i32` | Function type |
| Manual ref counting | `weak_ref_count: u8` | Keep manual counter (scaffold has it) |
| `unsigned int` | `u32` | Rust unsigned integer |
| `unsigned char` | `u8` | Rust unsigned byte |
| `int` | `i32` | Rust signed integer |

**Memory management strategy:**
- Use `Rc<RefCell<BOSNode>>` for child pointers (shared ownership)
- Use `Weak<RefCell<BOSNode>>` for parent pointers (avoid cycles)
- Manual `weak_ref_count` field preserved (scaffold requirement)
- `weak_ref_node_valid` flag preserved (scaffold requirement)
- No explicit `Drop` implementation needed (Rc handles cleanup)

**Concurrency:** Not required (single-threaded like C version)

### Module Structure for Target Project

```
pipeline/target/
├── Cargo.toml          # Build configuration (from scaffold)
├── Cargo.lock          # Dependency lock (from scaffold)
└── src/
    ├── lib.rs          # Re-exports + test_tree_sanity (from scaffold)
    ├── bostree.rs      # Core implementation (IMPLEMENT THIS)
    └── bin/
        ├── remove_bug.rs      # Test 1 (from scaffold)
        ├── remove_bug_2.rs    # Test 2 (from scaffold)
        └── timing.rs          # Test 3 (from scaffold)
```

**Implementation scope:**
- **ONLY** implement the functions in `src/bostree.rs` marked `unimplemented!()`
- Do **NOT** modify any other files
- The scaffold's structure is authoritative

### Output/Contract Mapping

Each test validates specific behaviors:

#### Test 1: remove_bug.rs
**Contract:**
- For each key 'A' through 'Y':
  1. Create tree with keys 'A' through 'Y' (25 nodes)
  2. Remove the target key
  3. Validate tree sanity (all invariants)
  4. Verify node count is 24
- **Validates:** Node removal doesn't lose subtrees (the "B' vanishes" bug)

#### Test 2: remove_bug_2.rs
**Contract:**
- Create tree with keys 'A' through 'Y'
- Remove 'G', then remove 'H'
- Validate tree sanity
- Verify 'E' is still present
- **Validates:** Reparenting during removal (the "E not reparented" bug)

#### Test 3: timing.rs
**Contract:**
- Insert 10,000,000 random 32-character keys (unique)
- Every 1,000,000 insertions: validate sanity
- Remove all nodes in random order
- Every 1,000,000 deletions: validate sanity
- **Validates:** Correctness under stress, no memory leaks, performance

#### test_tree_sanity (called by all tests)
**Contract (must all pass):**
1. Manual traversal count == `bostree_node_count()`
2. For each node at index i:
   - `bostree_rank(node) == i`
   - `bostree_lookup(node.key) == node`
   - `bostree_next_node(node) == bostree_select(i+1)`
   - `bostree_previous_node(node) == bostree_select(i-1)`
   - If parent exists, node is one of parent's children
   - Actual depth == reported depth
   - Actual left_child_count == reported left_child_count
   - Actual right_child_count == reported right_child_count
   - AVL balance: |left_depth - right_depth| ≤ 1

### Boundary and Error-Handling Strategy

**No external boundaries** (self-contained data structure):
- No I/O operations (except debug print)
- No network calls
- No file system access
- No database connections

**Error handling approach:**
1. **Invalid inputs:** Use `assert!()` for internal invariants (matching C)
2. **Not found:** Return `None` (Rust's `Option` type)
3. **Memory allocation:** Trust Rust's allocator (panics on OOM, like C's unchecked malloc)
4. **Weak reference violations:** Use `assert!()` for bounds checks (matching C)

**No Result<T, E> needed** because:
- All operations are infallible (given valid inputs)
- The C version doesn't return error codes
- Tests assume valid usage

### Unit Test Strategy

**Mockable seams:** None required
- The tree is a pure data structure with no external dependencies
- Tests use real `String` comparison (no need to mock)
- No I/O to mock

**Test organization:**
1. **Integration tests** (scaffold's `src/bin/*.rs`):
   - Each test is a standalone binary with `#[test]` attribute
   - Tests use the public API only
   - No mocking, no test doubles

2. **Validation helper** (`src/lib.rs::test_tree_sanity`):
   - Shared by all tests
   - Exhaustive invariant checking
   - Already implemented in scaffold

**Source tests → Target tests mapping:**

| C Test | Rust Test | Translation Status |
|--------|-----------|-------------------|
| sanity.c | (not ported) | Covered by remove_bug.rs |
| remove_bug.c | remove_bug.rs | **Already provided** |
| remove_bug_2.c | remove_bug_2.rs | **Already provided** |
| timing.c | timing.rs | **Already provided** |
| test_helpers.c | lib.rs::test_tree_sanity | **Already provided** |

**No new tests needed** because:
- The scaffold provides complete test coverage
- sanity.c is redundant (remove_bug.rs is more comprehensive)
- All tests use the same validation function

**Test execution:**
```bash
cd pipeline/target
cargo test --manifest-path Cargo.toml
```

This runs all three test binaries and validates correctness.

### Milestone Mapping

The translation can be completed in a single milestone since the scope is well-defined:

#### Milestone 1: Complete BOSTree Implementation
**Functionality to implement:**
1. Tree creation: `bostree_new`
2. Node counting: `bostree_node_count`
3. Insertion with AVL balancing: `bostree_insert`
4. Removal with AVL balancing: `bostree_remove`
5. Lookup: `bostree_lookup`
6. Order statistics: `bostree_select`, `bostree_rank`
7. Traversal: `bostree_next_node`, `bostree_previous_node`
8. Reference management: `bostree_node_weak_ref`, `bostree_node_weak_unref`
9. Helper functions: `_imax`, `_bostree_balance`, `_bostree_rotate_left`, `_bostree_rotate_right`
10. Debug print: `bostree_print` (optional, for debugging)

**Unit tests to pass:**
- `cargo test remove_bug` (25 removal scenarios)
- `cargo test remove_bug_2` (specific reparenting case)
- `cargo test timing` (10M operations stress test)

**Validation command:**
```bash
cd pipeline/target && cargo test --manifest-path Cargo.toml
```

**Success criteria:**
- All tests pass
- No panics or assertion failures
- test_tree_sanity validates all invariants
- Timing test completes without errors

**Implementation order (suggested):**
1. Basic structure: `bostree_new`, `bostree_node_count`
2. Simple operations: `bostree_lookup`, `bostree_next_node`, `bostree_previous_node`, `bostree_rank`
3. Insertion without balancing (BST insert)
4. AVL rotation helpers: `_bostree_balance`, `_bostree_rotate_left`, `_bostree_rotate_right`
5. Insertion with balancing (complete `bostree_insert`)
6. Order statistics: `bostree_select`
7. Reference management: `bostree_node_weak_ref`, `bostree_node_weak_unref`
8. Removal (most complex): `bostree_remove`
9. Debug print: `bostree_print`

**Critical implementation notes:**
- The removal logic is the most complex (260+ lines in C)
- Pay careful attention to:
  - Child count updates during rotations
  - Depth recalculation after structural changes
  - Parent pointer updates (use `Rc::downgrade()` for weak refs)
  - The two removal cases (both children vs. one/zero children)
  - Bubbling up replacement nodes from deeper subtrees
- Use `Rc::ptr_eq()` to compare node identity (not value equality)
- Borrow nodes carefully with `.borrow()` and `.borrow_mut()` to avoid panics
- The weak reference counting is manual (don't rely on Rc's count)

---

## Summary

This analysis provides the authoritative design for translating BOSTree from C to Rust:

1. **Source Research**: BOSTree is a 611-line AVL tree with order statistics, tested by 4 comprehensive test files that validate all invariants.

2. **Library Analysis**: Only standard library dependencies; the scaffold already provides all necessary Rust equivalents (std + rand crate).

3. **Target Design**: One-to-one structural mapping preserving the C logic, using Rust's `Rc<RefCell<T>>` for shared ownership and `Weak<RefCell<T>>` for parent pointers. The scaffold's public API is authoritative and must not be changed. Implementation consists of filling in the `unimplemented!()` functions in `src/bostree.rs` to pass all three test binaries.

The translation is straightforward but requires careful attention to Rust's borrowing rules and the complex removal logic. Success is measured solely by the three test binaries passing.
