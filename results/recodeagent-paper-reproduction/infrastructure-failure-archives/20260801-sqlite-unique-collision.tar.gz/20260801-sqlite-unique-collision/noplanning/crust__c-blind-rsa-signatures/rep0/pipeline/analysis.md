# Analysis Document: C to Rust Port of c-blind-rsa-signatures

## 1. Source Project Research

### Overview
The C implementation provides **Blind RSA Signatures** following RFC 9474 (RSASSA-PSS RSAE). The protocol enables a server to sign a blinded message from a client, allowing the client to later derive a valid (message, signature) pair that the server cannot link to the original blind signature. This is useful for anonymous token systems.

**Key workflow:**
1. Client blinds a message with a random secret factor
2. Server signs the blind message without seeing the original
3. Client unblinds the signature to obtain a valid (message, signature) pair
4. Anyone can verify the signature using the server's public key

### Directory Structure
```
source/
├── src/
│   ├── blind_rsa.h       # Public API header (180 lines)
│   ├── blind_rsa.c       # Implementation (920 lines)
│   └── test_blind_rsa.c  # Unit tests (189 lines)
├── Makefile              # Build configuration
├── README.md             # Documentation
└── LICENSE
```

**File Responsibilities:**
- **blind_rsa.h**: Defines all public types, enums, and function signatures for the blind RSA API
- **blind_rsa.c**: Implements all cryptographic operations using OpenSSL (1.1.x or 3.x)
- **test_blind_rsa.c**: Contains three test functions validating the complete protocol flow

### Key Structures and Interfaces

**Core Data Types (from blind_rsa.h):**

1. **BRSAContext** - Configuration context
   - `evp_md`: Hash function (EVP_MD pointer)
   - `salt_len`: PSS salt length

2. **BRSAPublicKey** - RSA public key
   - `evp_pkey`: OpenSSL EVP_PKEY pointer
   - `mont_ctx`: Montgomery context for modular exponentiation

3. **BRSASecretKey** - RSA secret key
   - `evp_pkey`: OpenSSL EVP_PKEY pointer

4. **BRSABlindMessage** - Blinded message
   - `blind_message`: Byte array
   - `blind_message_len`: Length

5. **BRSABlindingSecret** - Secret blinding factor
   - `secret`: Byte array
   - `secret_len`: Length

6. **BRSABlindSignature** - Blind signature
   - `blind_sig`: Byte array
   - `blind_sig_len`: Length

7. **BRSASignature** - Unblinded signature
   - `sig`: Byte array
   - `sig_len`: Length

8. **BRSASerializedKey** - DER-serialized key
   - `bytes`: Byte array
   - `bytes_len`: Length

9. **BRSAMessageRandomizer** - Optional noise prefix
   - `noise`: 32-byte array

10. **BRSAHashFunction** - Enum for hash algorithms
    - BRSA_SHA256, BRSA_SHA384, BRSA_SHA512

**Public API Functions (26 total):**

*Context Management:*
- `brsa_context_init_default()` - Initialize with SHA-384, auto salt
- `brsa_context_init_deterministic()` - Initialize with SHA-384, zero salt
- `brsa_context_init_custom()` - Initialize with custom hash and salt

*Key Management:*
- `brsa_keypair_generate()` - Generate RSA key pair (2048-4096 bits)
- `brsa_secretkey_import/export()` - DER serialization
- `brsa_publickey_import/export()` - DER serialization
- `brsa_publickey_recover()` - Extract public key from secret key
- `brsa_publickey_export_spki()` - Export as SubjectPublicKeyInfo
- `brsa_publickey_import_spki()` - Import from SPKI
- `brsa_publickey_id()` - Compute SHA-256 hash of SPKI as identifier
- `brsa_*_deinit()` - Free resources (6 functions)

*Blind Signature Protocol:*
- `brsa_blind_message_generate()` - Generate random message and blind it
- `brsa_blind()` - Blind a specific message
- `brsa_blind_sign()` - Server signs blind message
- `brsa_finalize()` - Client unblinds signature and verifies
- `brsa_verify()` - Verify unblinded signature

**Internal Helper Functions (from blind_rsa.c):**
- `_rsa_bits()`, `_rsa_size()`, `_rsa_n()`, `_rsa_e()` - OpenSSL version-agnostic accessors
- `new_mont_domain()` - Create Montgomery context
- `_rsa_parameters_check()` - Validate modulus size and exponent
- `_hash()` - Compute message hash with optional prefix
- `_blind()` - Core blinding algorithm
- `_check_canonical()` - Validate blind message is in canonical form
- `_finalize()` - Core unblinding algorithm
- `rsassa_pss_verify()` - PSS signature verification

### Data Models and Observable Output

**Contract Enforced by Tests:**

1. **Key Generation**: RSA-2048 keys with exponent F4 (65537)
2. **Blind Message**: Modulus-sized byte array (256 bytes for RSA-2048)
3. **Blinding Secret**: Modulus-sized byte array
4. **Signatures**: Modulus-sized byte arrays
5. **Serialized Keys**: DER-encoded byte arrays
6. **Key ID**: First N bytes of SHA-256(SPKI)
7. **Return Values**: 0 for success, -1 for error

**Cryptographic Properties:**
- PSS padding with MGF1
- Configurable hash function (SHA-256/384/512)
- Configurable salt length (0 for deterministic, hash-size for probabilistic)
- Modulus range: 2048-4096 bits
- Exponent: 3 or 65537 (F4)

### Error Handling

**Error Strategy:**
- All functions return `int`: 0 on success, -1 on error
- OpenSSL errors are propagated via `ERR_put_error()`
- Memory allocation failures return -1
- Invalid parameters (modulus too small/large, bad exponent) return -1
- Canonical form violations return -1

**Resource Management:**
- All heap-allocated structures have `_deinit()` functions
- Uses `OPENSSL_malloc()`, `OPENSSL_free()`, `OPENSSL_clear_free()` for sensitive data
- Montgomery contexts and BIGNUMs are properly freed
- EVP_PKEY structures are freed via `EVP_PKEY_free()`

### Dependencies

**Primary Dependency: OpenSSL**
- Supports OpenSSL 1.1.x, 3.x, and BoringSSL
- Uses conditional compilation for version compatibility

**OpenSSL Components Used:**
1. **EVP (Envelope) API**: `EVP_PKEY`, `EVP_MD`, `EVP_MD_CTX` for high-level crypto
2. **RSA API**: `RSA_*` functions for key generation, padding, encryption
3. **BIGNUM API**: `BN_*` for arbitrary-precision arithmetic
4. **Montgomery Context**: `BN_MONT_CTX` for efficient modular exponentiation
5. **Random**: `RAND_bytes()` for cryptographic randomness
6. **Hashing**: `SHA256_*` for key IDs, `EVP_Digest*` for message hashing
7. **ASN.1/DER**: `i2d_*`, `d2i_*` for key serialization
8. **X.509**: `X509_ALGOR` for SPKI construction

**Version-Specific Handling:**
- OpenSSL 3.x uses `EVP_PKEY_get_bn_param()` for key parameters
- OpenSSL 1.1.x uses `RSA_get0_n()`, `RSA_get0_e()`
- BoringSSL has `BN_bn2bin_padded()` built-in

### Unit Tests and Mocking Strategy

**Test Suite (test_blind_rsa.c):**

1. **test_default()** - Full protocol with default context (SHA-384, auto salt)
   - Generate keypair
   - Blind random message
   - Sign blind message
   - Finalize signature
   - Verify signature
   - Export/import keys
   - Compute key ID

2. **test_deterministic()** - Deterministic padding (zero salt)
   - Same flow as test_default
   - **Additional check**: Signing same blind message twice produces identical signatures

3. **test_custom_parameters()** - Custom hash (SHA-256) and salt (48 bytes)
   - Same flow as test_default

**Mocking Boundaries:**
The C tests do NOT mock any boundaries - they use real OpenSSL for all operations. This is appropriate because:
- OpenSSL is the only external dependency
- The library is a thin wrapper around OpenSSL primitives
- Correctness depends on actual cryptographic operations

**For Rust port:**
- Tests should similarly use real OpenSSL (via `openssl` crate)
- No mocking needed for unit tests
- Integration tests validate the complete protocol flow
- Property-based tests could verify algebraic properties (blind/unblind roundtrip)

---

## 2. Third-Party Library Analysis

### OpenSSL (C Source Dependency)

**Overview:**
OpenSSL is a robust, full-featured cryptographic library providing SSL/TLS and general-purpose cryptography. The C implementation uses OpenSSL for all RSA operations, big number arithmetic, hashing, and key management.

**How the Source Uses It:**
1. **Key Generation**: `RSA_generate_key_ex()` with exponent F4
2. **Key Serialization**: `i2d_PrivateKey()`, `d2i_PrivateKey()`, `i2d_PublicKey()`, `d2i_PublicKey()`
3. **RSA Operations**: `RSA_private_encrypt()`, `RSA_public_decrypt()` with `RSA_NO_PADDING`
4. **PSS Padding**: `RSA_padding_add_PKCS1_PSS_mgf1()`, `RSA_verify_PKCS1_PSS_mgf1()`
5. **Big Number Arithmetic**: `BN_*` functions for blinding/unblinding
6. **Montgomery Arithmetic**: `BN_MONT_CTX_*`, `BN_mod_exp_mont()` for efficient modular exponentiation
7. **Hashing**: `EVP_Digest*()` for message hashing, `SHA256_*()` for key IDs
8. **Random**: `RAND_bytes()` for generating secrets and noise

**Recommended Rust Counterpart: `openssl` crate (v0.10)**

**Rationale:**
- **Already provided in scaffold**: `Cargo.toml` specifies `openssl = { version = "0.10", features = ["vendored"] }`
- **Direct FFI bindings**: Provides safe Rust wrappers around OpenSSL C API
- **Feature parity**: Supports all operations used by the C implementation
- **Version compatibility**: Works with OpenSSL 1.1.x and 3.x
- **Vendored option**: Ensures consistent OpenSSL version across platforms

**Mapping of C OpenSSL to Rust `openssl` crate:**

| C API | Rust `openssl` crate |
|-------|---------------------|
| `EVP_PKEY` | `openssl::pkey::PKey<T>` |
| `RSA` | `openssl::rsa::Rsa<T>` |
| `BIGNUM` | `openssl::bn::BigNum` |
| `BN_CTX` | `openssl::bn::BigNumContext` |
| `BN_MONT_CTX` | Not directly exposed; use `BigNum::mod_exp()` |
| `EVP_MD` | `openssl::hash::MessageDigest` |
| `EVP_MD_CTX` | `openssl::hash::Hasher` |
| `RAND_bytes()` | `openssl::rand::rand_bytes()` |
| `RSA_generate_key_ex()` | `Rsa::generate()` |
| `i2d_PrivateKey()` | `PKey::private_key_to_der()` |
| `d2i_PrivateKey()` | `PKey::private_key_from_der()` |
| `RSA_padding_add_PKCS1_PSS_mgf1()` | Manual implementation or `openssl::pkey_ctx::PkeyCtx` |
| `BN_mod_exp_mont()` | `BigNum::mod_exp()` |

**Additional Rust Ecosystem Crates (NOT needed - already in scaffold):**

The scaffold already provides:
- `openssl-sys = "0.9"` - Low-level FFI bindings for direct OpenSSL access if needed

**What NOT to add:**
- ❌ `rsa` crate - Pure Rust RSA, but lacks PSS-MGF1 blinding support
- ❌ `ring` - Doesn't support RSA blinding
- ❌ `num-bigint` - Not needed; use OpenSSL's BigNum
- ❌ `sha2` - Not needed; use OpenSSL's hashing

---

## 3. Target Project Design

### Overview and Translation Requirements

**Functional Equivalence:**
The Rust port must reproduce the exact cryptographic behavior of the C implementation, validated by the scaffold's test suite (`scaffold/src/bin/test.rs`). The tests mirror the C tests and verify:
1. Complete blind signature protocol (blind → sign → finalize → verify)
2. Deterministic padding produces identical signatures
3. Custom hash functions and salt lengths work correctly
4. Key serialization/deserialization roundtrips
5. Key ID computation

**Constraints from Project Brief:**
1. **Immutable scaffold**: The provided Rust interface in `scaffold/src/blind_rsa.rs` defines the public API - do NOT change it
2. **Test oracle**: `scaffold/src/bin/test.rs` is the authoritative correctness check
3. **OpenSSL dependency**: Already specified in `Cargo.toml`

### Source → Target Structural Mapping

**Module Layout:**
```
C Source                          Rust Target
─────────────────────────────────────────────────────────────
src/blind_rsa.h                → src/blind_rsa.rs (public API)
src/blind_rsa.c                → src/blind_rsa.rs (implementation)
src/test_blind_rsa.c           → src/bin/test.rs (already provided)
```

**Type Mappings:**

| C Type | Rust Type | Notes |
|--------|-----------|-------|
| `BRSAContext` | `BRSAContext` | Struct with `evp_md: Option<EVP_MD>`, `salt_len: usize` |
| `BRSAPublicKey` | `BRSAPublicKey` | Struct with `evp_pkey: Option<EVP_PKEY>`, `mont_ctx: Option<BN_MONT_CTX>` |
| `BRSASecretKey` | `BRSASecretKey` | Struct with `evp_pkey: Option<EVP_PKEY>` |
| `BRSABlindMessage` | `BRSABlindMessage<'a>` | Struct with `blind_message: &'a [u8]`, `blind_message_len: usize` |
| `BRSABlindingSecret` | `BRSABlindingSecret<'a>` | Struct with `secret: &'a [u8]`, `secret_len: usize` |
| `BRSABlindSignature` | `BRSABlindSignature<'a>` | Struct with `blind_sig: &'a [u8]`, `blind_sig_len: usize` |
| `BRSASignature` | `BRSASignature<'a>` | Struct with `sig: &'a [u8]`, `sig_len: usize` |
| `BRSASerializedKey` | `BRSASerializedKey<'a>` | Struct with `bytes: &'a [u8]`, `bytes_len: usize` |
| `BRSAMessageRandomizer` | `BRSAMessageRandomizer` | Struct with `noise: [u8; 32]` |
| `BRSAHashFunction` | `BRSAHashFunction` | Enum with `BRSA_SHA256`, `BRSA_SHA384`, `BRSA_SHA512` |
| `uint8_t *` | `&[u8]` or `Vec<u8>` | Slices for input, Vec for owned data |
| `size_t` | `usize` | |
| `int` | `i32` or `c_int` | Return codes |
| `const EVP_MD *` | `Option<EVP_MD>` | OpenSSL type via `openssl-sys` |
| `EVP_PKEY *` | `Option<EVP_PKEY>` | OpenSSL type via `openssl-sys` |
| `BN_MONT_CTX *` | `Option<BN_MONT_CTX>` | OpenSSL type via `openssl-sys` |
| `BIGNUM *` | `Option<BIGNUM>` | OpenSSL type via `openssl-sys` |

**Idiom Mappings:**

1. **Memory Management:**
   - C: Manual `malloc`/`free`, `OPENSSL_malloc`/`OPENSSL_free`
   - Rust: `Vec<u8>` for owned buffers, `Box::from_raw()` for OpenSSL allocations
   - Lifetimes: Use `'a` for borrowed slices in message/signature structs

2. **Error Handling:**
   - C: Return `-1` on error, `0` on success
   - Rust: Keep same convention for FFI compatibility; internal helpers can use `Result<T, E>`

3. **Null Pointers:**
   - C: `NULL` for optional parameters
   - Rust: `Option<T>` (e.g., `msg_randomizer: &Option<BRSAMessageRandomizer>`)

4. **Mutability:**
   - C: Pointers are implicitly mutable
   - Rust: Explicit `&mut` for output parameters

5. **OpenSSL FFI:**
   - C: Direct function calls
   - Rust: Use `unsafe` blocks with `openssl-sys` for low-level operations
   - Prefer safe `openssl` crate wrappers where available

6. **Constants:**
   - C: `#define` macros
   - Rust: `const` or `pub const`

### Module Structure for Target Project

**File: `src/lib.rs`**
```rust
pub mod blind_rsa;
```

**File: `src/blind_rsa.rs`** (replace scaffold's unimplemented stubs)

**Sections:**
1. **Imports and Constants**
   - `use openssl_sys::*;`
   - `use std::ptr;`
   - Constants: `MIN_MODULUS_BITS`, `MAX_MODULUS_BITS`, `MAX_SERIALIZED_PK_LEN`, etc.

2. **Type Definitions**
   - Enums: `BRSAHashFunction`
   - Structs: `BRSAContext`, `BRSAPublicKey`, `BRSASecretKey`, etc.
   - Keep scaffold's struct definitions, replace `unimplemented!()` with real code

3. **Internal Helper Functions** (private)
   - `_rsa_bits()`, `_rsa_size()`, `_rsa_n()`, `_rsa_e()`
   - `new_mont_domain()`
   - `_rsa_parameters_check()`
   - `_hash()`
   - `_blind()`
   - `_check_canonical()`
   - `_finalize()`
   - `rsassa_pss_verify()`

4. **Public API Implementation**
   - Context methods: `brsa_context_init_*`
   - Key management: `brsa_keypair_generate`, `brsa_*key_import/export`
   - Protocol: `brsa_blind`, `brsa_blind_sign`, `brsa_finalize`, `brsa_verify`
   - Cleanup: `brsa_*_deinit`

5. **Memory Management Helpers** (private)
   - `brsa_blind_message_init()`, `brsa_blinding_secret_init()`, etc.
   - Allocate `Vec<u8>` and convert to slices

**File: `src/bin/test.rs`** (already provided in scaffold)
- Three test functions: `test_default`, `test_deterministic`, `test_custom_parameters`
- Do NOT modify

### Output/Contract Mapping

**Observable Outputs (validated by tests):**

1. **Key Generation**
   - Input: `modulus_bits: i32` (2048)
   - Output: `BRSASecretKey` and `BRSAPublicKey` with valid EVP_PKEY
   - Contract: Modulus is `modulus_bits` long, exponent is F4

2. **Blind Message Generation**
   - Input: `msg: &[u8]` (32 bytes), `pk: &BRSAPublicKey`
   - Output: `BRSABlindMessage` (256 bytes for RSA-2048), `BRSABlindingSecret` (256 bytes)
   - Contract: Blind message is PSS-padded and blinded with random factor

3. **Blind Signing**
   - Input: `blind_message: &BRSABlindMessage`, `sk: &BRSASecretKey`
   - Output: `BRSABlindSignature` (256 bytes)
   - Contract: Signature is RSA private encryption of blind message

4. **Finalization**
   - Input: `blind_sig: &BRSABlindSignature`, `secret: &BRSABlindingSecret`, `msg: &[u8]`, `pk: &BRSAPublicKey`
   - Output: `BRSASignature` (256 bytes)
   - Contract: Unblinded signature verifies against original message

5. **Verification**
   - Input: `sig: &BRSASignature`, `msg: &[u8]`, `pk: &BRSAPublicKey`
   - Output: `0` (success) or `-1` (failure)
   - Contract: PSS verification passes

6. **Key Serialization**
   - Input: `sk: &BRSASecretKey` or `pk: &BRSAPublicKey`
   - Output: `BRSASerializedKey` with DER-encoded bytes
   - Contract: Deserialization roundtrips correctly

7. **Key ID**
   - Input: `pk: &BRSAPublicKey`, `id_len: usize`
   - Output: First `id_len` bytes of SHA-256(SPKI)
   - Contract: Deterministic identifier for public key

8. **Deterministic Padding**
   - Input: Same blind message signed twice with zero salt
   - Output: Identical signatures
   - Contract: Determinism when salt_len = 0

### Boundary and Error-Handling Strategy

**High-Level Boundaries:**
The library is a thin wrapper around OpenSSL. All cryptographic operations delegate to OpenSSL via FFI.

**Boundary Strategy:**
1. **OpenSSL FFI**: Use `unsafe` blocks with `openssl-sys` for direct calls
2. **Safe Wrappers**: Use `openssl` crate for high-level operations where possible
3. **Memory Safety**: Ensure all OpenSSL-allocated memory is freed via proper `_deinit()` calls

**Error Handling:**
1. **Return Codes**: All public functions return `i32` (0 = success, -1 = error)
2. **Internal Helpers**: Can use `Result<T, ()>` internally, convert to -1/0 at API boundary
3. **OpenSSL Errors**: Check return values from all OpenSSL calls
4. **Null Checks**: Validate all OpenSSL allocations before use
5. **Parameter Validation**: Check modulus size, exponent, buffer lengths

**Error Propagation:**
```rust
// Internal helper
fn internal_operation() -> Result<(), ()> {
    unsafe {
        if openssl_sys::some_operation() != 1 {
            return Err(());
        }
    }
    Ok(())
}

// Public API
pub fn brsa_some_operation(...) -> i32 {
    match internal_operation() {
        Ok(()) => 0,
        Err(()) => -1,
    }
}
```

**Resource Cleanup:**
- All `_deinit()` methods must free OpenSSL resources
- Use `Drop` trait for RAII where appropriate (but scaffold uses manual `_deinit()`)
- Clear sensitive data (secrets, keys) before freeing

### Unit Test Strategy

**Mockable Seams:**
The C implementation does NOT mock OpenSSL, and neither should the Rust port. The library is fundamentally a cryptographic wrapper, and correctness depends on actual OpenSSL behavior.

**Test Structure:**
The scaffold provides three integration tests in `src/bin/test.rs`:
1. `test_default()` - Default context (SHA-384, auto salt)
2. `test_deterministic()` - Deterministic padding (zero salt)
3. `test_custom_parameters()` - Custom hash (SHA-256) and salt (48 bytes)

**Test Execution:**
- Tests are compiled as a binary (`src/bin/test.rs`)
- Each test uses `assert_eq!()` to validate return codes
- Tests validate the complete protocol flow end-to-end

**Unit Test Locations:**
- **Integration tests**: `src/bin/test.rs` (provided, do NOT modify)
- **Additional unit tests** (optional): Could add `#[cfg(test)]` module in `src/blind_rsa.rs` for:
  - Helper function correctness (`_rsa_bits`, `_rsa_size`, etc.)
  - Error cases (invalid modulus, bad exponent, etc.)
  - Edge cases (zero-length messages, oversized keys, etc.)

**Mocking Strategy:**
- **No mocking needed**: Use real OpenSSL for all tests
- **Why**: The library's value is in correct OpenSSL usage, not business logic
- **Alternative**: Property-based tests could verify algebraic properties without mocking

**Test Coverage Goals:**
1. ✅ Happy path: Complete protocol flow (covered by `test_default`)
2. ✅ Determinism: Same input → same output (covered by `test_deterministic`)
3. ✅ Custom parameters: Different hash/salt (covered by `test_custom_parameters`)
4. ⚠️ Error cases: Not covered by scaffold tests, but C tests don't cover them either
5. ⚠️ Edge cases: Not covered, but acceptable for initial port

### Milestone Mapping

**Milestone 1: Core Data Structures and Context Management**
- Implement `BRSAContext` and initialization methods
- Implement helper functions: `_rsa_bits`, `_rsa_size`, `_rsa_n`, `_rsa_e`
- Implement `new_mont_domain`
- **Tests**: None yet (no standalone tests for these)

**Milestone 2: Key Management**
- Implement `brsa_keypair_generate`
- Implement `brsa_secretkey_import/export`
- Implement `brsa_publickey_import/export`
- Implement `brsa_publickey_recover`
- Implement `brsa_*_deinit` for keys
- **Tests**: Partial validation via `test_default` (key generation and serialization)

**Milestone 3: Hashing and Padding**
- Implement `_hash` helper
- Implement `_rsa_parameters_check`
- **Tests**: None standalone, but required for protocol

**Milestone 4: Blinding**
- Implement `_blind` helper
- Implement `brsa_blind`
- Implement `brsa_blind_message_generate`
- Implement `brsa_blind_message_init/deinit`
- Implement `brsa_blinding_secret_init/deinit`
- **Tests**: Partial validation via `test_default`

**Milestone 5: Signing**
- Implement `_check_canonical`
- Implement `brsa_blind_sign`
- Implement `brsa_blind_signature_init/deinit`
- **Tests**: Partial validation via `test_default`

**Milestone 6: Finalization and Verification**
- Implement `_finalize` helper
- Implement `brsa_finalize`
- Implement `rsassa_pss_verify`
- Implement `brsa_verify`
- Implement `brsa_signature_init/deinit`
- **Tests**: ✅ `test_default` should pass
- **Tests**: ✅ `test_deterministic` should pass (validates determinism)
- **Tests**: ✅ `test_custom_parameters` should pass

**Milestone 7: SPKI and Key ID**
- Implement `brsa_publickey_export_spki`
- Implement `brsa_publickey_import_spki`
- Implement `brsa_publickey_id`
- **Tests**: ✅ All tests pass (key ID is tested in `test_default`)

**Validation Strategy:**
- After Milestone 6: All three tests should pass
- After Milestone 7: Complete parity with C implementation
- Run tests with: `cargo test --bin test` or `cargo run --bin test`

**Source Test Mapping:**
| C Test Function | Rust Test Function | Milestone |
|-----------------|-------------------|-----------|
| `test_default()` | `test_default()` | 6 (core), 7 (key ID) |
| `test_deterministic()` | `test_deterministic()` | 6 |
| `test_custom_parameters()` | `test_custom_parameters()` | 6 |

---

## Summary

This analysis document provides a comprehensive blueprint for porting **c-blind-rsa-signatures** from C to Rust:

1. **Source Project Research**: Analyzed the C implementation's structure (3 files, 920 lines of core logic), identified 26 public API functions, 10 data types, and 8 internal helpers. The library implements RFC 9474 blind RSA signatures using OpenSSL for all cryptographic operations.

2. **Third-Party Library Analysis**: Confirmed that the scaffold's `openssl` crate (v0.10) is the correct and only dependency needed. It provides direct FFI bindings to OpenSSL, matching the C implementation's approach. No additional crates are required.

3. **Target Project Design**: Defined a 1:1 structural mapping from C to Rust, preserving the module layout and API surface. Specified 7 milestones for incremental implementation, with the scaffold's three integration tests serving as the validation oracle. The design honors the immutable scaffold constraint and uses OpenSSL FFI for all cryptographic operations, mirroring the C implementation's architecture.

The port will replace the `unimplemented!()` stubs in `scaffold/src/blind_rsa.rs` with working implementations, validated by the existing tests in `scaffold/src/bin/test.rs`.
