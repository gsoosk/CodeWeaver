# Cissy C-to-Rust Translation Analysis

## 1. Source Project Research

### Overview
**Cissy** is a command-line CSV processing and formatting utility written in C. It is specifically designed to handle CSV files where quoted text contains the field separator (a common limitation of tools like AWK, sed, and cut). The program reads CSV data from stdin or a file, processes it according to command-line options, and outputs formatted CSV data.

**Core Functionality:**
- Parse CSV files with proper handling of quoted fields containing delimiters
- Select and reorder columns using range specifications (e.g., `2`, `2-5`, `4-`)
- Change input/output delimiters without affecting quoted text
- Support different quote characters for input and output
- Handle different end-of-line conventions (Unix `\n`, DOS `\r\n`, Mac `\r`)
- Detect and optionally allow binary characters in input

### Directory Structure

```
source/
├── src/
│   ├── cissy.c          # Main program with CLI parsing and CSV processing logic
│   ├── csvfield.h/c     # CsvField data structure for individual field storage
│   ├── csvline.h/c      # CsvLine data structure for line/row storage
│   ├── range.h/c        # Range parsing and management (column selection)
│   ├── Makefile         # Build configuration
│   └── doc/             # Documentation
├── test/
│   ├── test_csvfield.c  # Unit tests for csvfield module
│   ├── test_csvline.c   # Unit tests for csvline module
│   ├── test_range.c     # Unit tests for range module
│   └── Makefile         # Test build configuration
└── test_scripts/
    ├── test_in_out.sh   # Integration test harness
    └── test_in_out/     # 10 end-to-end test cases (input, args, expected output)
```

### Key Components and Interfaces

#### 1. **csvfield.h/c** - Field Storage Module
Manages individual CSV field data with dynamic memory allocation.

**Data Structure:**
```c
struct csvfield {
    char* data;      // Dynamically allocated string data
    size_t len;      // Allocated buffer size (not string length)
};
```

**API Surface:**
- `csvfield_create()` → `struct csvfield*` - Allocate new field with initial padding
- `csvfield_reset(pField)` - Reset field for reuse (sets data to '\0')
- `csvfield_set(pField, buf, offset, len)` - Set field content from buffer slice
- `csvfield_append(pField, buf, offset, len)` - Append to existing field content
- `csvfield_printToFile(pField, fp)` - Debug print in format `[data:len]`

**Memory Management:**
- Uses `STR_MEM_PAD = 10` bytes of extra allocation to reduce realloc frequency
- Grows buffer as needed via `malloc`/`free`/`realloc` pattern
- Exits on malloc failure

#### 2. **csvline.h/c** - Line/Row Storage Module
Manages a collection of CSV fields representing one line.

**Data Structure:**
```c
struct csvline {
    struct csvfield** field;  // Dynamic array of field pointers
    size_t fieldsize;         // Allocated array capacity
    size_t currentIdx;        // Number of fields currently in use
    char* eolStr;             // End-of-line string (default "\n")
};
```

**API Surface:**
- `csvline_create()` → `struct csvline*` - Allocate new empty line
- `csvline_reset(cline)` - Reset all fields for reuse, set currentIdx to 0
- `csvline_addField(cline, txt, startIdx, len)` - Add new field to line
- `csvline_appendField(cline, txt, startIdx, len)` - Append to last field (for multiline quoted fields)
- `csvline_getFieldCnt(cline)` → `size_t` - Return number of fields
- `csvline_getField(cline, idx)` → `char*` - Get field data by index (returns "" if out of bounds)
- `csvline_printToFile(cline, fp)` - Debug print

**Memory Management:**
- Grows field array in blocks of 10 to reduce realloc frequency
- Pre-creates csvfield objects when expanding array
- Reuses field objects across lines via reset

#### 3. **range.h/c** - Column Range Specification Module
Parses and manages column selection ranges (e.g., `1,3-5,7-`).

**Data Structure:**
```c
struct rangeElement {
    uint32_t start;
    uint32_t end;
    enum {EMPTY, SINGLE, STARTEND, GREATEREQUAL} rangetype;
    struct rangeElement* next;  // Linked list
};
```

**Range Types:**
- `EMPTY` - Uninitialized/empty range
- `SINGLE` - Single column (e.g., `5`)
- `STARTEND` - Range with start and end (e.g., `5-10`)
- `GREATEREQUAL` - Open-ended range (e.g., `5-` means 5 to end of line)

**API Surface:**
- `rangeCreate()` → `struct rangeElement*` - Create empty range element
- `rangeFree(list)` - Free entire linked list
- `rangeAddSingle(num, list)` → `struct rangeElement*` - Add single column to list
- `rangeAddStartEnd(start, end, list)` → `struct rangeElement*` - Add range to list
- `rangeAddGreaterEqual(num, list)` → `struct rangeElement*` - Add open-ended range
- `rangeContainsNum(num, list)` → `bool` - Check if column number is in any range
- `rangeElementToString(buf, bufsize, element)` → `char*` - Format single element
- `rangeListToString(buf, bufsize, list)` → `char*` - Format entire list
- `parseIntRanges(text)` → `struct rangeElement*` - Parse range string (e.g., "1,3-5,7-")

**Parsing Logic:**
- State machine parser for comma-separated ranges
- Validates: no leading dash, start ≤ end, positive numbers
- Exits on parse errors with descriptive messages

#### 4. **cissy.c** - Main Program
The main driver that orchestrates CSV parsing and output.

**Global State:**
```c
int32_t gLineCnt;                      // Current line number (for error messages)
FILE* gpInput, *gpOutput;              // I/O streams
char gpDelimIn, gpDelimOut;            // Delimiters (default ',')
char gpQuoteIn, gpQuoteOut;            // Quote characters (default '"')
char* gpEndLine;                       // Override EOL (NULL = preserve input)
bool gpAllowBinaryFlag;                // Allow binary characters
int gpVerbose;                         // Debug verbosity level
struct rangeElement* gpOutColumns;     // Column selection (NULL = all columns)
```

**Command-Line Options:**
- `-i <file>` - Input file (default: stdin)
- `-o <file>` - Output file (default: stdout)
- `-c <ranges>` - Column selection (e.g., "1,3-5,7-")
- `-d <char>` - Set both input and output delimiter
- `-di <char>` - Input delimiter
- `-do <char>` - Output delimiter
- `-q <char>` - Set both input and output quote character
- `-qi <char>` - Input quote character
- `-qo <char>` - Output quote character
- `-eu` - Unix EOL (`\n`)
- `-ed` - DOS EOL (`\r\n`)
- `-em` - Mac EOL (`\r`)
- `-b` - Allow binary data
- `-v` - Verbose (can be repeated for more verbosity)
- `-h` - Help

**Core Functions:**
- `main(argc, argv)` - Entry point, CLI parsing, main processing loop
- `getField(buf, buflen, end, inQuoted)` → `int` - Parse one field from buffer, return state
- `outputLine(cline)` - Output line according to column selection and formatting options
- `formatOutput(str)` - Convert quote characters if needed
- `isBinChar(c)` → `bool` - Detect binary characters (ASCII 1-8, 11-12, 14-26, 28-31, 127)
- `debug(level, fmt, ...)` - Conditional debug output to stderr
- `usage(fp)` - Print help message

**Processing Algorithm:**
1. Parse command-line arguments, set global configuration
2. For each line from input:
   - Create new `csvline` object
   - Read line with `getline()` (handles dynamic buffer allocation)
   - Parse fields using `getField()` state machine:
     - Track quote state to handle embedded delimiters
     - Detect field boundaries (delimiter or EOL)
     - Handle multiline quoted fields (read additional lines)
   - Add/append fields to `csvline` object
   - Output line via `outputLine()` with column filtering and formatting
3. Close files and exit

**State Machine (`getField`):**
- Returns: `rvStateNormal`, `rvStateMultiline`, `rvStateEOL`, `rvDelim`
- Tracks `inQuoted` state across calls for multiline fields
- Validates binary characters unless `-b` flag set
- Handles `\r`, `\n`, `\0` as EOL markers

### Data Models and Observable Output

**Input Contract:**
- CSV text with configurable delimiter (default comma)
- Quoted fields may contain delimiters and newlines
- Quote character is configurable (default double-quote)
- Supports multiline quoted fields

**Output Contract:**
- CSV text with selected columns
- Configurable output delimiter and quote character
- Configurable EOL convention
- Empty fields are handled (output delimiter only)
- Preserves input EOL unless overridden

**Observable Behavior (from test cases):**
- Test 1: Select single column → outputs that column from each line
- Test 2: Select range to end (`2-`) → outputs columns 2 through end
- Test 3: Quoted field with delimiter → preserves quotes and content
- Tests 4-10: Various combinations of column selection, delimiter changes, quote handling

### Error Handling

**Error Strategy:**
- **Fatal errors** (exit with -1):
  - Malloc failures → print to stderr, `exit(-1)`
  - File open failures → print to stderr, return -1
  - Invalid command-line arguments → print to stderr, return -1
  - Binary character in input (without `-b`) → print to stderr with line number, `exit(-1)`
  - Unterminated quote at EOF → print to stderr, `exit(-1)`
  - Range parsing errors (invalid syntax) → print to stderr, `exit(-1)`

- **No error recovery**: Program exits immediately on any error
- **Error messages**: All errors go to stderr with descriptive context

### Dependencies

**Standard C Library:**
- `stdio.h` - File I/O (`fopen`, `fprintf`, `getline`, `fclose`)
- `stdlib.h` - Memory allocation (`malloc`, `free`), `exit`, `atoi`
- `string.h` - String operations (`strlen`, `strncpy`, `strcmp`, `memset`, `memcpy`, `strncat`)
- `stdarg.h` - Variadic functions (`va_list`, `va_start`, `va_end`, `vfprintf`)
- `stdbool.h` - Boolean type
- `assert.h` - Assertions (used in tests and range validation)
- `limits.h` - Integer limits
- `stdint.h` - Fixed-width integer types (`uint32_t`, `int32_t`)

**No External Dependencies:** The project is self-contained with no third-party libraries.

### Unit Test Structure

#### test_csvfield.c
**Purpose:** Test csvfield module in isolation

**Test Cases:**
1. Create field → verify initial state
2. Set field to "hello" → verify data
3. Set field to "123" → verify reuse/overwrite
4. Set field to long string (27 chars) → verify buffer growth
5. Set to "123", append "123" → verify append produces "123123"
6. Reset field → verify cleared state

**Mocking:** None required (pure data structure)

**Output:** Debug prints to stderr in format `[data:len]`

#### test_csvline.c
**Purpose:** Test csvline module with csvfield integration

**Test Cases:**
1. Create line, add 25 "hello" fields → verify field count
2. Get field count → assert equals 25
3. Get first field → assert equals "hello"
4. Reset line → verify cleared state

**Mocking:** None required (uses real csvfield objects)

**Output:** Debug prints to stdout

#### test_range.c
**Purpose:** Test range parsing and query logic

**Test Cases:**
1. Single element (5) → test contains 4 (false), 5 (true)
2. Range (5-10) → test boundaries and interior
3. Multiple ranges (5-10, 15, 40-) → test all range types
4. Overlapping ranges (2, 2-4) → verify both added
5. Parse string "2,2-4" → verify produces same structure

**Mocking:** None required (pure logic)

**Assertions:** Uses `assert()` for validation

**Output:** Prints test names and "ok" on success

### Integration Tests

**Location:** `test_scripts/test_in_out.sh`

**Test Harness:**
- 10 test cases (test_1 through test_10)
- Each test has: `*_input.txt`, `*_cmdargs.txt`, `*_output.txt`
- Runs: `cat input | cissy $(cat cmdargs) > gen.txt`
- Compares: `diff gen.txt output.txt`

**Coverage:**
- Column selection (single, range, open-ended)
- Quoted fields with embedded delimiters
- Delimiter transformation
- Quote character transformation
- Various combinations

---

## 2. Third-Party Library Analysis

### C Standard Library → Rust Standard Library

#### stdio.h (File I/O)
**C Usage:**
- `FILE*`, `fopen()`, `fclose()`, `fprintf()`, `getline()`
- Used for: stdin/stdout/stderr, file I/O, formatted output

**Rust Equivalent:**
- `std::fs::File` - File handles
- `std::io::{stdin, stdout, stderr, BufRead, BufReader, Write}` - I/O traits and streams
- `std::io::BufRead::read_line()` - Line reading (similar to getline)
- `write!()`, `writeln!()` macros - Formatted output

**Provided by Scaffold:**
- The scaffold already imports `std::fs::File` and `std::io::Write` in csvfield.rs and csvline.rs
- **Do NOT add new I/O abstractions** - use standard library directly

#### stdlib.h (Memory Management)
**C Usage:**
- `malloc()`, `free()` - Manual memory management
- `exit()` - Program termination
- `atoi()` - String to integer conversion

**Rust Equivalent:**
- **Memory management:** Automatic via ownership system - `String`, `Vec<T>`, `Box<T>`
- **Program termination:** `std::process::exit()` or `panic!()` for fatal errors
- **String parsing:** `str::parse::<i32>()` or `str::parse::<u32>()`

**Provided by Scaffold:**
- Scaffold uses `String` for csvfield.data
- Scaffold uses `Vec<CsvField>` for csvline.field
- Scaffold uses `Option<Box<RangeElement>>` for range linked list
- **Do NOT introduce custom allocators** - use Rust's standard ownership

#### string.h (String Operations)
**C Usage:**
- `strlen()`, `strncpy()`, `strcmp()`, `memset()`, `memcpy()`, `strncat()`

**Rust Equivalent:**
- `String::len()`, `str::len()` - String length
- `String::push_str()`, `String::push()` - String building
- `str::eq()`, `==` operator - String comparison
- Slicing (`&str[start..end]`) - Substring operations
- `String::clear()` - Clear string (like memset)

**Provided by Scaffold:**
- Scaffold uses `String` type which provides all needed operations
- **Do NOT use unsafe string operations** - use safe Rust string APIs

#### stdarg.h (Variadic Functions)
**C Usage:**
- `va_list`, `va_start`, `va_end`, `vfprintf()` - Used in `debug()` function

**Rust Equivalent:**
- Rust macros for variadic behavior: `println!()`, `eprintln!()`, `format!()`
- For debug function: use `eprintln!()` macro directly or create macro wrapper

**Provided by Scaffold:**
- Scaffold declares `debug(level: i32, fmt: &str)` - simplified signature
- **Implementation note:** Convert to macro or use format strings

#### stdbool.h, stdint.h
**C Usage:**
- `bool`, `true`, `false` - Boolean type
- `uint32_t`, `int32_t` - Fixed-width integers

**Rust Equivalent:**
- `bool`, `true`, `false` - Built-in boolean type
- `u32`, `i32` - Built-in fixed-width integer types

**Provided by Scaffold:**
- Scaffold uses `u32` for range start/end
- Scaffold uses `i32` for main() return value
- **No additional types needed**

### Summary: No New Dependencies Required

**All functionality is provided by:**
1. **Rust standard library** (`std::*`) - I/O, strings, collections, process control
2. **Provided scaffold** - Already defines the public interface with appropriate types

**Do NOT add:**
- CSV parsing libraries (we're implementing the parser)
- Command-line parsing libraries (simple manual parsing like C version)
- Any external crates beyond what's in scaffold/Cargo.toml (currently none)

---

## 3. Target Project Design

### Overview and Translation Requirements

**Functional Equivalence:**
- The Rust port must produce **identical output** to the C version for all inputs
- Correctness is measured by the scaffold's unit tests (test_csvfield.rs, test_csvline.rs, test_range.rs)
- The translation must conform to the **provided scaffold interface** - do not modify public APIs

**Translation Constraints:**
1. **Preserve scaffold structure:** The scaffold defines modules (csvfield, csvline, range, cissy) and their public interfaces
2. **Implement all unimplemented!() functions** in the scaffold
3. **Maintain semantic equivalence:** Same algorithms, same edge cases, same error handling
4. **Rust idioms:** Use ownership, borrowing, and error handling idiomatically while preserving C semantics

### Source → Target Structural Mapping

#### Module Structure Mapping

| C Source | Rust Target | Mapping Notes |
|----------|-------------|---------------|
| `csvfield.h/c` | `src/csvfield.rs` | Struct + impl block |
| `csvline.h/c` | `src/csvline.rs` | Struct + impl block |
| `range.h/c` | `src/range.rs` | Nested module `pub mod range` with struct + impl |
| `cissy.c` | `src/cissy.rs` | Free functions (not a binary, used by tests) |
| `test/test_*.c` | `src/bin/test_*.rs` | Test binaries with `#[test]` functions |
| (main in cissy.c) | (main in cissy.rs) | Entry point for CLI tool |

#### Identifier Naming Conventions

**C → Rust Naming:**
- `struct csvfield` → `struct CsvField` (PascalCase for types)
- `csvfield_create()` → `CsvField::new()` (Rust constructor convention)
- `csvfield_set()` → `CsvField::set()` (method on struct)
- `struct rangeElement` → `struct RangeElement` (PascalCase)
- `enum {EMPTY, SINGLE, ...}` → `enum RangeType { Empty, Single, ... }` (PascalCase variants)
- Global variables `gpDelimIn` → local variables or struct fields (avoid globals)

**Preserve Semantic Names:**
- Keep field names: `data`, `len`, `field`, `fieldsize`, `current_idx`, `eol_str`
- Keep function names (converted to snake_case methods): `add_field`, `get_field_count`, `contains_num`

#### Type Mappings

| C Type | Rust Type | Notes |
|--------|-----------|-------|
| `char*` | `String` | Owned string (scaffold uses String) |
| `const char*` | `&str` | Borrowed string slice |
| `size_t` | `usize` | Platform-dependent unsigned integer |
| `uint32_t` | `u32` | 32-bit unsigned integer |
| `int32_t` | `i32` | 32-bit signed integer |
| `bool` | `bool` | Direct mapping |
| `FILE*` | `&mut File` | Borrowed mutable file handle |
| `struct csvfield*` | `CsvField` | Owned struct (no pointers needed) |
| `struct csvfield**` | `Vec<CsvField>` | Dynamic array of structs |
| `struct rangeElement*` | `Option<Box<RangeElement>>` | Linked list (scaffold uses this) |

#### Idiom Mappings

**Memory Management:**
- C: `malloc/free` → Rust: Automatic via `String`, `Vec`, `Box`
- C: Manual buffer growth → Rust: `String::reserve()`, `Vec::reserve()`
- C: NULL pointers → Rust: `Option<T>` (None/Some)

**Error Handling:**
- C: `exit(-1)` → Rust: `panic!()` or `std::process::exit(1)`
- C: `fprintf(stderr, ...)` → Rust: `eprintln!()`
- C: Return -1 on error → Rust: Return error code or use `Result<T, E>` (but match C behavior)

**I/O:**
- C: `getline()` → Rust: `BufRead::read_line()`
- C: `fprintf()` → Rust: `write!()`, `writeln!()`
- C: `fopen()` → Rust: `File::open()`, `File::create()`

**String Operations:**
- C: `strncpy(&buf[offset], src, len)` → Rust: `&src[offset..offset+len]` slicing
- C: `strlen()` → Rust: `.len()` method
- C: `strcmp()` → Rust: `==` operator
- C: `atoi()` → Rust: `.parse::<i32>()`

**Null Handling:**
- C: `if (ptr == NULL)` → Rust: `if let Some(val) = opt` or `match opt`
- C: Return NULL → Rust: Return `None`

### Module Structure for Target Project

```
pipeline/target/
├── Cargo.toml          # From scaffold (no changes)
├── src/
│   ├── lib.rs          # Module declarations (from scaffold)
│   ├── csvfield.rs     # CsvField implementation
│   ├── csvline.rs      # CsvLine implementation
│   ├── range.rs        # RangeElement implementation (nested module)
│   ├── cissy.rs        # Main program functions
│   └── bin/
│       ├── test_csvfield.rs  # Unit test binary
│       ├── test_csvline.rs   # Unit test binary
│       └── test_range.rs     # Unit test binary
```

**No changes to scaffold structure** - only implement the `unimplemented!()` bodies.

### Output/Contract Mapping

**Unit Test Contracts (from scaffold):**

1. **test_csvfield.rs:**
   - Create field → data should be empty string
   - Set field → data should match input
   - Append field → data should be concatenation
   - Reset field → data should be empty

2. **test_csvline.rs:**
   - Add 25 fields → field count should be 25
   - Get field 0 → should return "hello"
   - Reset → field count should be 0

3. **test_range.rs:**
   - Parse ranges → should match expected format
   - Contains checks → should return correct boolean
   - String formatting → should match C output format

**Integration Test Contract:**
- The Rust implementation must pass `cargo test` which runs the scaffold tests
- The tests verify the same behavior as C unit tests

### Boundary and Error-Handling Strategy

**Error Handling Philosophy:**
- **Match C behavior exactly:** Exit on fatal errors, no recovery
- **Use panic! for malloc-equivalent failures:** String/Vec allocation failures
- **Use eprintln! for error messages:** Match C's stderr output
- **Use std::process::exit(1) for CLI errors:** Match C's return -1

**Boundary Handling:**

1. **File I/O:**
   - C: `fopen()` returns NULL on failure → Rust: `File::open()` returns `Result`, unwrap or exit
   - C: `getline()` returns -1 on EOF → Rust: `read_line()` returns 0 bytes on EOF
   - Scaffold provides `File` type - use `std::fs::File::open()` and `File::create()`

2. **Memory Allocation:**
   - C: `malloc()` returns NULL → Rust: String/Vec panic on OOM (acceptable)
   - C: Manual buffer growth → Rust: Automatic with `String::reserve()`, `Vec::reserve()`

3. **String Parsing:**
   - C: `atoi()` returns 0 on error → Rust: `.parse()` returns `Result`, handle errors explicitly
   - C: Range parser exits on invalid input → Rust: `panic!()` or `exit()` on parse errors

4. **Array Bounds:**
   - C: Manual bounds checking → Rust: Automatic with `.get()` or panic with `[]`
   - csvline_getField returns "" for out-of-bounds → Rust: return `None` or `Some("")`

**No External Boundaries:**
- No database, network, or external services
- Only stdin/stdout/stderr and file I/O
- No mocking needed for unit tests (pure data structures)

### Unit Test Strategy

**Mockable Seams:**
- **None required** - all unit tests operate on pure data structures
- File I/O is only in main program, not in csvfield/csvline/range modules
- Tests use in-memory data (String, Vec) without file dependencies

**Test Structure:**

1. **Module Unit Tests (src/bin/test_*.rs):**
   - Each test file is a binary with `#[test]` functions
   - Tests call module functions directly (no mocking)
   - Scaffold already defines test structure - implement to match C tests

2. **Test Mapping:**

   **test_csvfield.c → test_csvfield.rs:**
   - Direct translation of test cases
   - Use `assert_eq!()` instead of manual verification
   - Output to Vec<u8> instead of stderr (scaffold pattern)

   **test_csvline.c → test_csvline.rs:**
   - Direct translation of test cases
   - Verify field count and field access
   - Test reset behavior

   **test_range.c → test_range.rs:**
   - Direct translation of test cases
   - Use `assert!()` and `assert_eq!()` for validation
   - Test all range types and parsing

3. **New Tests:**
   - **No new tests required** - scaffold tests cover C test functionality
   - If C tests are insufficient, add tests to match integration test coverage

**Test Execution:**
- `cargo test` runs all `#[test]` functions
- Each test binary can also be run standalone
- Tests must pass to validate translation correctness

### Milestone Mapping

The translation should proceed in dependency order, implementing and testing each module before moving to the next.

#### Milestone 1: Range Module
**C Source:** `range.h/c`
**Rust Target:** `src/range.rs`
**Unit Tests:** `test_range.c` → `test_range.rs`

**Functionality:**
- Implement `RangeElement` struct and methods
- Implement `RangeType` enum
- Implement linked list operations (add_single, add_start_end, add_greater_equal)
- Implement `contains_num()` query
- Implement `to_string()` and `list_to_string()` formatting
- Implement `parse_int_ranges()` parser

**Validation:**
- Run `cargo test --bin test_range`
- All assertions in test_range.rs must pass
- Output format must match C version exactly

**Dependencies:** None (standalone module)

#### Milestone 2: CsvField Module
**C Source:** `csvfield.h/c`
**Rust Target:** `src/csvfield.rs`
**Unit Tests:** `test_csvfield.c` → `test_csvfield.rs`

**Functionality:**
- Implement `CsvField::new()` constructor
- Implement `set()` method with buffer management
- Implement `append()` method
- Implement `reset()` method
- Implement `print_to_file()` method

**Validation:**
- Run `cargo test --bin test_csvfield`
- Field data must match expected values
- Buffer growth must work correctly

**Dependencies:** None (standalone module)

#### Milestone 3: CsvLine Module
**C Source:** `csvline.h/c`
**Rust Target:** `src/csvline.rs`
**Unit Tests:** `test_csvline.c` → `test_csvline.rs`

**Functionality:**
- Implement `CsvLine::new()` constructor
- Implement `add_field()` method with dynamic array growth
- Implement `append_field()` method
- Implement `get_field_count()` and `get_field()` accessors
- Implement `reset()` method
- Implement `print_to_file()` method

**Validation:**
- Run `cargo test --bin test_csvline`
- Field count and access must work correctly
- Dynamic growth must handle 25+ fields

**Dependencies:** CsvField module (Milestone 2)

#### Milestone 4: Main Program (cissy.rs)
**C Source:** `cissy.c`
**Rust Target:** `src/cissy.rs`
**Unit Tests:** Integration tests (if any)

**Functionality:**
- Implement `main()` function with CLI argument parsing
- Implement `get_field()` CSV parser state machine
- Implement `output_line()` with column filtering
- Implement `format_output()` quote conversion
- Implement `is_bin_char()` validation
- Implement `debug()` conditional output
- Implement `usage()` help text

**Validation:**
- Run `cargo build` to compile binary
- Run `cargo test` to verify all tests pass
- Manual testing with sample CSV inputs
- Compare output with C version for identical inputs

**Dependencies:** All previous modules (Milestones 1-3)

#### Milestone 5: Integration and Validation
**Validation:**
- Run full `cargo test` suite
- All unit tests must pass
- Verify output matches C version for edge cases:
  - Empty fields
  - Multiline quoted fields
  - Binary character detection
  - Various delimiter/quote combinations
  - All range types (single, start-end, greater-equal)

**Final Deliverables:**
- All `unimplemented!()` replaced with working code
- All tests passing
- Code compiles without warnings
- Behavior matches C version exactly

---

## Summary

This analysis provides a complete blueprint for translating cissy from C to Rust:

1. **Source Research:** Documented the C codebase structure, APIs, algorithms, and test coverage
2. **Library Analysis:** Identified that all functionality is provided by Rust std library and the scaffold - no new dependencies needed
3. **Target Design:** Defined the structural mapping, module organization, error handling strategy, unit test approach, and milestone sequence

The translation should proceed incrementally (Range → CsvField → CsvLine → Main), validating each milestone with its unit tests before proceeding. The scaffold's public interface must not be modified - only the `unimplemented!()` bodies should be filled in to match C semantics using idiomatic Rust.
