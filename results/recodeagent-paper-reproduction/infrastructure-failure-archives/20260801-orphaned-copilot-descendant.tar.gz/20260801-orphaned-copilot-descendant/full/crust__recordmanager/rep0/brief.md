# ReCodeAgent reproduction -- recordmanager (CRUST)

This project is part of a reproduction of the ReCodeAgent paper (arXiv:2604.07341) benchmark suite, run through CodeWeaver. Translate **recordmanager** faithfully from C to Rust.

## Hard constraints
- Read the C source under `source/` (read-only reference; do not edit it).
- Correctness is judged ONLY by the configured build/unit-test/validate commands against your own translation -- do not weaken, skip, or rewrite the oracle to make it pass.
- Do not fabricate a passing result: a milestone/parity claim must be backed by the actual command output.
- A provided Rust interface + test scaffold is under `scaffold/` (via `immutable_input`); conform your translation to it -- do not change its public interface.

## Scope
This is one project (`crust__recordmanager`) of the reproduction's benchmark matrix; translate only this project's source tree.
