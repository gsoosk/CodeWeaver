# TextRank Go → Rust Translation Analysis

## 1. Source Project Research

### Overview
TextRank is a Go implementation of the TextRank algorithm for automatic text summarization and phrase extraction. The library analyzes text to identify the most important words, phrases, and sentences using graph-based ranking algorithms. It supports multithreading, multiple languages (via stop word lists), and pluggable algorithms for weighting.

**Key Features:**
- Find most important phrases (word pairs)
- Find most important single words
- Extract important sentences by phrase weight or word occurrence
- Find sentences by phrase chains
- Support for multiple languages via stop word lists
- Two ranking algorithms: Default (basic occurrence) and Chain (combined with word relationships)
- Thread-safe for concurrent text processing
- Extensible via interfaces (Algorithm, Language, Rule)

**Project Structure:**
```
source/
├── textrank.go          # Main API facade
├── rank.go              # Core data structures (Rank, Word)
├── relation.go          # Phrase/relation graph (Relation, Score)
├── algorithm.go         # Ranking algorithms (AlgorithmDefault, AlgorithmChain)
├── language.go          # Stop word filtering (LanguageDefault)
├── rule.go              # Text parsing rules (RuleDefault)
├── tokenizer.go         # Text tokenization (TokenizeText, findWords)
├── builder.go           # Graph construction (TextToRank)
├── ranking.go           # Weight calculation (Calculate, normalize)
├── sorting.go           # Result extraction (FindPhrases, FindSingleWords, FindSentences)
├── text.go              # Parsed text structures (Text, ParsedSentence)
├── stop_word.go         # English stop word list
├── doc.go               # Package documentation
├── examples.go          # Example code
├── cmd/main.go          # Empty main (library only)
└── *_test.go            # Unit tests
```

**Total Lines:** ~2,173 lines of Go code

### Key Components and Interfaces

#### 1. **TextRank** (textrank.go)
The main facade that orchestrates the entire workflow:
- `NewTextRank()` - Constructor
- `Populate(text, lang, rule)` - Add text to the graph
- `Ranking(algorithm)` - Calculate weights
- `GetRankData()` - Access raw graph data
- `FindPhrases()`, `FindSingleWords()`, `FindSentencesByRelationWeight()`, etc. - Query methods

#### 2. **Rank** (rank.go)
Core data structure holding the entire graph:
- `Max`, `Min` - Min/max word weights for normalization
- `Relation` - Phrase graph (word-to-word connections)
- `SentenceMap` - Map of sentence ID → original sentence text
- `Words` - Map of word ID → Word struct
- `WordValID` - Map of word token → word ID (reverse index)

**Word struct:**
- `ID`, `Token` - Word identifier and text
- `Qty`, `Weight` - Occurrence count and normalized weight
- `SentenceIDs` - List of sentences containing this word
- `ConnectionLeft`, `ConnectionRight` - Adjacent words (map of word ID → occurrence count)

#### 3. **Relation** (relation.go)
Phrase graph structure:
- `Max`, `Min` - Min/max phrase weights
- `Node` - Nested map: `map[int]map[int]Score` (word1 ID → word2 ID → Score)

**Score struct:**
- `Qty` - Phrase occurrence count
- `Weight` - Normalized weight
- `SentenceIDs` - Sentences containing this phrase

**Methods:**
- `AddRelation(wordID, relatedWordID, sentenceID)` - Add or update a phrase
- Internal helpers: `updateRelation`, `extendRelation`, `createRelation`

#### 4. **Algorithm Interface** (algorithm.go)
Defines how to weight words and phrases:
```go
type Algorithm interface {
    WeightingHits(wordID int, rank *Rank) float32
    WeightingRelation(word1ID int, word2ID int, rank *Rank) float32
}
```

**Implementations:**
- `AlgorithmDefault` - Simple occurrence-based weighting
  - `WeightingHits`: returns word quantity
  - `WeightingRelation`: returns phrase quantity
- `AlgorithmChain` - Combined weighting with word relationships
  - `WeightingHits`: word qty + sum of (connected word qty × connection count)
  - `WeightingRelation`: phrase qty + abs(word1 qty - word2 qty) / 100

#### 5. **Language Interface** (language.go)
Handles stop words and word normalization:
```go
type Language interface {
    IsStopWord(word string) bool
    FindRootWord(word string) (bool, string)
    SetActiveLanguage(code string)
    SetWords(code string, words []string)
}
```

**LanguageDefault:**
- Stores stop words per language code
- Default English stop words (331 words)
- `IsStopWord`: checks if word is in stop list or ≤2 characters
- `FindRootWord`: stub (returns false, "") - not implemented
- `SetActiveLanguage`, `SetWords`: manage language dictionaries

#### 6. **Rule Interface** (rule.go)
Defines text parsing rules:
```go
type Rule interface {
    IsWordSeparator(rune rune) bool
    IsSentenceSeparator(rune rune) bool
}
```

**RuleDefault:**
- `wordSeparators`: 21 characters (space, punctuation, brackets, etc.)
- `sentenceSeparators`: 3 characters (!, ., ?)
- `IsWordSeparator`: checks both word and sentence separators
- `IsSentenceSeparator`: checks sentence separators only

#### 7. **Tokenizer** (tokenizer.go)
Parses raw text into structured data:
- `TokenizeText(rawText, rule)` → `Text` - Split text into sentences and words
- `findWords(rawSentence, rule)` → `[]string` - Extract words from a sentence (lowercased)

#### 8. **Builder** (builder.go)
Constructs the graph from parsed text:
- `TextToRank(sentence, lang, ranks)` - Add a sentence to the graph
- `addWord(ranks, words, lang, sentenceID)` - Add words, filter stop words, build connections
- `addSentence(ranks, sentence)` - Add sentence to map, return ID

#### 9. **Ranking** (ranking.go)
Calculates and normalizes weights:
- `Calculate(ranks, algorithm)` - Main entry point
- `updateRanks(ranks, algorithm)` - Calculate weights for words and phrases, normalize to [0, 1]
- `normalize(weight, min, max)` - Linear normalization: (weight - min) / (max - min)

#### 10. **Sorting/Querying** (sorting.go)
Extract ranked results:
- `FindPhrases(ranks)` → `[]Phrase` - All phrases sorted by weight
- `FindSingleWords(ranks)` → `[]SingleWord` - All words sorted by weight
- `FindSentences(ranks, kind, limit)` → `[]Sentence` - Top N sentences by ByQty or ByRelation
- `FindSentencesByPhrases(ranks, words)` → `[]Sentence` - Sentences containing phrase chains
- `FindSentencesFrom(ranks, id, limit)` → `[]Sentence` - N sentences starting from ID

**Result Structs:**
- `Phrase`: LeftID, RightID, Left, Right, Weight, Qty
- `SingleWord`: ID, Word, Weight, Qty
- `Sentence`: ID, Value

#### 11. **Text Structures** (text.go)
Intermediate parsing structures:
- `Text` - Container for `[]ParsedSentence`
- `ParsedSentence` - `original` (raw sentence), `words` (tokenized words)

### Data Models

**Graph Model:**
- **Nodes:** Words (unique tokens)
- **Edges:** Phrases (directed word pairs with occurrence counts)
- **Attributes:** Each word/phrase has quantity, weight, and sentence IDs

**Data Flow:**
1. Raw text → `TokenizeText` → `Text` (sentences + words)
2. `Text` → `TextToRank` → `Rank` (graph with words, phrases, sentences)
3. `Rank` + `Algorithm` → `Calculate` → Weighted graph (normalized weights)
4. Weighted graph → `Find*` functions → Sorted results

**Key Invariants:**
- Word IDs are sequential (0, 1, 2, ...)
- Sentence IDs are sequential (0, 1, 2, ...)
- Weights are normalized to [0.0, 1.0]
- Phrases are bidirectional (can be stored as either word1→word2 or word2→word1)
- Stop words are filtered during graph construction

### Error Handling
The Go source has **no explicit error handling**:
- No functions return errors
- No panics or error checks
- Assumes valid inputs (non-nil pointers, valid IDs)
- Map lookups assume keys exist (potential panics if misused)

**Implications for Rust:**
- Use `Option<T>` for map lookups
- Consider `Result<T, E>` for public APIs (e.g., invalid sentence IDs)
- Panic on internal invariant violations (e.g., word ID out of bounds)
- Document preconditions clearly

### Dependencies
From `go.mod`:
- `github.com/stretchr/testify v1.2.1` - Testing assertions (dev dependency)
- Standard library only: `strings`, `unicode/utf8`, `sort`, `math`

**No external runtime dependencies** - pure Go implementation.

### Unit Tests

**Test Files:**
1. `textrank_test.go` (196 lines) - Main integration tests
   - `TestOnSingleThread` - Full workflow with default and chain algorithms
   - `TestOnMultiThread` - Concurrent text processing via goroutines
   - Helper assertions: `assertTheGnomeTestTextDefault`, `assertTheGnomeTestTextChain`
   - Uses GNOME desktop article as test data

2. `algorithm_test.go` (62 lines)
   - `TestWeightingRelation` - Tests both algorithms' phrase weighting
   - `TestWeightingHits` - Tests both algorithms' word weighting
   - `createRank()` - Helper to build test graph

3. `language_test.go`, `rank_test.go`, `sorting_test.go`, `tokenizer_test.go` - Minimal/empty tests

**Test Strategy:**
- Integration tests dominate (full workflow)
- Few unit tests for individual components
- No mocking - tests use real implementations
- Assertions via `testify/assert`

**Mockable Boundaries:**
- `Algorithm` interface - can swap weighting strategies
- `Language` interface - can swap stop word lists
- `Rule` interface - can swap parsing rules
- No I/O or external dependencies to mock

---

## 2. Third-Party Library Analysis

### Go Dependencies → Rust Equivalents

#### Testing Framework
- **Go:** `github.com/stretchr/testify/assert`
- **Rust:** Built-in `assert_eq!`, `assert!` macros
- **Recommendation:** Use Rust's standard test framework. No external crate needed.

#### Standard Library Mappings

| Go Package | Go Usage | Rust Equivalent |
|------------|----------|-----------------|
| `strings` | `strings.ToLower()` | `str::to_lowercase()` |
| `unicode/utf8` | `utf8.RuneCountInString()` | `str::chars().count()` |
| `sort` | `sort.Slice()` with custom comparator | `Vec::sort_by()` or `Vec::sort_by_key()` |
| `math` | `math.Abs()` | `f32::abs()` |
| `time` | `time.Sleep()`, `time.Second` | `std::thread::sleep()`, `std::time::Duration` |

#### Concurrency
- **Go:** Goroutines + channels (`go func()`, `make(chan string)`, `<-stream`)
- **Rust:** `std::thread::spawn()` + `std::sync::mpsc::channel()` or `crossbeam::channel`
- **Recommendation:** Use `std::sync::mpsc` for basic channels, or `crossbeam` for more advanced patterns. For thread-safe shared state, use `Arc<Mutex<T>>`.

#### Collections
- **Go:** `map[K]V`, `[]T`
- **Rust:** `HashMap<K, V>`, `Vec<T>`
- **Recommendation:** Use `std::collections::HashMap` and `Vec`. No external crate needed.

### Provided Scaffolding
**None specified** - we must create the entire Rust project from scratch:
- `Cargo.toml` with project metadata
- `src/lib.rs` for library code
- `src/main.rs` for the binary (if needed)
- `tests/` for integration tests

### Recommended Rust Crates
**Minimal dependencies** (prefer standard library):
- **None required** for core functionality
- **Optional:** `crossbeam` (v0.8) for advanced concurrency (if needed for multi-threaded tests)

---

## 3. Target Project Design

### Structural Mapping (Source → Target)

| Go File | Rust Module/File | Notes |
|---------|------------------|-------|
| `textrank.go` | `src/lib.rs` or `src/textrank.rs` | Main API facade |
| `rank.go` | `src/rank.rs` | `Rank` and `Word` structs |
| `relation.go` | `src/relation.rs` | `Relation` and `Score` structs |
| `algorithm.go` | `src/algorithm.rs` | `Algorithm` trait + implementations |
| `language.go` | `src/language.rs` | `Language` trait + `LanguageDefault` |
| `rule.go` | `src/rule.rs` | `Rule` trait + `RuleDefault` |
| `tokenizer.go` | `src/tokenizer.rs` | `tokenize_text()`, `find_words()` |
| `builder.go` | `src/builder.rs` | `text_to_rank()`, `add_word()`, `add_sentence()` |
| `ranking.go` | `src/ranking.rs` | `calculate()`, `normalize()` |
| `sorting.go` | `src/sorting.rs` | `find_phrases()`, `find_single_words()`, etc. |
| `text.go` | `src/text.rs` | `Text`, `ParsedSentence` |
| `stop_word.go` | `src/stop_word.rs` | `get_default_english()` |
| `doc.go` | `src/lib.rs` (doc comments) | Package-level documentation |
| `examples.go` | `examples/` or doc tests | Example code |
| `cmd/main.go` | `src/main.rs` or `src/bin/` | Binary entry point (optional) |
| `*_test.go` | `tests/*.rs` | Integration tests |

### Module Structure

**Proposed Rust project layout:**
```
pipeline/target/
├── Cargo.toml
├── src/
│   ├── lib.rs              # Re-exports, public API
│   ├── textrank.rs         # TextRank struct + facade methods
│   ├── rank.rs             # Rank, Word
│   ├── relation.rs         # Relation, Score
│   ├── algorithm.rs        # Algorithm trait, AlgorithmDefault, AlgorithmChain
│   ├── language.rs         # Language trait, LanguageDefault
│   ├── rule.rs             # Rule trait, RuleDefault
│   ├── tokenizer.rs        # tokenize_text, find_words
│   ├── builder.rs          # text_to_rank, add_word, add_sentence
│   ├── ranking.rs          # calculate, normalize
│   ├── sorting.rs          # find_phrases, find_single_words, find_sentences, etc.
│   ├── text.rs             # Text, ParsedSentence
│   └── stop_word.rs        # get_default_english
├── tests/
│   ├── textrank_test.rs    # Integration tests (single/multi-threaded)
│   └── algorithm_test.rs   # Algorithm unit tests
└── examples/
    └── basic.rs            # Example usage
```

**`src/lib.rs` structure:**
```rust
pub mod algorithm;
pub mod builder;
pub mod language;
pub mod rank;
pub mod ranking;
pub mod relation;
pub mod rule;
pub mod sorting;
pub mod stop_word;
pub mod text;
pub mod textrank;
pub mod tokenizer;

// Re-export main types
pub use textrank::TextRank;
pub use algorithm::{Algorithm, AlgorithmDefault, AlgorithmChain};
pub use language::{Language, LanguageDefault};
pub use rule::{Rule, RuleDefault};
pub use rank::{Rank, Word};
pub use relation::{Relation, Score};
pub use sorting::{Phrase, SingleWord, Sentence, BY_QTY, BY_RELATION};
pub use text::{Text, ParsedSentence};
```

### Observable Output/Contract

**Public API (must match Go behavior):**

1. **Constructor Functions:**
   - `TextRank::new()` → `TextRank`
   - `RuleDefault::new()` → `RuleDefault`
   - `LanguageDefault::new()` → `LanguageDefault`
   - `AlgorithmDefault::new()` → `AlgorithmDefault`
   - `AlgorithmChain::new()` → `AlgorithmChain`

2. **TextRank Methods:**
   - `populate(&mut self, text: &str, lang: &dyn Language, rule: &dyn Rule)`
   - `ranking(&mut self, algorithm: &dyn Algorithm)`
   - `get_rank_data(&self) → &Rank`
   - `find_phrases(&self) → Vec<Phrase>`
   - `find_single_words(&self) → Vec<SingleWord>`
   - `find_sentences_by_relation_weight(&self, limit: usize) → Vec<Sentence>`
   - `find_sentences_by_word_qty_weight(&self, limit: usize) → Vec<Sentence>`
   - `find_sentences_by_phrase_chain(&self, phrases: &[String]) → Vec<Sentence>`
   - `find_sentences_from(&self, sentence_id: usize, limit: usize) → Vec<Sentence>`

3. **Trait Implementations:**
   - `Algorithm::weighting_hits(&self, word_id: usize, rank: &Rank) → f32`
   - `Algorithm::weighting_relation(&self, word1_id: usize, word2_id: usize, rank: &Rank) → f32`
   - `Language::is_stop_word(&self, word: &str) → bool`
   - `Language::find_root_word(&self, word: &str) → (bool, String)`
   - `Language::set_active_language(&mut self, code: &str)`
   - `Language::set_words(&mut self, code: &str, words: Vec<String>)`
   - `Rule::is_word_separator(&self, c: char) → bool`
   - `Rule::is_sentence_separator(&self, c: char) → bool`

4. **Result Structs:**
   - `Phrase { left_id, right_id, left, right, weight, qty }`
   - `SingleWord { id, word, weight, qty }`
   - `Sentence { id, value }`

**Behavioral Contracts (from tests):**
- Phrase ranking: "gnome shell" should be top phrase with weight 1.0, qty 5
- Word ranking: "gnome" should be top word with weight 1.0, qty 12
- Sentence extraction: Correct sentence IDs in correct order
- Normalization: Weights in [0.0, 1.0]
- Thread safety: Concurrent `populate` + `ranking` calls must not corrupt data

### Error Handling Strategy

**Rust Approach:**
1. **Public API:** Use `Result<T, E>` for operations that can fail:
   - `find_sentences_from(id, limit)` → `Result<Vec<Sentence>, String>` if `id` out of bounds
   - `find_sentences_by_phrase_chain(phrases)` → `Result<Vec<Sentence>, String>` if phrases not found

2. **Internal API:** Use `Option<T>` for map lookups:
   - `rank.words.get(&id)` → `Option<&Word>`
   - `rank.word_val_id.get(word)` → `Option<&usize>`

3. **Panics:** For internal invariants (should never happen):
   - Word ID out of bounds in internal functions
   - Relation node inconsistencies

4. **Validation:** Check inputs in public methods:
   - Empty text → early return (no-op)
   - Invalid sentence ID → return error or empty vec

### Boundary Strategy (Thread Safety)

**Go Approach:**
- No explicit synchronization in the code
- Tests use goroutines but rely on external synchronization (channels, sleep)
- Assumes single-threaded access to `TextRank` instance during mutation

**Rust Approach:**
1. **Single-threaded by default:** `TextRank` is `!Send` and `!Sync` (no interior mutability)
2. **Multi-threaded via wrapper:** Provide `Arc<Mutex<TextRank>>` for concurrent access
3. **Immutable queries:** After `ranking()`, all `find_*` methods are `&self` (read-only)

**Recommendation:**
- Make `TextRank` methods take `&mut self` for `populate` and `ranking`
- Make `find_*` methods take `&self` (immutable)
- For multi-threaded tests, wrap in `Arc<Mutex<TextRank>>`

### Unit Test Strategy

**Mockable Seams:**
1. **Algorithm Trait:** Create mock algorithms for testing
   - `MockAlgorithm` that returns fixed weights
   - Test `calculate()` with different algorithms

2. **Language Trait:** Create mock languages for testing
   - `MockLanguage` with custom stop words
   - Test `text_to_rank()` with different stop word lists

3. **Rule Trait:** Create mock rules for testing
   - `MockRule` with custom separators
   - Test `tokenize_text()` with different parsing rules

**Test Structure:**
```rust
// tests/textrank_test.rs
#[test]
fn test_on_single_thread() {
    let raw_text = "...";
    let mut tr = TextRank::new();
    let rule = RuleDefault::new();
    let language = LanguageDefault::new();
    let algorithm = AlgorithmDefault::new();
    
    tr.populate(raw_text, &language, &rule);
    tr.ranking(&algorithm);
    
    assert_the_gnome_test_text_default(&tr);
}

#[test]
fn test_on_multi_thread() {
    use std::sync::{Arc, Mutex};
    use std::sync::mpsc::channel;
    use std::thread;
    
    let (tx, rx) = channel();
    let tr = Arc::new(Mutex::new(TextRank::new()));
    
    // Spawn threads, send text via channel, populate + rank
    // ...
    
    let tr_locked = tr.lock().unwrap();
    assert_the_gnome_test_text_default(&tr_locked);
}

// tests/algorithm_test.rs
#[test]
fn test_weighting_relation() {
    let rank = create_rank();
    let def = AlgorithmDefault::new();
    let weight_def = def.weighting_relation(0, 1, &rank);
    assert_eq!(weight_def, 2.0);
    
    let chain = AlgorithmChain::new();
    let weight_chain = chain.weighting_relation(0, 1, &rank);
    assert_eq!(weight_chain, 2.01);
}
```

**Mock Example:**
```rust
// In tests/mocks.rs or inline
struct MockAlgorithm {
    fixed_weight: f32,
}

impl Algorithm for MockAlgorithm {
    fn weighting_hits(&self, _word_id: usize, _rank: &Rank) -> f32 {
        self.fixed_weight
    }
    
    fn weighting_relation(&self, _w1: usize, _w2: usize, _rank: &Rank) -> f32 {
        self.fixed_weight
    }
}
```

### Milestone Mapping

**Proposed Milestones (cumulative):**

1. **M0: Skeleton** - Compiles, no logic
   - All modules, structs, traits defined
   - Stub implementations (return default values)
   - No tests pass yet

2. **M1: Core Data Structures** - Rank, Word, Relation, Score
   - `Rank::new()`, `Rank::add_new_word()`, `Rank::update_word()`
   - `Relation::add_relation()`
   - Tests: `algorithm_test::create_rank()` helper works

3. **M2: Tokenization** - Text parsing
   - `tokenize_text()`, `find_words()`
   - `Text`, `ParsedSentence` structs
   - Tests: Tokenizer produces correct sentences/words

4. **M3: Graph Construction** - Builder
   - `text_to_rank()`, `add_word()`, `add_sentence()`
   - Language filtering (stop words)
   - Tests: Graph built correctly from text

5. **M4: Algorithms** - Weighting
   - `AlgorithmDefault`, `AlgorithmChain` implementations
   - Tests: `algorithm_test::test_weighting_relation()`, `test_weighting_hits()`

6. **M5: Ranking** - Weight calculation
   - `calculate()`, `normalize()`
   - Tests: Weights normalized to [0, 1]

7. **M6: Sorting/Querying** - Result extraction
   - `find_phrases()`, `find_single_words()`, `find_sentences()`
   - Tests: Results sorted correctly

8. **M7: TextRank Facade** - Public API
   - `TextRank` struct with all methods
   - Tests: `test_on_single_thread()` passes

9. **M8: Multi-threading** - Concurrency
   - Thread-safe access via `Arc<Mutex<T>>`
   - Tests: `test_on_multi_thread()` passes

10. **M9: Full Conformance** - All tests pass
    - All integration tests
    - All unit tests
    - Documentation examples

**Test Selectors (for validation):**
- `test_on_single_thread` - Main integration test
- `test_on_multi_thread` - Concurrency test
- `test_weighting_relation` - Algorithm test
- `test_weighting_hits` - Algorithm test

**Validation Command:**
```bash
cd pipeline/target && cargo test --manifest-path Cargo.toml
```

**Full Suite Gate:** All tests must pass (no specific selector needed).

---

## Summary

This analysis covers:

1. **Source Project Research:**
   - TextRank is a ~2,173-line Go library for text ranking
   - 11 main modules: textrank, rank, relation, algorithm, language, rule, tokenizer, builder, ranking, sorting, text
   - 3 interfaces (Algorithm, Language, Rule) for extensibility
   - No error handling, no external dependencies
   - Tests focus on integration (full workflow) with minimal unit tests

2. **Third-Party Library Analysis:**
   - All Go standard library → Rust standard library
   - `testify/assert` → Rust built-in assertions
   - No external crates required (optional: `crossbeam` for advanced concurrency)

3. **Target Project Design:**
   - 1:1 module mapping (Go files → Rust modules)
   - Public API preserves Go method names (snake_case)
   - Error handling: `Result`/`Option` for public APIs, panics for invariants
   - Thread safety: `&mut self` for mutation, `&self` for queries, `Arc<Mutex<T>>` for concurrency
   - Unit test strategy: Mock traits (Algorithm, Language, Rule) for isolated testing
   - 10 cumulative milestones from skeleton to full conformance

The translation is straightforward with no major architectural changes needed. The main challenges are:
- Rust ownership (use `&` and `&mut` appropriately)
- HashMap lookups (use `Option` and handle missing keys)
- Trait objects (`&dyn Trait` instead of Go interfaces)
- Concurrency (explicit `Arc<Mutex<T>>` instead of implicit goroutine safety)
