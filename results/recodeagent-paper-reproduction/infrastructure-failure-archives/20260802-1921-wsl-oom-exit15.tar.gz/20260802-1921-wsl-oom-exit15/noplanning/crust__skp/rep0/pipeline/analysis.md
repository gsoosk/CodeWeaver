# SKP C-to-Rust Translation Analysis

## 1. Source Project Research

### Overview

The **skp** library is a comprehensive text parsing library written in C that provides three levels of text processing functionality:

1. **Skipping Level**: Pattern-based text matching via the `skp_()` function
2. **Scanning Level**: Loop-based text scanning using `skp_loop_t` structures with conditional macros
3. **Parsing Level**: Full PEG (Parsing Expression Grammar) parser with AST construction, memoization, and left-recursion handling

The library implements a domain-specific pattern language for text matching, supports both UTF-8 and ISO-8859-1 encodings, and provides a macro-based DSL for defining parsers with automatic AST construction.

### Directory Structure and File Responsibilities

```
source/
├── src/
│   ├── skp.h          # Main header file (2153 lines) - entire library implementation
│   └── skp.c          # Minimal wrapper that includes skp.h with SKP_MAIN defined
├── test/
│   ├── ut_test1.c     # Unit tests for pattern matching (alternatives, quantifiers, character classes)
│   ├── ut_test2.c     # Unit tests for literal matching, case sensitivity, UTF-8, skip-to mode
│   └── ut_test3.c     # Unit tests for string alternatives with \xE separator
└── README.md          # Project documentation

```

**Key file: `skp.h`**
- Lines 1-100: Version info, includes, variadic macro helpers, core `skp_()` declaration
- Lines 100-657: Pattern matching implementation (character classes, `match()` function, `skp_()` implementation)
- Lines 658-1234: AST parsing macros and structures (`skpdef`, `skprule`, `skpmatch`, etc.)
- Lines 1235-2153: AST implementation functions (memoization, tree navigation, node manipulation)

The entire library is header-only; `skp.c` simply includes `skp.h` with `SKP_MAIN` defined to generate the implementation.

### Key Structures and Interfaces

#### Pattern Matching API

**Core function:**
```c
int skp_(const char *src, const char *pat, const char **to, const char **end);
```
- `src`: Source text to match against
- `pat`: Pattern string in skp pattern language
- `to`: Output pointer to matched text start
- `end`: Output pointer to matched text end
- Returns: Match code (0=no match, 1=match, 2-255=alternative index)

**Pattern Language Features:**

Character classes:
- `a` - alphabetic
- `d` - digit
- `x` - hexadecimal digit
- `w` - blank (space/tab)
- `s` - space (any whitespace)
- `n` - newline
- `l` - lowercase
- `u` - uppercase
- `p` - punctuation
- `c` - control character
- `g` - graphic character
- `v` - visible character
- `r` - printable character

Quantifiers:
- `*` - zero or more
- `+` - one or more
- `?` - optional (zero or one)
- `!` - negation

Special patterns:
- `I` - identifier (letter followed by letters/digits/underscores)
- `D` - decimal number
- `F` - floating-point number
- `X` - hexadecimal number
- `Q` - quoted string
- `B` - balanced parentheses

String literals:
- `'text'` - literal string match
- `'opt1\xEopt2\xEopt3'` - alternatives separated by `\xE`

Goals and flags:
- `&` - set goal (match must reach this point)
- `!&` - negative goal (match must not reach this point)
- `C` - case-sensitive mode
- `U` - UTF-8 mode
- `>` - skip-to mode (skip until pattern matches)

#### Scanning Loop API

**Structure:**
```c
typedef struct skp_loop_t {
    const char *src;    // Current position in source
    const char *to;     // Match start
    const char *end;    // Match end
    int code;           // Match code
} skp_loop_t;
```

**Macros:**
- `skpif(loop, pattern)` - Conditional match (like if)
- `skpelse(loop, pattern)` - Alternative match (like else if)
- `skpend(loop)` - End of conditional chain

#### AST Parsing API

**Core structures:**

```c
typedef struct ast_t {
    const char *src;           // Source text
    int *par;                  // Parenthesis array
    int npar;                  // Number of parentheses
    int cpar;                  // Capacity of par array
    struct ast_node_t *nodes;  // Node data array
    int nnodes;                // Number of nodes
    int cnodes;                // Capacity of nodes array
    struct ast_mmz_t *mmz;     // Memoization table
    int nmmz;                  // Number of memoization entries
    int cmmz;                  // Capacity of mmz array
    jmp_buf jmp;               // Error handling jump buffer
} ast_t;

typedef struct ast_node_t {
    const char *to;            // Node text start
    const char *end;           // Node text end
    int code;                  // Node type code
    int rule;                  // Rule index
} ast_node_t;

typedef struct ast_mmz_t {
    const char *src;           // Memoization key: source position
    int rule;                  // Memoization key: rule index
    int par;                   // Memoized result: parenthesis index
    int lr;                    // Left-recursion depth
} ast_mmz_t;
```

**Parser definition macros:**
- `skpdef(name, ...)` - Define a parser with rules
- `skprule(name, pattern)` - Define a parsing rule
- `skpmatch(ast, rule, ...)` - Match a rule and execute actions
- `skpnode(ast, code)` - Create an AST node
- `skpopen(ast)` - Open a parenthesis (start subtree)
- `skpclose(ast)` - Close a parenthesis (end subtree)

**AST representation:**

The AST uses a parenthesized tree representation with two parallel arrays:
- `par[]`: Parenthesis indices
  - Positive values: opening parenthesis (index into `nodes[]`)
  - Negative values: closing parenthesis (delta to matching opening)
- `nodes[]`: Node data (text range, code, rule)

Example: For tree `(a (b c) d)`:
```
par:   [0, 1, -1, -3]
nodes: [a, b, c, d]
```

### Data Models and Observable Output

The library's observable output consists of:

1. **Pattern matching results:**
   - Match code (integer 0-255)
   - Matched text range (two pointers: `to`, `end`)

2. **AST structure:**
   - Parenthesis array representing tree structure
   - Node array with text ranges and type codes
   - Accessible via navigation functions (`ast_child`, `ast_next`, `ast_parent`, etc.)

3. **Text extraction:**
   - Functions to extract text from AST nodes
   - Support for both null-terminated strings and length-based extraction

### Error Handling

The C implementation uses two error handling mechanisms:

1. **Pattern matching errors:**
   - Return value of 0 indicates no match
   - Invalid patterns may cause undefined behavior (no validation)

2. **AST parsing errors:**
   - Uses `setjmp`/`longjmp` for non-local control flow
   - `ast_t.jmp` buffer set up before parsing
   - Parse failures longjmp back to error handler
   - Memory allocation failures also use longjmp

3. **Memory management:**
   - Dynamic allocation for AST arrays (par, nodes, mmz)
   - Manual realloc-based growth strategy
   - No automatic cleanup (caller must free)

### Dependencies

The C implementation depends only on the standard library:

- `<stdio.h>` - Standard I/O (used in tests, not core library)
- `<stdlib.h>` - Memory allocation (malloc, realloc, free)
- `<string.h>` - String operations (strlen, memcpy, strcmp)
- `<ctype.h>` - Character classification (isalpha, isdigit, etc.)
- `<setjmp.h>` - Non-local jumps (setjmp, longjmp)
- `<assert.h>` - Assertions (used in tests)
- `<errno.h>` - Error codes
- `<stdbool.h>` - Boolean type
- `<inttypes.h>` - Fixed-width integer types
- `<limits.h>` - Numeric limits

No external dependencies are required.

### Unit Test Structure and Coverage

The source includes three unit test files that exercise different aspects of the library:

**ut_test1.c:**
- Tests pattern matching with alternatives (return codes \x02, \x03, \x04)
- Tests quantifiers (`?'12'`, `!'12'`, `!'23'`)
- Tests character classes (`D` for decimal, `I` for identifier, `a` for alpha)
- Tests pattern sequences (`'1'..a`)
- Uses `skptrace` macro for debug output
- Uses `skptest` macro for assertions

**ut_test2.c:**
- Tests literal `'&'` character matching
- Tests case-sensitive vs case-insensitive matching (`!C` flag)
- Tests UTF-8 character handling (è, ì)
- Tests skip-to mode (`>` prefix)

**ut_test3.c:**
- Tests string alternatives with `\xE` separator
- Tests pattern alternatives in quoted strings

**Test infrastructure:**
- `skptrace(...)` - Conditional debug output macro
- `skptest(cond)` - Assertion macro that prints failure and exits
- Tests are standalone executables (each has a `main()`)
- No mocking infrastructure (tests use real library functions)
- Tests verify exact return codes and pointer positions

## 2. Third-Party Library Analysis

### C Standard Library Dependencies

The C implementation uses only standard library facilities. For each, the Rust equivalent is:

| C Dependency | Usage in Source | Rust Equivalent | Notes |
|--------------|-----------------|-----------------|-------|
| `<stdlib.h>` malloc/realloc/free | Dynamic memory for AST arrays | `Vec<T>` | Rust's `Vec` provides automatic growth and RAII cleanup |
| `<string.h>` strlen, memcpy, strcmp | String operations | `str` methods, slices | Rust string slices are UTF-8 by default; use `as_bytes()` for byte operations |
| `<ctype.h>` isalpha, isdigit, etc. | Character classification | `char` methods | Rust's `char::is_alphabetic()`, `char::is_numeric()`, etc. |
| `<setjmp.h>` setjmp, longjmp | Error handling in parser | `Result<T, E>` or `panic!` | Rust uses Result for recoverable errors; panic for unrecoverable |
| `<stdbool.h>` bool, true, false | Boolean type | `bool` | Direct equivalent |
| `<inttypes.h>` int32_t, etc. | Fixed-width integers | `i32`, `u32`, etc. | Direct equivalent |
| `<limits.h>` INT_MAX, etc. | Numeric limits | `i32::MAX`, etc. | Direct equivalent |

### Scaffolding-Provided Infrastructure

The provided Rust scaffold at `scaffold/src/skp.rs` already provides:

1. **Complete function signatures** for all public API functions
2. **Type definitions** for `SkpLoop` (equivalent to `skp_loop_t`)
3. **Test infrastructure** with `skptrace!` and `skptest!` macros
4. **Test binaries** (`ut_test1.rs`, `ut_test2.rs`, `ut_test3.rs`) that mirror the C tests exactly

**No additional external dependencies are needed.** The scaffold uses only Rust's standard library.

### Recommended Approach

**Do NOT add any external crates.** The translation should use only:
- Rust standard library (`std`)
- The provided scaffold structure

The scaffold already provides the exact API contract that must be implemented. The translation task is to fill in the `unimplemented!()` stubs with working Rust code that matches the C behavior.

## 3. Target Project Design

### Overview and Translation Requirements

**Goal:** Translate the C skp library to Rust with exact behavioral equivalence, as verified by the provided unit tests.

**Functional equivalence criteria:**
- All three unit test binaries (`ut_test1`, `ut_test2`, `ut_test3`) must pass
- Pattern matching must return identical match codes and text ranges
- AST structure must be identical (same parenthesis/node arrays)
- Character classification must handle both ASCII and UTF-8 identically
- Error handling must preserve the same failure modes

**Constraints from project brief:**
- Conform to the provided scaffold interface (do not change public API)
- Do not modify the test binaries
- Use only Rust standard library (no external crates)

### Source-to-Target Structural Mapping

#### Module Structure

**C structure:**
```
source/src/
  skp.h          # Entire library (header-only)
  skp.c          # Wrapper that includes skp.h
```

**Rust structure (scaffold-provided):**
```
scaffold/
  Cargo.toml
  src/
    lib.rs       # Library entry point (re-exports from skp module)
    skp.rs       # Main implementation module (mirrors skp.h)
    bin/
      ut_test1.rs
      ut_test2.rs
      ut_test3.rs
```

**Mapping:**
- `skp.h` → `src/skp.rs` (all implementation goes here)
- `skp.c` → not needed (Rust doesn't need separate compilation unit)
- `test/ut_test*.c` → `src/bin/ut_test*.rs` (already provided in scaffold)

#### Identifier Naming Conventions

**Preserve C names where possible:**
- `skp_()` → `skp_()` (keep underscore suffix)
- `skp_loop_t` → `SkpLoop` (Rust struct naming convention)
- `ast_t` → `Ast` (Rust struct naming convention)
- `ast_node_t` → `AstNode`
- `ast_mmz_t` → `AstMmz`
- Function names: keep C names exactly (`ast_child`, `ast_next`, etc.)

**Pattern language:**
- Keep all pattern syntax identical (character classes, quantifiers, flags)
- Preserve return code semantics (0=no match, 1=match, 2-255=alternative)

#### Idiom Mappings

| C Idiom | Rust Equivalent | Notes |
|---------|-----------------|-------|
| `const char *` | `&str` | Rust string slices are UTF-8; use `as_bytes()` for byte access |
| `const char **to` (output param) | Return `&str` in tuple | Rust uses return values instead of output parameters |
| `malloc`/`realloc`/`free` | `Vec<T>` | Automatic growth and RAII cleanup |
| `setjmp`/`longjmp` | `Result<T, E>` or `panic!` | Use Result for recoverable errors, panic for abort |
| Pointer arithmetic (`src++`) | Slice indexing or iterators | Use `&s[i..]` or `s.chars()` |
| `NULL` | `None` (for `Option<T>`) | Rust uses Option for nullable values |
| Variadic macros | Rust macros | Use `macro_rules!` for pattern-based macros |
| `typedef struct` | `struct` | Rust structs don't need typedef |
| Global mutable state | `thread_local!` or different design | Avoid global mutables; use local state |

**Critical translation challenges:**

1. **String handling:**
   - C uses byte-oriented `const char *` with pointer arithmetic
   - Rust uses UTF-8 `&str` with slice operations
   - Need to handle both UTF-8 and ISO-8859-1 modes
   - Solution: Work with byte slices (`&[u8]`) internally, convert to `&str` for API

2. **Error handling:**
   - C uses `setjmp`/`longjmp` for parser errors
   - Rust should use `Result<T, E>` for recoverable errors
   - Solution: Internal functions return `Result`, top-level catches and converts to match code

3. **Macro translation:**
   - C uses heavy macro metaprogramming (`skpdef`, `skprule`, etc.)
   - Rust macros are more structured but powerful
   - Solution: Use `macro_rules!` with pattern matching; may need procedural macros for complex cases

4. **Memory management:**
   - C manually manages AST arrays with realloc
   - Rust uses `Vec` with automatic growth
   - Solution: Replace `par`/`nodes`/`mmz` arrays with `Vec<i32>`/`Vec<AstNode>`/`Vec<AstMmz>`

### Module Structure for Target Project

**src/lib.rs:**
```rust
pub mod skp;
pub use skp::*;
```

**src/skp.rs:** (main implementation, ~2000 lines)

Sections (mirroring skp.h structure):
1. **Constants and version info** (lines 1-20)
   - Version constants
   - Pattern syntax constants

2. **Core pattern matching** (lines 21-400)
   - Character classification helpers
   - Pattern parsing and matching logic
   - `skp_()` function implementation

3. **Scanning loop support** (lines 401-500)
   - `SkpLoop` struct
   - Helper functions for loop macros

4. **AST structures** (lines 501-700)
   - `Ast`, `AstNode`, `AstMmz` structs
   - AST creation and initialization

5. **AST parsing macros** (lines 701-1000)
   - `skpdef!`, `skprule!`, `skpmatch!` macros
   - Parser DSL implementation

6. **AST implementation** (lines 1001-2000)
   - Memoization logic
   - Tree navigation functions
   - Node manipulation functions
   - Text extraction functions

**src/bin/ut_test1.rs, ut_test2.rs, ut_test3.rs:**
- Already provided in scaffold
- Do not modify (read-only oracle)

### Output/Contract Mapping

The observable contract is defined by the unit tests. Each test verifies:

1. **Pattern matching contract:**
   - Input: source string, pattern string
   - Output: (match_code, matched_text_start, matched_text_end)
   - Verified by: `skptest!` macro assertions

2. **Text range contract:**
   - Matched text must be exact substring of source
   - Pointers (in C) / slices (in Rust) must point to correct positions
   - Verified by: comparing returned slices to expected substrings

3. **Match code contract:**
   - 0 = no match
   - 1 = match (default)
   - 2-255 = alternative index (for patterns with `\xE` separators)
   - Verified by: exact match code comparisons

4. **Character encoding contract:**
   - ASCII characters must work in both UTF-8 and ISO-8859-1 modes
   - UTF-8 multi-byte characters must work in UTF-8 mode
   - Verified by: ut_test2 with è, ì characters

### Boundary and Error-Handling Strategy

**Boundaries:**

1. **Public API boundary:**
   - All public functions in scaffold must be implemented
   - Signature: `fn skp_(src: &str, pat: &str) -> (i32, &str, &str)`
   - This is the only boundary; no external I/O or system calls

2. **Internal boundaries:**
   - Pattern parser (parses pattern string into internal representation)
   - Character classifier (determines if character matches class)
   - AST builder (constructs tree structure)

**Error handling strategy:**

1. **Pattern matching errors:**
   - Invalid patterns: return match code 0 (no match)
   - No validation of pattern syntax (matches C behavior)

2. **AST parsing errors:**
   - Parse failures: return from rule with failure indicator
   - Memory allocation: use `Vec` which panics on OOM (acceptable for this use case)
   - No `setjmp`/`longjmp` needed; use early returns or `Result` internally

3. **Memory safety:**
   - Rust's ownership system prevents use-after-free, double-free, buffer overflows
   - No unsafe code needed for core logic
   - May need `unsafe` for performance-critical byte operations (use sparingly)

### Unit Test Strategy

**Test structure:**

The scaffold provides three test binaries that mirror the C tests exactly:
- `ut_test1.rs` - pattern matching, alternatives, quantifiers, character classes
- `ut_test2.rs` - literals, case sensitivity, UTF-8, skip-to mode
- `ut_test3.rs` - string alternatives

**Test execution:**
- Each test is a standalone binary (not `#[test]` functions)
- Tests use `skptrace!` for debug output (controlled by environment variable)
- Tests use `skptest!` for assertions (exits with code 1 on failure)

**Mockable seams:**

The C tests do not use mocks (they test the real library). The Rust tests should follow the same approach:
- No mocking needed
- Tests call the real `skp_()` function
- Tests verify exact behavior against known inputs/outputs

**Test translation:**

The scaffold already provides translated tests. No additional test translation is needed. The implementation must make these tests pass.

**Unit test coverage:**

The three test binaries cover:
1. **Pattern syntax:**
   - Alternatives (`\x02`, `\x03`, `\x04` return codes)
   - Quantifiers (`?`, `!`, `*`, `+`)
   - Character classes (`a`, `d`, `D`, `I`)
   - Sequences (`'1'..a`)

2. **Encoding and case sensitivity:**
   - Literal matching (`'&'`)
   - Case-insensitive mode (`!C`)
   - UTF-8 characters (è, ì)
   - Skip-to mode (`>`)

3. **String alternatives:**
   - Multiple alternatives with `\xE` separator
   - Pattern alternatives in quoted strings

**Additional testing:**

The AST parsing functionality is not covered by the provided unit tests. The implementation should:
- Implement AST functions to match the C behavior
- Verify correctness by manual testing or additional tests (not required for milestone completion)

### Milestone Mapping

**Milestone 1: Core Pattern Matching**
- Implement `skp_()` function
- Implement character classification
- Implement pattern parsing and matching
- Support: literals, character classes, quantifiers, alternatives, goals, flags
- **Tests:** ut_test1, ut_test2, ut_test3 should all pass
- **Source coverage:** skp.h lines 100-657

**Milestone 2: Scanning Loop Support**
- Implement `SkpLoop` struct and helpers
- Implement loop macros (`skpif!`, `skpelse!`, `skpend!`)
- **Tests:** No dedicated tests (used by higher-level code)
- **Source coverage:** skp.h lines 658-800 (loop-related code)

**Milestone 3: AST Parsing**
- Implement `Ast`, `AstNode`, `AstMmz` structs
- Implement AST creation and initialization
- Implement memoization logic
- Implement tree navigation functions
- Implement parser definition macros
- **Tests:** No unit tests provided (AST is for advanced use cases)
- **Source coverage:** skp.h lines 800-2153

**Milestone completion criteria:**

Each milestone is complete when:
1. All relevant unit tests pass (for M1)
2. Code compiles without warnings
3. No unsafe code unless absolutely necessary (document why)
4. Code follows Rust idioms (ownership, borrowing, error handling)

**Recommended implementation order:**

1. Start with Milestone 1 (core pattern matching)
   - This is the foundation and has the most test coverage
   - Get all three test binaries passing

2. Then Milestone 2 (scanning loops)
   - Builds on pattern matching
   - Needed for some advanced use cases

3. Finally Milestone 3 (AST parsing)
   - Most complex, least tested
   - Can be deferred if time-constrained

**Source test mapping:**

| C Test | Rust Test | Functionality Tested | Milestone |
|--------|-----------|---------------------|-----------|
| ut_test1.c | ut_test1.rs | Alternatives, quantifiers, character classes, sequences | M1 |
| ut_test2.c | ut_test2.rs | Literals, case sensitivity, UTF-8, skip-to mode | M1 |
| ut_test3.c | ut_test3.rs | String alternatives with \xE separator | M1 |

All provided tests map to Milestone 1. Milestones 2 and 3 have no dedicated unit tests but are needed for completeness.

---

## Summary

This analysis document provides the authoritative design for translating the C skp library to Rust. The three sections cover:

1. **Source Project Research:** Comprehensive analysis of the C implementation, including its three-level architecture (skipping, scanning, parsing), pattern language, AST representation, error handling, and unit test structure.

2. **Third-Party Library Analysis:** Identification of C standard library dependencies and their Rust equivalents. Confirmation that the provided scaffold already supplies all needed infrastructure, requiring no external crates.

3. **Target Project Design:** Detailed structural mapping from C to Rust, including module organization, identifier naming, idiom translations, error handling strategy, unit test approach, and a three-milestone implementation plan focused on (1) core pattern matching, (2) scanning loops, and (3) AST parsing.

The design preserves the source structure and naming where sensible, uses idiomatic Rust constructs (Vec, Result, slices), and defines success as passing all three provided unit test binaries.
