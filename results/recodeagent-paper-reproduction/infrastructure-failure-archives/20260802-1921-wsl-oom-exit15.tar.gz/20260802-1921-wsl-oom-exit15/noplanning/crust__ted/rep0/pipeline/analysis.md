# Ted Editor - C to Rust Translation Analysis

## 1. Source Project Research

### Overview
Ted is a terminal-based text editor written in C that implements a gap buffer data structure for efficient text editing. The project consists of two main layers:
1. **Buffer Layer** (`buffer/`): Core data structures for text manipulation
2. **Application Layer** (`app/`): Terminal UI, input handling, and editor state management

The editor supports basic text editing operations (insert, delete, newline), cursor navigation (arrow keys), file loading/saving, and displays a status line showing file name, cursor position, and modification status.

### Directory Structure and File Responsibilities

```
source/
├── buffer/
│   ├── gap.h           # GapBuffer interface definition
│   ├── gap.c           # GapBuffer implementation (single-line editing)
│   ├── buffer.h        # TextBuffer interface definition
│   └── buffer.c        # TextBuffer implementation (multi-line document)
├── app/
│   ├── defs.h          # ANSI escape codes, macros, panic function
│   ├── visual.c        # Screen rendering logic (VirtualScreen)
│   └── main.c          # Main editor loop, terminal setup, input processing
└── tests/
    ├── runtests.c      # Unit tests for GapBuffer and TextBuffer
    └── runtests.txt    # Test data file (3 lines: 11, 10, 9 'a' characters)
```

**File Responsibilities:**

- **gap.c/h**: Implements the gap buffer data structure, a character array with a movable "gap" that allows efficient insertion/deletion at the cursor position. Provides operations: create, destroy, insert_char, backspace, move_gap, get_string, split, create_from_string, char_at.

- **buffer.c/h**: Implements TextBuffer, an array of GapBuffer pointers representing lines in a document. Manages cursor position (row, col), line array resizing, and multi-line operations. Provides: create, destroy, move_cursor, insert, backspace, new_line, get_line, create_from_file.

- **visual.c**: Implements VirtualScreen for rendering the editor window. Handles line wrapping, scrolling (render_start_line), and virtual cursor positioning. Functions: screen_append, required_screen_rows, move_cursor_in_view, draw_editor_window, set_virtual_cursor_position.

- **main.c**: Contains EditorState (global state), terminal setup (raw mode via termios), main event loop, input processing (read_char, process_keypress), arrow key handlers, file I/O (load_file_and_initialize_buffer, flush_buffer_to_file), screen rendering (draw_screen, draw_status_line).

- **defs.h**: Defines ANSI escape codes (ESC, INVERT_COLOUR, RESET_STYLE_COLOUR), CTRL_KEY macro, and panic function.

### Key Structures and Interfaces

#### GapBuffer (gap.h)
```c
typedef struct GapBuffer {
    char* buffer;   // Heap-allocated character array
    int str_len;    // Length of the string (excluding gap)
    int gap_len;    // Length of the gap
    int gap_loc;    // Gap location (offset from buffer start)
} GapBuffer;
```

**API Surface:**
- `GapBuffer* CreateGapBuffer(int capacity)` - Returns NULL on failure
- `void DestroyGapBuffer(GapBuffer* instance)` - Frees memory
- `int GapBufferInsertChar(GapBuffer* instance, char ch)` - Returns 0 or MEM_ERROR (128)
- `void GapBufferBackSpace(GapBuffer* instance)` - No-op if gap_loc == 0
- `int GapBufferMoveGap(GapBuffer* instance, int location)` - Clamps location to [0, str_len]
- `char* GapBufferGetString(GapBuffer* instance)` - Returns heap-allocated null-terminated string
- `GapBuffer* GapBufferSplit(GapBuffer* instance)` - Splits at gap, returns second half
- `GapBuffer* CreateGapBufferFromString(char* str, int gap_len)` - Gap positioned at end
- `char GapBufferCharAt(GapBuffer* instance, int i)` - Returns '\0' on invalid input

#### TextBuffer (buffer.h)
```c
typedef struct TextBuffer {
    GapBuffer** lines;      // Array of GapBuffer pointers
    int lines_capacity;     // Size of lines array
    int cursorRow;          // Current cursor row
    int cursorCol;          // Current cursor column
    int cursorColMoved;     // Flag: gap needs repositioning before insert
    int last_line_loc;      // Index of last line (also line count)
} TextBuffer;
```

**API Surface:**
- `TextBuffer* CreateTextBuffer(int lines, int line_size)` - Returns NULL on failure
- `void DestroyTextBuffer(TextBuffer* instance)` - Frees all lines and structure
- `void TextBufferMoveCursor(TextBuffer* instance, int row, int col)` - Clamps to valid positions
- `int TextBufferInsert(TextBuffer* instance, char ch)` - Returns 0 or MEM_ERROR
- `int TextBufferBackspace(TextBuffer* instance)` - Returns 0 or MEM_ERROR
- `int TextBufferNewLine(TextBuffer* instance)` - Splits line, shifts array, returns 0 or MEM_ERROR
- `char* TextBufferGetLine(TextBuffer* instance, int row)` - Returns heap-allocated string or NULL
- `TextBuffer* CreateTextBufferFromFile(FILE* fp)` - Reads file line-by-line, NULL on error

#### VirtualScreen (visual.c)
```c
struct VirtualScreen {
    char* buffer;           // Heap-allocated screen buffer (escape codes + text)
    int buf_pos;            // Current write position
    int len;                // Buffer capacity
    Cursor cursor;          // Virtual cursor position (x=row, y=col)
    int width;              // Terminal width
    int height;             // Terminal height
    int render_start_line;  // First line to render (for scrolling)
};

typedef struct Cursor {
    int x;  // Row (1-indexed for ANSI escape codes)
    int y;  // Column (1-indexed)
} Cursor;
```

**Functions:**
- `void screen_append(const char* str, int size)` - Appends to screen buffer
- `int required_screen_rows(int line_length, int screen_width)` - Calculates wrapped line height
- `void move_cursor_in_view(TextBuffer* buffer, VirtualScreen* screen)` - Adjusts render_start_line
- `void draw_editor_window(TextBuffer* buffer, VirtualScreen* screen)` - Renders visible lines
- `void set_virtual_cursor_position(TextBuffer* buffer, VirtualScreen* screen)` - Maps buffer cursor to screen coordinates

#### EditorState (main.c)
```c
struct EditorState {
    struct termios orig_termios;  // Original terminal settings
    char* file_name;              // Basename of file
    char* file_path;              // Full path or "Empty Buffer"
    bool flushed;                 // True if buffer saved to disk
    TextBuffer* current_buffer;   // The document
    struct VirtualScreen screen;  // Rendering state
};
```

### Data Models and Observable Output

**Observable Output Contract:**
1. **Unit Tests** (`tests/runtests.c`): The test oracle validates:
   - GapBuffer operations produce expected strings
   - TextBuffer operations produce expected line contents
   - File loading correctly parses `tests/runtests.txt` (3 lines)
   - Memory management (no leaks, proper cleanup)

2. **Interactive Editor** (main binary):
   - Terminal screen rendering (ANSI escape codes)
   - Status line format: `[filename | row,col changed? Ctrl+Q-quit Ctrl+S-Save]`
   - File I/O: reads/writes text files line-by-line (newlines stripped on read, not written on save in current implementation - bug)
   - Keyboard input: arrow keys, backspace, Ctrl+Q (quit), Ctrl+S (save), printable characters

**Data Invariants:**
- GapBuffer: `buffer` capacity = `str_len + gap_len`, gap always within bounds
- TextBuffer: `lines[0..last_line_loc]` are non-NULL, `lines[last_line_loc+1..]` are NULL
- Cursor: `0 <= cursorRow <= last_line_loc`, `0 <= cursorCol <= lines[cursorRow]->str_len`

### Error Handling

**C Source Approach:**
1. **Memory Allocation Failures**: Functions return NULL (for pointers) or MEM_ERROR (128) for int-returning functions
2. **File I/O Errors**: `load_file_and_initialize_buffer` returns -1 (file open failed) or MEM_ERROR
3. **Panic**: `panic(const char* message)` clears screen, calls `perror()`, exits with code 1
4. **Bounds Checking**: Cursor movement clamps to valid ranges; out-of-bounds access returns NULL or '\0'
5. **No Recovery**: Most errors are fatal (panic) or silently ignored (e.g., backspace at position 0)

**Error Propagation:**
- `GapBufferInsertChar` → `TextBufferInsert` → `process_keypress` (error ignored)
- `TextBufferNewLine` → `process_keypress` (error ignored)
- File operations return error codes but are not always checked

### Dependencies

**C Standard Library:**
- `<stdlib.h>`: malloc, free, realloc, exit
- `<string.h>`: memcpy, memmove, strlen, strcmp
- `<stdio.h>`: FILE, fopen, fclose, getline, fputs, printf, perror, sprintf, snprintf
- `<unistd.h>`: read, write, STDIN_FILENO, STDOUT_FILENO
- `<termios.h>`: struct termios, tcgetattr, tcsetattr, TCSAFLUSH
- `<sys/ioctl.h>`: ioctl, TIOCGWINSZ, struct winsize
- `<sys/errno.h>`: EAGAIN
- `<stdbool.h>`: bool, true, false
- `<libgen.h>`: basename
- `<assert.h>`: assert (tests only)

**No External Libraries**: The project uses only POSIX/C standard library functions.

### Unit Tests and Mocking Strategy

**Test Structure** (`tests/runtests.c`):
- **TestGapBuffer()**: 7 test cases covering create, insert, backspace, move_gap, split, create_from_string
- **TestTextBuffer()**: 5 test cases covering create, insert, backspace, move_cursor, new_line, create_from_file
- **Test Data**: `tests/runtests.txt` contains 3 lines (11, 10, 9 'a' characters)
- **Assertions**: Uses `assert()` and custom `string_comp_assert()` (compares strings, frees first arg)

**Mocking Boundaries:**
- **No Mocks in C Tests**: Tests use real implementations; file I/O uses actual test file
- **Isolation**: GapBuffer tests are independent of TextBuffer; TextBuffer tests depend on GapBuffer
- **Cleanup**: Tests explicitly call `DestroyGapBuffer` and `DestroyTextBuffer`

**Test Coverage:**
- Buffer layer: Comprehensive (all public functions tested)
- Application layer: No unit tests (only manual testing of interactive editor)

---

## 2. Third-Party Library Analysis

### C Dependencies and Rust Equivalents

#### Standard Library Functions

| C Dependency | Usage in Source | Rust Equivalent | Notes |
|--------------|-----------------|-----------------|-------|
| `malloc/free/realloc` | Manual memory management | `Vec<T>`, `String`, `Box<T>` | Rust's ownership system eliminates manual free; Vec handles resizing |
| `memcpy/memmove` | Buffer copying in gap operations | `Vec::copy_from_slice`, slice operations | Rust slices provide safe copying |
| `strlen/strcmp` | String operations | `str::len()`, `==` operator | Rust strings are UTF-8, not null-terminated |
| `FILE*/fopen/fclose` | File I/O | `std::fs::File` | Provided by Rust standard library |
| `getline` | Reading lines from file | `BufRead::read_line` | Rust's `BufReader` provides buffered line reading |
| `fputs` | Writing to file | `Write::write_all` | Rust's `Write` trait |
| `printf/sprintf/snprintf` | Formatting | `println!`, `format!`, `write!` | Rust macros |
| `termios` | Terminal control | **`termios` crate (0.3)** | **Already in scaffold Cargo.toml** |
| `ioctl/TIOCGWINSZ` | Window size detection | `termios` crate or `libc` | Covered by termios crate |
| `read/write` (POSIX) | Raw I/O | `std::io::Read`, `std::io::Write` | Rust standard library |
| `basename` | Path manipulation | `std::path::Path::file_name()` | Rust standard library |
| `assert` | Testing | `assert!`, `assert_eq!` | Rust macros |

#### Provided Scaffolding

**Cargo.toml** already includes:
```toml
[dependencies]
termios="0.3"
```

**Scaffolding Modules** (all functions marked `unimplemented!()`):
- `src/gap.rs`: GapBuffer struct and methods (matches C API)
- `src/buffer.rs`: TextBuffer struct and methods (matches C API)
- `src/defs.rs`: Constants and panic function
- `src/visual.rs`: VirtualScreen and rendering functions
- `src/main.rs`: EditorState and main loop
- `src/lib.rs`: Module declarations
- `src/bin/runtests.rs`: Test harness (mirrors C tests)

**DO NOT ADD NEW DEPENDENCIES**: All required functionality is covered by:
1. Rust standard library (`std::fs`, `std::io`, `std::path`, `std::vec`, `std::string`)
2. `termios` crate (already provided)

---

## 3. Target Project Design

### Overview and Translation Requirements

**Functional Equivalence:**
- The Rust port must pass the unit tests in `src/bin/runtests.rs` (mirrors `tests/runtests.c`)
- The main editor binary must exhibit the same interactive behavior (terminal rendering, input handling, file I/O)
- Correctness is judged by `cargo test` (unit tests) and `cargo build` (compilation)

**Constraints from Brief:**
- **Immutable Scaffold**: Do not modify the public interface in `scaffold/src/*.rs`
- **Preserve Structure**: Mirror the C source's module layout (gap, buffer, visual, main)
- **No New Dependencies**: Use only Rust std and the provided `termios` crate

### Source → Target Structural Mapping

#### Module Structure
```
C Source                    Rust Target
--------                    -----------
buffer/gap.h + gap.c    →   src/gap.rs
buffer/buffer.h + buffer.c → src/buffer.rs
app/defs.h              →   src/defs.rs
app/visual.c            →   src/visual.rs
app/main.c              →   src/main.rs
tests/runtests.c        →   src/bin/runtests.rs (already provided)
                            src/lib.rs (module declarations)
```

#### Type Mappings

| C Type | Rust Type | Notes |
|--------|-----------|-------|
| `char*` (heap string) | `String` | Owned, UTF-8, growable |
| `char*` (buffer) | `Vec<char>` | GapBuffer uses char array, not bytes |
| `int` | `i32` | Signed 32-bit integer |
| `size_t` | `usize` | Platform-dependent unsigned integer |
| `bool` | `bool` | Native Rust type |
| `GapBuffer*` | `GapBuffer` (owned) or `&GapBuffer` (borrowed) | No pointers; use ownership |
| `GapBuffer**` (array) | `Vec<Option<GapBuffer>>` | NULL pointers → None |
| `FILE*` | `&std::fs::File` | Borrowed reference |
| `struct termios` | `termios::Termios` | From termios crate |
| `NULL` | `None` (for Option<T>) | Rust's null representation |
| Return NULL | Return `Option<T>` | `None` for failure |
| Return MEM_ERROR | Return `i32` (128) | Keep error code for API compatibility |

#### Identifier Naming Conventions

**C → Rust Naming:**
- `CreateGapBuffer` → `GapBuffer::create` (associated function)
- `DestroyGapBuffer` → `GapBuffer::destroy` (consumes self) or rely on Drop trait
- `GapBufferInsertChar` → `GapBuffer::insert_char` (method)
- `TextBufferMoveCursor` → `TextBuffer::move_cursor` (method)
- `snake_case` for functions/variables (already Rust convention)
- `PascalCase` for types (already Rust convention)

**Preserve Field Names:**
- `buffer`, `str_len`, `gap_len`, `gap_loc` (GapBuffer)
- `lines`, `lines_capacity`, `cursor_row`, `cursor_col`, `cursor_col_moved`, `last_line_loc` (TextBuffer)
- Match scaffold's public fields exactly

### Idiom Mappings

#### Memory Management
- **C**: Manual `malloc/free`, NULL checks, memory leaks possible
- **Rust**: Ownership, `Vec<T>` auto-resizes, `Drop` trait for cleanup
- **Strategy**: 
  - `GapBuffer::buffer` → `Vec<char>` (auto-managed)
  - `TextBuffer::lines` → `Vec<Option<GapBuffer>>` (None = NULL)
  - `destroy` methods consume `self` (move semantics), but scaffold uses `self` so implement as no-op (Drop handles cleanup)

#### Error Handling
- **C**: Return NULL or MEM_ERROR, panic on fatal errors
- **Rust**: 
  - `Option<T>` for nullable returns (e.g., `TextBuffer::create` → `Option<TextBuffer>`)
  - `i32` return codes for compatibility (0 = success, 128 = MEM_ERROR)
  - `panic!()` for fatal errors (matches C's `panic()`)
- **Strategy**: Match scaffold signatures exactly; use `Option` where C returns NULL pointers

#### String Handling
- **C**: Null-terminated `char*`, manual length tracking
- **Rust**: `String` (UTF-8, length-prefixed), `Vec<char>` for character arrays
- **Strategy**: 
  - GapBuffer stores `Vec<char>` (not `Vec<u8>`) to match C's character semantics
  - `get_string()` returns `String` (heap-allocated, like C's malloc'd string)
  - No null terminators needed

#### Concurrency
- **C**: Single-threaded, global `editor_state`
- **Rust**: Single-threaded (no changes needed)
- **Strategy**: Keep global state in `main.rs` (Rust allows mutable statics with `unsafe`, but prefer local variables passed to functions)

### Module Structure for Target Project

```
src/
├── lib.rs              # Module declarations (pub mod gap, buffer, defs, visual)
├── gap.rs              # GapBuffer implementation
├── buffer.rs           # TextBuffer implementation
├── defs.rs             # Constants, panic function
├── visual.rs           # VirtualScreen, rendering functions
├── main.rs             # EditorState, main loop, terminal setup
└── bin/
    └── runtests.rs     # Unit tests (provided, mirrors C tests)
```

**Public API** (from scaffold):
- `gap.rs`: `GapBuffer` struct (public fields), methods: `create`, `destroy`, `insert_char`, `backspace`, `move_gap`, `get_string`, `split`, `create_from_string`, `char_at`
- `buffer.rs`: `TextBuffer` struct (public fields), methods: `create`, `destroy`, `move_cursor`, `insert`, `backspace`, `new_line`, `get_line`, `create_from_file`
- `defs.rs`: Constants (`ESC`, `INVERT_COLOUR`, etc.), `panic` function
- `visual.rs`: `VirtualScreen`, `Cursor` structs, methods: `screen_append`, `required_screen_rows`, `move_cursor_in_view`, `draw_editor_window`, `set_virtual_cursor_position`
- `main.rs`: `EditorState` struct, methods for terminal control, input handling, rendering

### Output/Contract Mapping

**Unit Test Oracle** (`src/bin/runtests.rs`):
- **Milestone 1**: GapBuffer tests pass (create, insert, backspace, move_gap, split, create_from_string, char_at)
- **Milestone 2**: TextBuffer tests pass (create, insert, backspace, move_cursor, new_line, get_line)
- **Milestone 3**: File loading test passes (create_from_file with `tests/runtests.txt`)

**Interactive Editor Oracle** (manual testing):
- **Milestone 4**: Editor launches, displays file, handles arrow keys, insert/backspace
- **Milestone 5**: Save (Ctrl+S) and quit (Ctrl+Q) work correctly

**Test Execution:**
- `cargo test` runs `src/bin/runtests.rs` (unit tests)
- `cargo build` compiles the main editor binary
- `cargo run <file>` launches the interactive editor

### Boundary and Error-Handling Strategy

**High-Level Boundaries:**
1. **File I/O**: `std::fs::File`, `BufReader` for reading, `Write` for writing
2. **Terminal Control**: `termios` crate for raw mode, `ioctl` for window size
3. **Standard I/O**: `std::io::stdin()`, `std::io::stdout()` for read/write

**Error Handling:**
- **Memory Allocation**: Rust's `Vec` panics on OOM (matches C's undefined behavior); return MEM_ERROR (128) only for API compatibility where C does
- **File Errors**: Return `None` (for `Option<TextBuffer>`) or -1 (for `i32`) to match C behavior
- **Terminal Errors**: Call `panic!()` with error message (matches C's `panic()`)
- **Bounds Checking**: Clamp cursor positions, return '\0' or `None` for invalid indices

**Scaffolding Calls:**
- No high-level scaffolding to replace; all functionality implemented from scratch
- Use `termios` crate for terminal control (already in Cargo.toml)

### Unit-Test Strategy

**Mockable Seams:**
- **File I/O**: Tests use real file (`tests/runtests.txt`), no mocking needed
- **Terminal I/O**: Unit tests don't test interactive editor (only buffer layer)
- **Isolation**: GapBuffer tests are independent; TextBuffer tests depend on GapBuffer

**Test Structure** (from `src/bin/runtests.rs`):
- `test_gap_buffer()`: Mirrors C's `TestGapBuffer()` (7 test cases)
- `test_text_buffer()`: Mirrors C's `TestTextBuffer()` (5 test cases, file test commented out initially)
- **No Mocks**: Use real implementations, real file I/O

**Test Data:**
- `tests/runtests.txt`: 3 lines (11, 10, 9 'a' characters) - **must be copied to target project**

**Test Execution:**
- `cargo test` runs all `#[test]` functions in `src/bin/runtests.rs`
- Tests use `assert_eq!` and custom `string_comp_assert` helper

**Coverage:**
- **Milestone 1**: GapBuffer tests (all operations)
- **Milestone 2**: TextBuffer tests (basic operations)
- **Milestone 3**: File loading test (uncomment in runtests.rs)
- **Milestone 4-5**: Manual testing of interactive editor (no automated tests)

### Milestone Mapping

**Milestone 1: GapBuffer Implementation**
- **Source Functionality**: `buffer/gap.c` (all functions)
- **Target Module**: `src/gap.rs`
- **Unit Tests**: `test_gap_buffer()` in `src/bin/runtests.rs`
- **Validation**: `cargo test` passes GapBuffer tests
- **Deliverables**: 
  - `GapBuffer::create`, `destroy`, `insert_char`, `backspace`, `move_gap`, `get_string`, `split`, `create_from_string`, `char_at`
  - Internal helper: `resize_buffer` (private function)

**Milestone 2: TextBuffer Implementation**
- **Source Functionality**: `buffer/buffer.c` (basic operations, excluding file I/O)
- **Target Module**: `src/buffer.rs`
- **Unit Tests**: `test_text_buffer()` (first 4 test cases)
- **Validation**: `cargo test` passes TextBuffer tests (except file loading)
- **Deliverables**:
  - `TextBuffer::create`, `destroy`, `move_cursor`, `insert`, `backspace`, `new_line`, `get_line`

**Milestone 3: File I/O**
- **Source Functionality**: `CreateTextBufferFromFile` in `buffer/buffer.c`
- **Target Module**: `src/buffer.rs` (add `create_from_file`)
- **Unit Tests**: Uncomment file loading test in `test_text_buffer()`
- **Validation**: `cargo test` passes all tests
- **Deliverables**:
  - `TextBuffer::create_from_file`
  - Copy `tests/runtests.txt` to target project

**Milestone 4: Visual Layer and Terminal Setup**
- **Source Functionality**: `app/visual.c`, `app/defs.h`, terminal setup in `app/main.c`
- **Target Modules**: `src/visual.rs`, `src/defs.rs`, partial `src/main.rs`
- **Unit Tests**: None (manual testing)
- **Validation**: `cargo build` succeeds
- **Deliverables**:
  - `defs::panic`, constants
  - `VirtualScreen::screen_append`, `required_screen_rows`, `move_cursor_in_view`, `draw_editor_window`, `set_virtual_cursor_position`
  - `EditorState::initialize`, `cleanup`, `set_window_size`, `enable_raw_mode`, `disable_raw_mode`

**Milestone 5: Main Editor Loop and Input Handling**
- **Source Functionality**: Main loop, input processing, file I/O in `app/main.c`
- **Target Module**: `src/main.rs` (complete implementation)
- **Unit Tests**: None (manual testing)
- **Validation**: `cargo run <file>` launches editor, basic editing works
- **Deliverables**:
  - `EditorState::render_screen`, `draw_screen`, `draw_status_line`
  - `EditorState::read_char`, `process_keypress`
  - Arrow key handlers: `up_arrow`, `down_arrow`, `left_arrow`, `right_arrow`
  - File operations: `load_file_and_initialize_buffer`, `flush_buffer_to_file`
  - Main loop in `main()`

**Milestone 6: Polish and Full Validation**
- **Source Functionality**: Bug fixes, edge cases
- **Target Modules**: All modules
- **Unit Tests**: All tests pass
- **Validation**: `cargo test && cargo build` succeeds, manual testing confirms full functionality
- **Deliverables**:
  - Fix any failing tests
  - Ensure file save writes newlines correctly (C version has bug)
  - Verify memory safety (no panics, no leaks)

---

## Summary

This analysis provides a complete blueprint for translating the Ted editor from C to Rust:

1. **Source Research**: Identified a two-layer architecture (buffer + application), documented all data structures, APIs, and test coverage. The C source uses manual memory management, POSIX file I/O, and termios for terminal control.

2. **Library Analysis**: All C dependencies map to Rust standard library or the provided `termios` crate. No new dependencies needed. The scaffold already provides the correct structure and API signatures.

3. **Target Design**: Defined a 1:1 structural mapping (gap.c → gap.rs, buffer.c → buffer.rs, etc.), idiom mappings (malloc → Vec, NULL → Option, char* → String/Vec<char>), and a 6-milestone plan that incrementally builds the port, validated by unit tests at each stage.

The translation preserves the source's architecture and naming while leveraging Rust's ownership system for memory safety. The unit tests in `src/bin/runtests.rs` serve as the oracle for correctness, mirroring the C tests exactly.
