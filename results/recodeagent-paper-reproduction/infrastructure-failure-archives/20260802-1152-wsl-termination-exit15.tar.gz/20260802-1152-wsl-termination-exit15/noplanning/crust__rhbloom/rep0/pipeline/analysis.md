# rhbloom: C to Rust Translation Analysis

## 1. Source Project Research

### Overview
**rhbloom** is a Robin Hood Bloom filter implementation in C that provides a space-efficient probabilistic data structure for membership testing. The key innovation is that it starts as a Robin Hood hash table and dynamically upgrades to a full Bloom filter when the hash table reaches a size threshold, optimizing memory usage for smaller datasets while maintaining the probabilistic guarantees of a Bloom filter for larger ones.

**Core functionality:**
- Add 64-bit keys to the filter
- Test whether keys probably exist (with configurable false-positive rate)
- Dynamic growth from hash table to Bloom filter
- Clear entries without deallocating memory
- Query memory usage and upgrade status

### Directory Structure and File Responsibilities

```
source/
├── rhbloom.h          # Public API header (8 functions, 1 opaque struct)
├── rhbloom.c          # Core implementation (266 lines)
├── test.c             # Unit tests and benchmarks (205 lines)
├── README.md          # Documentation and usage examples
├── LICENSE            # MIT license
├── makefile           # Build configuration
└── coverage_report.json  # Test coverage metadata
```

**rhbloom.h** - Public API surface:
- `struct rhbloom` - Opaque filter handle
- `rhbloom_new(n, p)` - Create filter for n items with false-positive rate p
- `rhbloom_new_with_allocator(n, p, malloc, free)` - Create with custom allocator
- `rhbloom_free(rhbloom)` - Deallocate filter
- `rhbloom_clear(rhbloom)` - Reset filter without freeing memory
- `rhbloom_add(rhbloom, key)` - Add key, returns false on OOM
- `rhbloom_test(rhbloom, key)` - Test membership, returns true if probably present
- `rhbloom_memsize(rhbloom)` - Get memory footprint in bytes
- `rhbloom_upgraded(rhbloom)` - Check if upgraded to Bloom filter

**rhbloom.c** - Implementation details:
- `struct rhbloom` internal fields:
  - Custom allocator function pointers (`malloc`, `free`)
  - Robin Hood hash table state: `count`, `nbuckets`, `buckets` (array of uint64)
  - Bloom filter state: `k` (bits per key), `m` (total bits), `bits` (bit array)
- Key encoding macros: `RHBLOOM_KEY`, `RHBLOOM_DIB`, `RHBLOOM_SETKEYDIB` pack 56-bit key + 8-bit DIB (distance-to-initial-bucket) into uint64
- `rhbloom_mix(key)` - Hash function using mix13 algorithm
- `rhbloom_testadd(rhbloom, key, add)` - Unified Bloom filter test/add logic
- `rhbloom_addkey(rhbloom, key)` - Robin Hood hash table insertion
- `rhbloom_grow(rhbloom)` - Resize hash table or upgrade to Bloom filter
- Upgrade trigger: when `nbuckets * 8 >= m >> 3` (hash table size approaches Bloom filter size)

**test.c** - Test suite:
- `murmurhash2()` - Hash function for test data generation (not part of rhbloom API)
- `hash(int)` - Wrapper to hash integers for test keys
- `test()` - Comprehensive unit tests:
  - Tests n=0 to 100,000 in steps of 1,000
  - Tests p=0.01 to 0.70 in steps of 0.05
  - Validates upgrade occurs, all added keys are found, false-positive rate ≤ p+0.1
  - Tests `rhbloom_clear()` by running test_step twice per filter
- `bench()` - Performance benchmarks with configurable N and P
- `test_step()` - Core test logic: add nn keys, verify upgrade, check hits, validate false-positive rate

### Key Structures and API Surface

**Data Model:**
- **Input:** 64-bit unsigned integer keys (typically pre-hashed)
- **Output:** Boolean membership test results (probabilistic)
- **State transitions:**
  1. Empty → Robin Hood hash table (initial state)
  2. Hash table grows by doubling `nbuckets` when 50% full
  3. Hash table → Bloom filter when `nbuckets * 8 >= m >> 3`
  4. Bloom filter never shrinks or reverts

**Key Algorithms:**

1. **Bloom filter sizing (lines 44-54):**
   - Calculate optimal bits: `m = n * log(p) / log(1 / pow(2, log(2)))`
   - Calculate bits per key: `k = round((m / n) * log(2))`
   - Round m to next power of 2 for efficient modulo via bitmasking
   - Adjust k proportionally to maintain false-positive rate

2. **Robin Hood hashing (lines 177-199):**
   - Linear probing with DIB (distance from ideal bucket)
   - Swap entries when probe finds lower DIB (rich help poor)
   - Ensures bounded probe lengths and good cache locality

3. **Bloom filter bit setting (lines 107-133):**
   - First bit: `j = key & (m-1)`
   - Subsequent bits: re-hash using `key *= 0x94d049bb133111eb; key ^= key >> 31`
   - Set/test k bits total using byte array indexing: `bits[j>>3] |= 1<<(j&7)`

4. **Key mixing (lines 96-105):**
   - mix13 algorithm from Zimbry blog
   - Three rounds of xor-shift and multiply with large primes
   - Applied to all keys before add/test to improve distribution

**Error Handling:**
- Memory allocation failures return NULL (new) or false (add/grow)
- No exceptions or error codes
- Caller must check return values
- No validation of input parameters (n, p, key)

### Dependencies

**Standard C library:**
- `<stdlib.h>` - malloc, free, size_t
- `<stdbool.h>` - bool, true, false
- `<stdint.h>` - uint64_t, uint8_t, UINT64_C
- `<math.h>` - log, pow, round (only in rhbloom_new)
- `<string.h>` - memset (for clearing memory)
- `<stdio.h>` - printf, assert (test.c only)
- `<time.h>` - clock_gettime (test.c benchmarks only)

**No external dependencies** - Pure C89/C99 with standard library only.

### Unit Test Strategy in Source

**Test structure (test.c):**
- `test()` function runs exhaustive parameter sweep
- `test_step()` validates one (n, p) configuration:
  1. Add n+1 keys while checking pre-upgrade invariants
  2. Assert upgrade occurred
  3. Verify all added keys test positive (100% recall)
  4. Test n+1 unseen keys, verify false-positive rate ≤ p+0.1
- Tests run twice per filter: once fresh, once after `rhbloom_clear()`
- No mocking needed - pure algorithmic tests with deterministic hash function

**Test oracle contract:**
- All added keys must test positive after upgrade
- False-positive rate on unseen keys must not exceed p+0.1
- Upgrade must occur (hash table → Bloom filter transition)
- Clear must reset state while preserving capacity

**Benchmark contract (bench mode):**
- Add N keys, test N present keys, test N absent keys
- Report operations/sec, ns/op, false-positive rate, memory usage
- Runs twice with clear in between to verify clear correctness

## 2. Third-Party Library Analysis

### C Dependencies

**Standard library math functions:**
- **Usage:** `log()`, `pow()`, `round()` in `rhbloom_new()` for Bloom filter sizing
- **Rust equivalent:** `f64::ln()`, `f64::powf()`, `f64::round()` - built into Rust core
- **Status:** No external crate needed, use Rust standard library

**Standard library memory functions:**
- **Usage:** `malloc()`, `free()`, `memset()` for dynamic allocation and zeroing
- **Rust equivalent:** `Vec<T>` for dynamic arrays, automatic Drop trait for cleanup
- **Status:** Idiomatic Rust ownership eliminates need for manual memory management

**Standard library types:**
- **Usage:** `size_t`, `uint64_t`, `uint8_t`, `bool`
- **Rust equivalent:** `usize`, `u64`, `u8`, `bool` - built-in primitive types
- **Status:** Direct mapping, no crate needed

### Test Dependencies (test.c)

**murmurhash2 implementation:**
- **Usage:** Hash integer test keys to u64 for deterministic test data
- **Rust equivalent:** Inline implementation in test.rs (already provided in scaffold)
- **Status:** Scaffold provides murmurhash2 in `src/bin/test.rs` - do NOT add external crate

**Timing functions:**
- **Usage:** `clock_gettime(CLOCK_MONOTONIC)` for benchmarks
- **Rust equivalent:** `std::time::Instant` - built into Rust standard library
- **Status:** Scaffold already uses `Instant::now()` in test.rs

### Provided Scaffolding Analysis

**scaffold/Cargo.toml:**
- Package name: `rhbloom`
- Edition: 2021
- No dependencies declared
- **Constraint:** Do NOT add dependencies unless absolutely necessary

**scaffold/src/lib.rs:**
- Declares `pub mod rhbloom;` - single public module

**scaffold/src/rhbloom.rs:**
- Defines `pub struct RHBloom` with fields matching C struct (minus allocator pointers)
- Declares all public methods as `unimplemented!()`
- **Key difference from C:** No custom allocator support (Rust uses global allocator)
- **Constraint:** Must implement all declared methods, preserve public API

**scaffold/src/bin/test.rs:**
- Complete test harness matching test.c behavior
- Provides `murmurhash2()`, `hash()`, `test_step()`, `test()`, `bench()`
- Uses `#[test]` attribute for `test()` function
- **Constraint:** Do NOT modify test.rs - it is the oracle

### Recommendations

**No new crates needed.** The translation requires only Rust standard library:
- `std::vec::Vec` for dynamic arrays
- `std::f64` for math functions
- `std::mem::size_of` for memory size calculations
- `std::time::Instant` (already in test.rs)

**Scaffolding already provides:**
- Complete test harness (test.rs) - do NOT recreate
- Struct definition with correct fields - implement methods
- Public API surface - preserve exactly as declared

## 3. Target Project Design

### Overview and Translation Requirements

**Functional equivalence measured by:**
- `cargo test` must pass (runs `test()` function in test.rs)
- Test validates upgrade behavior, recall, false-positive rate ≤ p+0.1
- Benchmark mode must run and report similar performance characteristics

**Translation constraints from brief:**
- Source at `source/` is read-only reference
- Scaffold at `scaffold/` defines immutable public interface
- Working copy at `pipeline/target/` receives translated implementation
- Validation: `cd pipeline/target && cargo test --manifest-path Cargo.toml`

**Key differences from C:**
- No custom allocator support (Rust uses global allocator, Box/Vec handle allocation)
- Ownership and borrowing replace manual memory management
- `Vec<u64>` and `Vec<u8>` replace raw pointers
- Empty vectors replace NULL pointers for "not yet allocated" state
- Methods take `&self` or `&mut self` instead of `struct rhbloom*` parameter

### Source → Target Structural Mapping

**Module structure:**
```
C source                    Rust target
--------                    -----------
rhbloom.h (API)        →    src/rhbloom.rs (pub impl RHBloom)
rhbloom.c (impl)       →    src/rhbloom.rs (private methods)
test.c                 →    src/bin/test.rs (provided, do NOT translate)
```

**Type mappings:**
```
C                           Rust
-                           ----
struct rhbloom              pub struct RHBloom
size_t                      usize
uint64_t                    u64
uint8_t                     u8
bool                        bool
double                      f64
void*(*malloc)(size_t)      (omit - use Vec)
void(*free)(void*)          (omit - use Drop trait)
uint64_t *buckets           Vec<u64> (empty = not allocated)
uint8_t *bits               Vec<u8> (empty = not allocated)
```

**Function mappings:**
```
C function                          Rust method
----------                          -----------
rhbloom_new(n, p)                   RHBloom::new(n: usize, p: f64) -> Self
rhbloom_new_with_allocator(...)     (omit - Rust uses global allocator)
rhbloom_free(rhbloom)               RHBloom::free(&mut self) (or rely on Drop)
rhbloom_clear(rhbloom)              RHBloom::clear(&mut self)
rhbloom_add(rhbloom, key)           RHBloom::add(&mut self, key: u64) -> bool
rhbloom_test(rhbloom, key)          RHBloom::test(&self, key: u64) -> bool
rhbloom_memsize(rhbloom)            RHBloom::memsize(&self) -> usize
rhbloom_upgraded(rhbloom)           RHBloom::upgraded(&self) -> bool
rhbloom_mix(key)                    RHBloom::mix(key: u64) -> u64
rhbloom_testadd(rhbloom, key, add)  RHBloom::testadd(&mut self, key: u64, add: bool) -> bool
rhbloom_addkey(rhbloom, key)        RHBloom::addkey(&mut self, key: u64) -> bool
rhbloom_grow(rhbloom)               RHBloom::grow(&mut self) -> bool
```

**Macro mappings:**
```
C macro                             Rust equivalent
-------                             ---------------
RHBLOOM_KEY(x)                      inline: (x << 8) >> 8
RHBLOOM_DIB(x)                      inline: (x >> 56) as usize
RHBLOOM_SETKEYDIB(key, dib)         inline: (key & 0x00FFFFFFFFFFFFFF) | ((dib as u64) << 56)
```

**Idiom mappings:**
- **NULL checks:** `if (!rhbloom->bits)` → `if self.bits.is_empty()`
- **Allocation:** `malloc(size)` → `Vec::with_capacity(n)` or `vec![0; n]`
- **Deallocation:** `free(ptr)` → automatic via Drop trait
- **Zeroing:** `memset(ptr, 0, size)` → `vec.fill(0)` or `vec.clear(); vec.resize(n, 0)`
- **Pointer arithmetic:** `bits[j>>3]` → `self.bits[j>>3]` (Vec indexing)
- **Bitwise ops:** Identical in Rust (u64 supports all C bitwise operations)
- **Error handling:** Return `false` on allocation failure (Vec allocation can panic, but matches C behavior of not recovering from OOM)

### Module Structure for Target Project

**pipeline/target/Cargo.toml** (copy from scaffold):
```toml
[package]
name = "rhbloom"
version = "0.1.0"
edition = "2021"

[dependencies]
# None required
```

**pipeline/target/src/lib.rs** (copy from scaffold):
```rust
pub mod rhbloom;
```

**pipeline/target/src/rhbloom.rs** (translate rhbloom.c into this):
```rust
// Public struct (from scaffold)
pub struct RHBloom {
    count: usize,
    nbuckets: usize,
    buckets: Vec<u64>,
    k: usize,
    m: usize,
    bits: Vec<u8>,
}

// Public methods (implement these)
impl RHBloom {
    pub fn new(n: usize, p: f64) -> Self { ... }
    pub fn memsize(&self) -> usize { ... }
    pub fn clear(&mut self) { ... }
    pub fn upgraded(&self) -> bool { ... }
    pub fn testadd(&mut self, key: u64, add: bool) -> bool { ... }
    pub fn free(&mut self) { ... }
    pub fn mix(key: u64) -> u64 { ... }
    pub fn grow(&mut self) -> bool { ... }
    pub fn add(&mut self, key: u64) -> bool { ... }
    pub fn addkey(&mut self, key: u64) -> bool { ... }
    pub fn test(&self, key: u64) -> bool { ... }
}

// Private helper functions (if needed)
fn key_part(x: u64) -> u64 { ... }
fn dib_part(x: u64) -> usize { ... }
fn set_key_dib(key: u64, dib: usize) -> u64 { ... }
```

**pipeline/target/src/bin/test.rs** (copy from scaffold, do NOT modify):
- Already complete and correct
- Imports `rhbloom::rhbloom::RHBloom`
- Provides test oracle via `#[test] fn test()`
- Provides benchmark via `fn main()` with "bench" argument

### Output/Contract Mapping

**Observable outputs (all via test.rs oracle):**

1. **Upgrade behavior:**
   - Filter must transition from hash table to Bloom filter
   - `upgraded()` must return true after sufficient adds
   - Transition must preserve all previously added keys

2. **Membership testing:**
   - All added keys must test positive (100% recall)
   - False-positive rate on unseen keys must be ≤ p + 0.1
   - Test must be deterministic for same key sequence

3. **Clear operation:**
   - Must reset filter to empty state
   - Must preserve capacity (no reallocation)
   - Must allow re-adding keys with same behavior

4. **Memory reporting:**
   - `memsize()` must return struct size + allocated buffer sizes
   - Must match C formula: `sizeof(struct) + (bits ? m>>3 : nbuckets<<3)`

5. **Add operation:**
   - Must return true on success
   - Must return false on allocation failure (or panic, matching C OOM behavior)
   - Must handle duplicate keys idempotently

### Boundary and Error-Handling Strategy

**No external boundaries** - Pure algorithmic code with no I/O, no network, no filesystem.

**Error handling:**
- **C approach:** Return NULL or false on malloc failure
- **Rust approach:** 
  - Vec allocation can panic on OOM (acceptable - matches C behavior of not recovering)
  - Alternatively, use `try_reserve()` and return false on allocation failure
  - Recommendation: Use simple Vec allocation (panic on OOM) for initial translation, matches C semantics

**Memory safety:**
- Rust ownership prevents use-after-free, double-free, memory leaks
- Vec automatically deallocates on drop
- No unsafe code needed (all operations are safe indexing and arithmetic)

**Numeric safety:**
- All arithmetic is unsigned (usize, u64, u8)
- Bitwise operations are well-defined
- Division by zero impossible (all divisors are constants or checked)
- Overflow: Use wrapping arithmetic for hash mixing (`.wrapping_mul()`, `.wrapping_add()`)

### Unit Test Strategy

**Mockable seams:** None needed - pure algorithmic code with no external dependencies.

**Test structure:**
- **Source tests (test.c):** Translate behavior into test.rs (already done in scaffold)
- **Target tests (test.rs):** Already provided, do NOT modify
- **Test execution:** `cargo test` runs `#[test] fn test()`
- **Benchmark execution:** `cargo run --bin test bench [N] [P]`

**Test coverage:**
- Scaffold test.rs covers all public methods
- Tests parameter sweep: n ∈ [0, 100000] step 1000, p ∈ [0.01, 0.70] step 0.05
- Tests clear operation by running test_step twice per filter
- Tests upgrade transition by checking `upgraded()` before and after
- Tests false-positive rate by comparing hits on unseen keys to expected p

**No new tests needed** - scaffold provides complete oracle.

**Test isolation:**
- Each test iteration creates new RHBloom instance
- No shared state between tests
- Deterministic hash function ensures reproducibility

### Milestone Mapping

**Milestone 1: Core data structure and initialization**
- Implement `RHBloom::new(n, p)` with Bloom filter sizing math
- Implement `RHBloom::upgraded()` to check if bits vector is non-empty
- Implement `RHBloom::memsize()` to calculate memory footprint
- Implement `RHBloom::free()` (may be no-op, rely on Drop)
- **Tests:** Create filter, check initial state, check memsize
- **Validation:** Instantiation tests pass

**Milestone 2: Hash mixing and key encoding**
- Implement `RHBloom::mix(key)` with mix13 algorithm
- Implement key/dib extraction and packing (inline or helper functions)
- **Tests:** Verify mix produces expected distribution (implicit in later tests)
- **Validation:** No direct tests, but required for milestone 3

**Milestone 3: Robin Hood hash table operations**
- Implement `RHBloom::addkey(key)` with Robin Hood insertion
- Implement `RHBloom::test(key)` for hash table mode (before upgrade)
- Implement `RHBloom::add(key)` to call mix and addkey
- **Tests:** Add keys to small filter, test membership before upgrade
- **Validation:** Pre-upgrade assertions in test_step pass

**Milestone 4: Hash table growth**
- Implement `RHBloom::grow()` to double nbuckets and rehash
- Integrate grow into add when count reaches nbuckets/2
- **Tests:** Add enough keys to trigger growth, verify no data loss
- **Validation:** Filters with n < upgrade threshold pass tests

**Milestone 5: Bloom filter operations**
- Implement `RHBloom::testadd(key, add)` for Bloom filter bit setting/testing
- Modify `RHBloom::grow()` to upgrade to Bloom filter when threshold reached
- Modify `RHBloom::add()` and `RHBloom::test()` to use Bloom filter when upgraded
- **Tests:** Add keys until upgrade, verify all keys test positive
- **Validation:** Upgrade assertions in test_step pass

**Milestone 6: Clear operation and full test suite**
- Implement `RHBloom::clear()` to reset bits or buckets without deallocation
- **Tests:** Run full test suite with clear between iterations
- **Validation:** `cargo test` passes completely

**Milestone 7: Benchmarks and performance validation**
- Verify benchmark mode runs: `cargo run --bin test bench`
- Compare performance to C implementation (should be similar)
- **Tests:** Benchmark with N=1000000, P=0.01
- **Validation:** Benchmark completes, reports reasonable false-positive rate

**Source functionality mapping to milestones:**
- M1: rhbloom_new, rhbloom_memsize, rhbloom_upgraded, rhbloom_free
- M2: rhbloom_mix, RHBLOOM_KEY/DIB/SETKEYDIB macros
- M3: rhbloom_addkey, rhbloom_test (hash table path), rhbloom_add (partial)
- M4: rhbloom_grow (hash table resize path)
- M5: rhbloom_testadd, rhbloom_grow (upgrade path), rhbloom_add/test (Bloom filter path)
- M6: rhbloom_clear
- M7: test.c bench() function (already in test.rs)

**Unit test mapping to milestones:**
- M1-M2: No direct tests, but required for M3
- M3: test_step pre-upgrade assertions (lines 71-77 in test.rs)
- M4: Implicit in M3 tests (growth happens automatically)
- M5: test_step upgrade and post-upgrade assertions (lines 79-100 in test.rs)
- M6: test() function with clear between iterations (lines 104-114 in test.rs)
- M7: bench() function (lines 117-165 in test.rs)

**Critical path:**
1. M1 → M2 → M3 (basic hash table functionality)
2. M3 → M4 (growth enables larger tests)
3. M4 → M5 (upgrade to Bloom filter)
4. M5 → M6 (clear operation)
5. M6 → M7 (benchmarks)

**Validation commands per milestone:**
- M1-M6: `cd pipeline/target && cargo test`
- M7: `cd pipeline/target && cargo run --bin test bench`

---

## Summary

This analysis provides a complete blueprint for translating rhbloom from C to Rust:

1. **Source research** identified a 266-line Robin Hood Bloom filter with dynamic upgrade, comprehensive test suite (205 lines), and no external dependencies beyond standard library.

2. **Library analysis** confirmed no external crates needed - Rust standard library provides all required functionality (Vec, f64 math, Instant). Scaffold already provides complete test harness and struct definition.

3. **Target design** specifies exact source→target mappings for types, functions, and idioms; defines 7 milestones from initialization through benchmarks; and confirms test.rs as the authoritative oracle requiring no modification.

The translation preserves the C implementation's structure (single module, same algorithm flow) while leveraging Rust's ownership system to eliminate manual memory management. The scaffold's public API exactly matches the C API surface, ensuring drop-in compatibility for the test harness.
