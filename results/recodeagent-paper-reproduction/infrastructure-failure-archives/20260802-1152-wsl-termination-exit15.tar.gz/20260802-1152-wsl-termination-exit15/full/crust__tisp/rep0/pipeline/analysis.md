# Tisp C-to-Rust Translation Analysis

## 1. Source Project Research

### Overview
Tisp is a tiny, terse, and transparent Lisp programming language designed to be lightweight, modular, extendable, and easy to embed into other programs. It is a functional language inspired by Scheme with ideas from Python, Haskell, Julia, and Elm. The implementation consists of approximately 2,683 lines of C code across the core interpreter and standard library modules.

**Core Functionality:**
- Read-Eval-Print Loop (REPL) interpreter
- S-expression parser with syntactic sugar
- Dynamic type system with 13 value types
- Garbage-collection-free memory management (manual allocation)
- Hash table-based environment records for variable scoping
- Tail-call optimization for function calls
- Macro system for compile-time code transformation

### Directory Structure

```
source/
├── tisp.h              # Main header with type definitions and API
├── tisp.c              # Core interpreter (952 lines)
├── main.c              # CLI entry point (83 lines)
├── test.c              # Unit test suite (613 lines)
├── tibs_tsp.h          # Embedded standard library (generated from .tsp files)
├── tib/                # Standard library modules in C
│   ├── core.c          # Core primitives (285 lines)
│   ├── string.c        # String operations (159 lines)
│   ├── math.c          # Math operations (292 lines)
│   ├── io.c            # I/O operations (205 lines)
│   ├── os.c            # OS operations (94 lines)
│   ├── *.tsp           # Tisp standard library code
└── Makefile
```

### Key Components and Interfaces

#### 1. **Type System** (`tisp.h` lines 85-103)
```c
typedef enum {
    TSP_NONE  = 1 << 0,   // void
    TSP_NIL   = 1 << 1,   // nil/false/empty list
    TSP_INT   = 1 << 2,   // integer
    TSP_DEC   = 1 << 3,   // decimal (float)
    TSP_RATIO = 1 << 4,   // rational (fraction)
    TSP_STR   = 1 << 5,   // string
    TSP_SYM   = 1 << 6,   // symbol
    TSP_PRIM  = 1 << 7,   // primitive (C function)
    TSP_FORM  = 1 << 8,   // special form (C macro)
    TSP_FUNC  = 1 << 9,   // function (Tisp lambda)
    TSP_MACRO = 1 << 10,  // macro (Tisp macro)
    TSP_PAIR  = 1 << 11,  // cons pair
    TSP_REC   = 1 << 12,  // record (hash table)
} TspType;
```

#### 2. **Value Representation** (`tisp.h` lines 109-119)
```c
struct Val {
    TspType t;
    union {
        char *s;                                           // STRING, SYMBOL
        struct { double num, den; } n;                     // NUMBER
        struct { char *name; Prim pr; } pr;                // PRIMITIVE, FORM
        struct { char *name; Val args, body; Rec env; } f; // FUNCTION, MACRO
        struct { Val car, cdr; } p;                        // PAIR
        Rec r;                                             // REC
    } v;
};
```

#### 3. **Environment Records** (`tisp.h` lines 76-82)
Hash table implementation with open addressing and linear probing:
```c
struct Rec {
    int size, cap;
    struct Entry {
        char *key;
        Val val;
    } *items;
    struct Rec *next;  // Parent scope chain
};
```

#### 4. **Interpreter State** (`tisp.h` lines 122-129)
```c
struct Tsp {
    char *file;        // Current input string
    size_t filec;      // Current position in input
    Val none, nil, t;  // Singleton values
    Rec env, strs, syms; // Global environment and intern tables
    void **libh;       // Dynamic library handles
    size_t libhc;      // Library handle count
};
```

### Data Models and Observable Output

**Input:** Tisp source code as strings (from files, stdin, or command-line arguments)

**Output:** 
- Printed values via `tisp_print()` to stdout/stderr
- Format: Valid Tisp code (quoted lists, symbols, numbers, strings)
- Error messages: Prefixed with `"; tisp: error: "` to stderr
- Return codes: 0 for success, 1-2 for errors

**Observable Contract (from test.c):**
- 613 lines of test cases covering:
  - Number parsing (integers, decimals, rationals, scientific notation)
  - String and symbol parsing
  - Quote, cons, car, cdr operations
  - Arithmetic operations (+, -, *, /, mod, pow)
  - Comparison operations (=, <, >, <=, >=)
  - Control flow (cond, do, eval)
  - Function and macro definition
  - Record (hash table) operations
  - String operations
  - I/O operations (read, write)
  - OS operations (cd, pwd, exit, time)

### Error Handling

**Strategy:** Return NULL on error with stderr message
- Macros: `tsp_warn()`, `tsp_warnf()` print error and return NULL
- Argument validation: `tsp_arg_num()`, `tsp_arg_type()`, `tsp_arg_min()`, `tsp_arg_max()`
- No exceptions; errors propagate via NULL returns
- Backtrace tracking via `bt` variable in base environment

### Dependencies

**C Standard Library:**
- `stdio.h` - I/O operations
- `stdlib.h` - Memory allocation, exit
- `string.h` - String manipulation
- `ctype.h` - Character classification
- `stdarg.h` - Variadic functions
- `stdint.h` - Fixed-width integers
- `math.h` - Mathematical functions
- `assert.h` - Assertions (test only)
- `time.h` - Time operations
- `unistd.h` - POSIX operations (chdir, getcwd, read, close)
- `fcntl.h` - File control (open)
- `limits.h` - System limits (PATH_MAX, INT_MAX)
- `dlfcn.h` - Dynamic loading (dlopen, dlsym)
- `libgen.h` - Path manipulation (basename)
- `signal.h` - Signal handling (SIGINT)

**No external dependencies** - pure C with standard library only.

### Unit Test Structure

**test.c** (613 lines):
- Array of test cases: `char *tests[][2]` with input and expected output
- Test sections marked by `{ "section_name", NULL }`
- Test runner: `tisp_test()` function that:
  1. Initializes Tisp state
  2. Reads input string
  3. Evaluates expression
  4. Prints result to temporary file
  5. Compares output with expected string
- No mocking - tests run against real interpreter
- Tests are self-contained and stateless (each initializes fresh environment)

**Test Coverage:**
- Lexer/parser: Number formats, strings, symbols, lists, quotes
- Evaluator: Primitives, functions, macros, special forms
- Standard library: All tib modules (core, string, math, io, os)
- Edge cases: Empty lists, improper lists, nested structures
- Error cases: Type mismatches, undefined symbols, division by zero

---

## 2. Third-Party Library Analysis

### C Dependencies → Rust Equivalents

#### Standard Library Functions

| C Dependency | Usage | Rust Equivalent | Notes |
|--------------|-------|-----------------|-------|
| `malloc/calloc/realloc/free` | Manual memory management | `Box`, `Vec`, `String` | Rust's ownership system eliminates manual free |
| `printf/fprintf/fputs` | Formatted output | `print!`, `write!`, `format!` | Rust's formatting macros |
| `fopen/fclose/fread/fwrite` | File I/O | `std::fs::File`, `std::io::Read/Write` | Rust's I/O traits |
| `strcpy/strcat/strlen/strcmp` | String operations | `String` methods | Rust strings are UTF-8 safe |
| `isdigit/isalpha/tolower` | Character classification | `char` methods | Rust's char type |
| `pow/floor/ceil/round/abs` | Math functions | `f64` methods, `i32::abs` | Rust's numeric traits |
| `time/clock` | Time operations | `std::time::SystemTime`, `Instant` | Rust's time module |
| `chdir/getcwd/open/read/close` | POSIX operations | `std::env::set_current_dir`, `std::fs` | Rust's filesystem module |
| `dlopen/dlsym/dlclose` | Dynamic loading | `libloading` crate (optional) | Not in std, rarely needed |
| `signal/sigaction` | Signal handling | `signal-hook` crate (optional) | Not in std |

#### Provided Scaffolding Analysis

**scaffold/src/tisp.rs** provides:
- Type definitions: `TspType`, `Val`, `ValUnion`, `Rec`, `Entry`, `Tsp`
- Function signatures (all `unimplemented!()`)
- Constants: `TSP_REC_MAX_PRINT`, `TSP_SYM_CHARS`, `TSP_REC_FACTOR`, `TSP_OP_CHARS`

**What the scaffold provides:**
1. **Type structure** - Rust enums and structs matching C types
2. **Function signatures** - All public API functions declared
3. **Module organization** - Separate modules for core, string, math, io, os
4. **Test harness** - `scaffold/src/bin/test.rs` with test runner

**What is NOT provided (must be implemented):**
- All function bodies (currently `unimplemented!()`)
- Memory management strategy (Box vs Rc vs Arc)
- Error handling (Option/Result types)
- String interning logic
- Hash table implementation
- Parser implementation
- Evaluator implementation
- All primitive functions

#### Recommended New Libraries

**None required.** The scaffold uses only Rust standard library:
- `std::collections::HashMap` - Could be used for records (alternative to manual hash table)
- `std::rc::Rc` - For shared ownership of values (alternative to raw pointers)
- `std::cell::RefCell` - For interior mutability if needed

**Optional enhancements (NOT recommended for faithful port):**
- `libloading` - For dynamic library loading (if implementing `load` primitive)
- `signal-hook` - For signal handling (if implementing SIGINT handling)

---

## 3. Target Project Design

### Overview and Translation Requirements

**Goal:** Faithful line-by-line translation of tisp from C to Rust, preserving:
- Exact behavior as verified by test suite
- Module structure and naming conventions
- Algorithm implementations (hash table, parser, evaluator)
- Performance characteristics (no GC, manual memory management via Rust ownership)

**Functional Equivalence Measured By:**
- All 613 test cases in test.c must pass when translated to Rust
- Output format must match exactly (including whitespace, number formatting)
- Error messages must match format ("; tisp: error: ...")
- Command-line interface must match (same flags, same behavior)

**Constraints from Brief:**
- Use provided scaffold structure (do not change public interfaces)
- Conform to scaffold's type definitions
- Implement all `unimplemented!()` functions
- Do not modify scaffold's test harness structure

### Source → Target Structural Mapping

#### Module Mapping

| C File | Rust Module | Responsibility |
|--------|-------------|----------------|
| `tisp.h` | `src/tisp.rs` | Core types, interpreter API |
| `tisp.c` | `src/tisp.rs` | Parser, evaluator, printer, environment |
| `main.c` | `src/bin/main.rs` | CLI entry point (NEW - not in scaffold) |
| `test.c` | `src/bin/test.rs` | Test runner (provided in scaffold) |
| `tib/core.c` | `src/core.rs` | Core primitives (car, cdr, cons, etc.) |
| `tib/string.c` | `src/string.rs` | String primitives (Str, Sym, strlen, etc.) |
| `tib/math.c` | `src/math.rs` | Math primitives (+, -, *, /, pow, etc.) |
| `tib/io.c` | `src/io.rs` | I/O primitives (read, write, etc.) |
| `tib/os.c` | `src/os.rs` | OS primitives (cd, pwd, exit, time) |
| `tibs_tsp.h` | Embedded in binary or external file | Standard library Tisp code |

#### Type Mapping

| C Type | Rust Type | Notes |
|--------|-----------|-------|
| `TspType` (enum) | `TspType` (enum) | Bit flags → Rust enum with Copy trait |
| `Val` (pointer) | `Box<Val>` or `Rc<Val>` | Heap-allocated, owned |
| `Rec` (pointer) | `Box<Rec>` | Heap-allocated record |
| `Tsp` (pointer) | `Tsp` (owned struct) | Interpreter state |
| `char *` | `String` or `&str` | Owned vs borrowed strings |
| `Prim` (function pointer) | `fn(Tsp, Rec, Val) -> Val` | Function pointer type |
| `NULL` | `None` (Option<T>) | Rust's null safety |
| `int` | `i32` | Signed 32-bit integer |
| `double` | `f64` | 64-bit float |
| `size_t` | `usize` | Platform-dependent unsigned |

#### Idiom Mapping

| C Idiom | Rust Idiom | Example |
|---------|------------|---------|
| `if (!ptr)` | `if ptr.is_none()` | Null checks → Option |
| `return NULL` | `return None` | Error signaling |
| `malloc/free` | `Box::new` / automatic drop | Memory management |
| `ptr->field` | `ptr.field` or `(*ptr).field` | Dereferencing |
| `typedef struct` | `struct` | Type definitions |
| `union` | `enum` with variants | Tagged unions |
| `#define` macros | `const` or `macro_rules!` | Constants and macros |
| `va_list` | Variadic generics or slices | Variadic functions |
| `fprintf(stderr, ...)` | `eprintln!(...)` | Error output |
| `do { ... } while(0)` | Block expression | Macro hygiene |

### Module Structure for Target Project

```
pipeline/target/
├── Cargo.toml          # Package manifest
├── src/
│   ├── lib.rs          # Library root (re-exports modules)
│   ├── tisp.rs         # Core interpreter (parser, eval, print, env)
│   ├── core.rs         # Core primitives
│   ├── string.rs       # String primitives
│   ├── math.rs         # Math primitives
│   ├── io.rs           # I/O primitives
│   ├── os.rs           # OS primitives
│   └── bin/
│       ├── main.rs     # CLI entry point (NEW)
│       └── test.rs     # Test runner (provided)
└── tibs.tsp            # Standard library (optional external file)
```

### Output/Contract Mapping

**Test Oracle:** `scaffold/src/bin/test.rs`
- Reads test cases from `TESTS` array
- For each test: read → eval → print → compare output
- Expected output must match exactly (string equality)

**Milestone Mapping:**

1. **Milestone 1: Core Types and Memory Management**
   - Implement `Val`, `Rec`, `Entry`, `Tsp` types
   - Implement `mk_val`, `mk_int`, `mk_dec`, `mk_rat`, `mk_str`, `mk_sym`, `mk_pair`, `mk_list`
   - Implement hash table: `hash`, `rec_new`, `rec_add`, `rec_get`, `entry_get`, `rec_grow`
   - Tests: None (infrastructure only)

2. **Milestone 2: Parser (Read)**
   - Implement `tisp_read`, `tisp_read_sexpr`, `read_pair`, `read_num`, `read_str`, `read_sym`
   - Implement `skip_ws`, `isnum`, `is_sym`, `is_op`, `esc_str`, `esc_char`
   - Tests: Number parsing, string parsing, symbol parsing, list parsing (lines 14-59 of test.c)

3. **Milestone 3: Printer**
   - Implement `tisp_print` for all value types
   - Tests: All tests (output comparison requires printer)

4. **Milestone 4: Environment and Evaluator**
   - Implement `tisp_env_init`, `tisp_env_add`, `tisp_env_lib`
   - Implement `tisp_eval`, `tisp_eval_list`, `tisp_eval_body`, `eval_proc`
   - Implement `rec_extend`, `vals_eq`, `tsp_lstlen`, `tsp_type_str`
   - Tests: Basic evaluation (quote, cons, car, cdr)

5. **Milestone 5: Core Primitives (tib/core.c)**
   - Implement `prim_car`, `prim_cdr`, `prim_cons`, `form_quote`, `prim_eval`, `prim_eq`
   - Implement `form_cond`, `prim_typeof`, `form_Func`, `form_Macro`, `prim_error`
   - Implement `form_def`, `form_undefine`, `form_definedp`
   - Implement `prim_recmerge`, `prim_records`, `mk_rec`, `prim_procprops`
   - Tests: Lines 70-150 of test.c (quote, cons, cxr, do, eval, cond, eq)

6. **Milestone 6: Math Primitives (tib/math.c)**
   - Implement `prim_add`, `prim_sub`, `prim_mul`, `prim_div`, `prim_mod`, `prim_pow`
   - Implement `prim_Int`, `prim_Dec`, `prim_round`, `prim_floor`, `prim_ceil`
   - Implement comparison: `prim_lt`, `prim_gt`, `prim_le`, `prim_ge`
   - Implement `frac_reduce`, `mk_num` helper
   - Tests: Lines 200-350 of test.c (arithmetic, comparisons)

7. **Milestone 7: String Primitives (tib/string.c)**
   - Implement `prim_Str`, `prim_Sym`, `prim_strlen`, `form_strformat`
   - Implement `val_string` helper
   - Tests: Lines 400-450 of test.c (string operations)

8. **Milestone 8: I/O Primitives (tib/io.c)**
   - Implement `prim_write`, `read_file`, `count_parens`
   - Implement file reading and writing
   - Tests: Lines 450-500 of test.c (I/O operations)

9. **Milestone 9: OS Primitives (tib/os.c)**
   - Implement `prim_cd`, `prim_pwd`, `prim_exit`, `prim_now`, `form_time`
   - Tests: Lines 500-550 of test.c (OS operations)

10. **Milestone 10: CLI and Integration**
    - Implement `main.rs` CLI entry point
    - Implement `tisp_read_line`, `tisp_read_sugar` for REPL
    - Implement standard library loading
    - Tests: Full test suite (all 613 lines)

### Boundary and Error-Handling Strategy

**C Error Handling:**
- Return NULL on error
- Print to stderr with `fprintf(stderr, "; tisp: error: ...")`
- Macros: `tsp_warn()`, `tsp_warnf()` for error reporting

**Rust Error Handling:**
- Use `Option<Val>` for functions that can fail (return `None` on error)
- Use `Result<Val, String>` if more detailed error info needed (optional)
- Print to stderr with `eprintln!("...")` or `write!(stderr, ...)`
- Preserve exact error message format for test compatibility

**Boundary Strategy:**
- **File I/O:** Use `std::fs::File` and `std::io::Read/Write` traits
- **Standard input:** Use `std::io::stdin()`
- **Standard output/error:** Use `std::io::stdout()`, `std::io::stderr()`
- **Environment variables:** Use `std::env` (if needed)
- **File system:** Use `std::fs` and `std::env::set_current_dir`
- **Time:** Use `std::time::SystemTime` and `std::time::Instant`

**No high-level scaffolding calls** - the scaffold only provides type definitions and function signatures. All logic must be implemented.

### Unit Test Strategy

**Mockable Seams:**
The C source has no explicit mocking - tests run against the real interpreter. The Rust port should follow the same approach:
- No mocks needed for unit tests
- Tests initialize a fresh `Tsp` state for each test case
- Tests use real file I/O (temporary files for output comparison)

**Test Structure:**
- `scaffold/src/bin/test.rs` provides the test harness
- Test cases defined in `TESTS` array: `&[(&str, Option<&str>)]`
- Test runner: `tisp_test()` function
- Each test: initialize → read → eval → print → compare

**Source Tests Translation:**
- All 613 test cases from `test.c` are already translated to Rust in `scaffold/src/bin/test.rs`
- Test format: `("input", Some("expected_output"))` or `("section", None)`
- No new tests needed - implement to pass existing tests

**Test Organization:**
- Tests are in `src/bin/test.rs` (provided)
- Run with `cargo test`
- Each test section marked by `("section_name", None)`
- Tests are self-contained and stateless

**Unit Test Locations:**
- All tests in `src/bin/test.rs`
- No separate unit test files needed
- Integration tests run the full interpreter

### Milestone Mapping

| Milestone | Source Functionality | Unit Tests | Success Criteria |
|-----------|---------------------|------------|------------------|
| M1 | Types, memory, hash table | None | Compiles, types defined |
| M2 | Parser (read) | Lines 14-59 | Number/string/symbol parsing |
| M3 | Printer | All tests | Output formatting correct |
| M4 | Evaluator, environment | Lines 70-82 | Quote works |
| M5 | Core primitives | Lines 83-150 | cons, car, cdr, cond, eq work |
| M6 | Math primitives | Lines 200-350 | Arithmetic and comparisons work |
| M7 | String primitives | Lines 400-450 | String operations work |
| M8 | I/O primitives | Lines 450-500 | File I/O works |
| M9 | OS primitives | Lines 500-550 | OS operations work |
| M10 | CLI, full integration | All 613 lines | Full test suite passes |

**Incremental Validation:**
- After each milestone, run `cargo test` to verify progress
- Tests should pass incrementally (M2 tests pass after M2, etc.)
- Final validation: All 613 test cases pass

---

## Summary

This analysis document provides the authoritative design for translating tisp from C to Rust:

1. **Source Project Research:** Tisp is a 2,683-line Lisp interpreter with a hash table-based environment, manual memory management, and a comprehensive test suite of 613 test cases. The architecture consists of a parser (read), evaluator (eval), printer (print), and standard library modules (core, string, math, io, os).

2. **Third-Party Library Analysis:** The C source uses only standard library functions, all of which have direct Rust equivalents in `std`. The provided scaffold defines all types and function signatures but requires full implementation. No external crates are needed.

3. **Target Project Design:** The Rust port will preserve the C structure with a 1-to-1 module mapping. Types will use Rust's ownership system (`Box`, `Option`) instead of raw pointers. Error handling will use `Option<Val>` instead of NULL returns. The translation will proceed in 10 milestones, each validated by a subset of the 613 test cases, culminating in full test suite passage.

The design ensures faithful translation while leveraging Rust's safety guarantees (ownership, no null pointers, bounds checking) without changing the observable behavior or algorithm implementations.
