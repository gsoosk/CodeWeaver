# gohistogram Go-to-Rust Analysis and Target Design

## 1. Source Project Research

### Purpose and architecture

`source/` is the Go module `github.com/VividCortex/gohistogram` (Go 1.21.6). It is a small, deterministic, in-memory library implementing the streaming approximate histogram algorithm described by Ben-Haim and Yom-Tov. Values are retained as ordered, dynamically merged bins rather than as raw samples. There are two implementations:

- `NumericHistogram` assigns ordinary occurrence counts to bins.
- `WeightedHistogram` decays selected existing bin counts with an exponentially weighted moving-average operation, making recent observations more influential.

There is no persistence, network access, clock, randomness, goroutine, synchronization, configuration, or live infrastructure. The `cmd` package is an intentionally empty executable, so the only meaningful observable surface is the library API and its textual histogram representation.

### Source tree and file responsibilities

| Path | Responsibility | Port disposition |
|---|---|---|
| `go.mod` | Declares the module and Go version; has no `require` entries. | Becomes the Cargo package manifest. |
| `histogram.go` | Defines public `Histogram` and private shared `bin`. | Becomes the common Rust trait/data module. |
| `numerichistogram.go` | Complete ordinary histogram implementation. | Translate algorithmically, without replacing it with another histogram crate. |
| `weightedhistogram.go` | Complete decaying histogram implementation plus private `ewma` and `scaleDown`. | Translate algorithmically, preserving update order. |
| `example.go` | Compile-only Go documentation example touching every public concrete method. It has no `Output:` assertion. | Becomes a Rust example or compiling doctest. |
| `cmd/main.go` | Blank-imports the library and runs an empty `main`; produces no output. | Becomes an empty Cargo binary target. |
| `histogram_test.go` | Two behavioral tests over a common 14,999-value fixture. | Translate directly to Rust integration tests. |
| `sample_data_test.go` | Defines `testData`, the integer fixture used by both behavioral tests. | Keep as test-only Rust fixture data. |
| `README.md` | Algorithm, usage, and tuning documentation. | Adapt usage syntax for Rust while retaining algorithm guidance. |
| `LICENSE` | MIT license. | Preserve unchanged. |
| `coverage.out` | Checked-in Go coverage profile; it reports that merge bodies, statistics, string rendering, and sentinel branches were not exercised. | Research input only; not a runtime artifact to port. |
| `result.json` | Generated static symbol/dependency inventory for the Go source. | Research input only; not a runtime artifact to port. |

### Data model and public API

`histogram.go` defines:

- `Histogram`, with mutating `Add(float64)`, read-only `Quantile(float64) float64`, and `String() string`.
- Private `bin { value float64; count float64 }`. Both fields are floating point because merged bin locations are weighted centroids and weighted counts can be fractional.

`NumericHistogram` has private `bins []bin`, `maxbins int`, and `total uint64`. Its exported API is:

- `NewHistogram(n int) *NumericHistogram`
- `Add(n float64)`
- `Quantile(q float64) float64`
- `CDF(x float64) float64`
- `Mean() float64`
- `Variance() float64`
- `Count() float64`
- `String() string`

`WeightedHistogram` has private `bins []bin`, `maxbins int`, `total float64`, and `alpha float64`. It exports the same methods and is constructed by `NewWeightedHistogram(n int, alpha float64)`. `alpha` is documented as `2/(N+1)` for an intended moving-window age but is not validated.

Both concrete pointer types satisfy `Histogram`; `CDF`, `Mean`, `Variance`, and `Count` deliberately are not part of that interface.

### Core behavioral contract

For ordinary finite values and positive `maxbins`, both implementations maintain bins in ascending value order:

1. `Add` uses exact `float64` equality to increment an existing bin.
2. Otherwise it inserts before the first strictly greater bin, or appends at the end.
3. After each insertion, `trim` repeatedly merges the closest adjacent pair until `len(bins) <= maxbins`.
4. A merge sums counts and uses their weighted average as the new value. Candidate deltas are compared with strict `<`, so an equal-distance tie selects the leftmost pair. The initial minimum is the literal `1e99`, not positive infinity.

`NumericHistogram.Add` increments its `uint64 total` exactly once per sample before trimming. Go unsigned overflow wraps, so a fully faithful Rust implementation must use wrapping addition rather than debug-overflow behavior.

`WeightedHistogram.Add` has important, observable asymmetry that must not be “corrected”:

- Existing value: increment that bin by `1`, multiply every other bin count by `alpha`, then trim.
- Interior insertion: add a count-`1` bin, multiply every old bin by `alpha`, then trim.
- Append as the new largest value: append count `1`, do **not** decay existing bins, then trim.

This ordering follows Go's LIFO `defer` behavior: `scaleDown` runs before `trim`. `ewma(existing, 0, alpha)` is `existing * alpha`; the full helper is `new*(1-alpha) + existing*alpha`. Weighted `trim` recomputes `total` from all bin counts before merging; merges preserve that sum. With `alpha == 1`, normal finite input behaves like `NumericHistogram`, apart from the type of `total`.

Query semantics are:

- `Quantile(q)` starts with `q * total`, subtracts bin counts in ascending order, and returns the first bin where the remainder is `<= 0`.
- On an empty histogram, or when a positive remainder survives all bins (normally `q > 1`), it returns the sentinel `-1.0`; it does not return `Option` or an error.
- For a nonempty histogram, `q <= 0` returns the first bin, and `q == 1` returns the last bin under normal totals. A NaN `q` falls through to `-1.0`.
- `CDF(x)` sums counts for bin values `<= x` and divides by total. Empty CDF is IEEE `NaN` (`0/0`), not zero or an error.
- `Mean` is the count-weighted bin mean. Empty mean is `0`.
- `Variance` is the population variance of the current approximate bin distribution, divided by total rather than `total-1`. Empty variance is `0`.
- `Count` always returns `float64`; for a weighted histogram it is the current sum of weights, not the number of calls to `Add`.

`String` has an exact line-oriented contract:

```text
Total: <total>
<bin-value> <TAB surrounded by fmt spaces> <bar>
...
```

More precisely, it is the concatenation of `fmt.Sprintln("Total:", total)` and, for each bin, `fmt.Sprintln(value, "\t", bar)`. Thus a bin line is `<value> \t <bar>\n`. `bar` contains `trunc(count/total*200)` periods. Empty histograms render only `Total: 0\n`. Numeric formatting follows Go's default formatting for the underlying `uint64`/`float64`.

The library writes no tables, records, or files. The no-op command emits neither stdout nor stderr.

### Error handling and edge behavior

There are no Go `error` returns, explicit validation branches, or recovery handlers. Constructors accept all arguments. A non-positive `maxbins` eventually makes `trim` attempt to merge when no adjacent pair exists and panic; normal documented usage assumes a positive count (typically 20–80). `alpha` values outside `[0,1]` are accepted and participate literally in floating-point arithmetic.

No normalization or total ordering is applied to NaN/infinite samples. Exact comparisons with NaN fail, so NaN appends; pathological non-finite or extremely separated values can violate ordering assumptions or leave the merge index at zero and panic. The Rust port must retain direct IEEE comparisons and must not silently sort with `total_cmp`, clamp arguments, discard samples, or convert sentinels into success-shaped defaults.

### Source tests and boundary mocking

`histogram_test.go` defines `approx(x, y)` as `abs(x-y) < 0.2` and contains:

- `TestHistogram`: constructs `NewHistogram(160)`, adds all fixture values, checks `Count() == 14999`, and checks quantiles `0.25`, `0.5`, and `0.75` against `14`, `18`, and `22`, plus `CDF(18)` against `0.5` and `CDF(22)` against `0.75`.
- `TestWeightedHistogram`: repeats the quantile and CDF checks with `NewWeightedHistogram(160, 1)`. It does not assert weighted count.

The fixture has 14,999 integers, 158 distinct values, minimum `2`, and maximum `216`. Because the configured maximum is 160, these tests never execute a merge. The actual fixture CDFs are approximately `0.570038` at 18 and `0.780452` at 22; the source intentionally uses a broad `0.2` tolerance. The checked-in coverage profile reports only 43.2% statement coverage: source tests do not exercise merge logic, `Mean`, `Variance`, `String`, empty behavior, invalid quantiles, or weighted decay with `alpha < 1`.

Tests use no mocks because there are no external boundaries. They instantiate concrete in-memory histograms and share only static fixture data. `example.go` is a compile-time API smoke test, not an output test.

## 2. Third-Party Library Analysis

There are no third-party Go dependencies: `go.mod` contains no requirements. The Rust port should likewise have no runtime crate dependencies, and in particular must not substitute `hdrhistogram`, `histogram`, or another statistics crate whose bucketing, quantiles, decay, and formatting would differ.

| Go facility | Source use | Rust counterpart |
|---|---|---|
| `fmt.Sprintln` | Builds `String()` output line by line. | `std::fmt::{Display, Formatter, Write}` and `write!`/`writeln!`; use a small private formatting helper if needed to preserve Go spellings such as `+Inf` rather than changing the public output. |
| Built-in slices and `append` | Ordered bin storage, insertion, and replacement during merge. | `Vec<Bin>`, `Vec::insert`, indexed scans, and `remove`/replacement. |
| Built-in IEEE `float64` arithmetic | Bin locations, counts, decay, statistics, comparisons, and NaN behavior. | `f64`; preserve operation order and ordinary partial comparisons. |
| `math.Abs` | Test-only approximate comparisons. | `(x - y).abs()` from the standard library. |
| `testing` | Unit tests and error reporting. | Rust's built-in `#[test]`, `assert!`, and `assert_eq!` harness. |

The project brief names no reusable application scaffolding, and `pipeline/target` is not present at analysis time. The only provided infrastructure is the Cargo command contract in `codeweaver.toml`: `cargo build` for build checking and `cargo test` for both unit testing and validation. There are no provided storage, CLI, serialization, logging, or service abstractions to call or recreate. The target therefore needs a normal library crate and no framework layer.

## 3. Target Project Design

### Translation requirements and Rust API

Create a Rust package named `gohistogram` at `pipeline/target`, with a library crate of the same name. Preserve the source algorithms and observable edge behavior; correctness is determined by the configured Cargo build/test commands, with the translated source tests as the minimum oracle.

Use Rust naming and ownership conventions while retaining traceability:

- Go pointers returned by constructors become owned structs; mutation uses `&mut self`, queries use `&self`.
- `Histogram` becomes an object-safe public trait with `add(&mut self, f64)` and `quantile(&self, f64) -> f64`, plus `Display` as the idiomatic equivalent of Go's `String`.
- Both structs expose inherent `add`, `quantile`, `cdf`, `mean`, `variance`, and `count` methods so concrete callers do not need trait-method imports. Trait implementations delegate to those inherent methods.
- `NewHistogram` maps to `NumericHistogram::new(maxbins)` and a thin root-level `new_histogram(maxbins)` compatibility constructor. `NewWeightedHistogram` maps similarly to `WeightedHistogram::new(maxbins, alpha)` and `new_weighted_histogram`.
- Preserve `count() -> f64` for both implementations even though numeric storage is `u64`.
- Use `usize` for `maxbins`, the natural Rust representation of a vector-size limit. Do not validate or clamp zero; the first required impossible merge must panic rather than silently alter behavior. Negative Go values are outside the documented domain and have no Rust `usize` representation.
- Use direct return values, not `Result` or `Option`: source has no recoverable error channel, and `-1.0`, `NaN`, zero statistics, and panics are part of its behavior.
- No threading translation is needed. Rust's `&mut self` models the source's unsynchronized mutation without adding locks.

### Source-to-target structural mapping

| Go source/symbol | Rust target |
|---|---|
| `histogram.go` / `Histogram` | `src/histogram.rs` / public `Histogram: Display` trait |
| `histogram.go` / private `bin` | `src/histogram.rs` / crate-private `Bin { value: f64, count: f64 }` |
| `numerichistogram.go` / `NumericHistogram` | `src/numeric_histogram.rs` / public `NumericHistogram` |
| `NewHistogram` | `NumericHistogram::new` plus root `new_histogram` |
| `NumericHistogram.Add`, `Quantile`, `CDF`, `Mean`, `Variance`, `Count` | Inherent snake-case methods and the relevant trait delegates |
| `NumericHistogram.trim` | Private `trim(&mut self)` in `numeric_histogram.rs` |
| `weightedhistogram.go` / `WeightedHistogram` | `src/weighted_histogram.rs` / public `WeightedHistogram` |
| `NewWeightedHistogram` | `WeightedHistogram::new` plus root `new_weighted_histogram` |
| `ewma`, `scaleDown`, `trim` | Private `ewma`, `scale_down`, and `trim` in `weighted_histogram.rs` |
| Both `String` methods | `Display` implementations; blanket `ToString` supplies `.to_string()` |
| Go package assembly | `src/lib.rs`, declaring modules and re-exporting public trait, types, and constructors |
| `example.go` | `examples/basic.rs` or a compiling crate-level doctest with no asserted output |
| `cmd/main.go` | `src/bin/cmd.rs`, empty and silent |
| `histogram_test.go` | `tests/histogram_test.rs` |
| `sample_data_test.go` | Test-only `tests/sample_data.rs`, imported by the integration test |
| `README.md`, `LICENSE` | Target README with Rust usage; unchanged MIT license |
| `coverage.out`, `result.json` | Do not copy; they are Go analysis artifacts, not product output |

`Bin` and its fields should be `pub(crate)` only as needed across internal modules; histogram fields remain private. The crate root should re-export the public API so consumers use `gohistogram::NumericHistogram`, not internal module paths.

### Algorithm and contract implementation details

Do not sort after insertion or use `f64::total_cmp`. Scan in source order for exact equality and then the first `>` value, using `Vec::insert`; this retains NaN behavior. In each `trim`, scan adjacent pairs from left to right, initialize the best delta to `1e99`, and update only on strict `<`. Replace the selected pair with the weighted centroid and summed count, repeating as required. Preserve the source arithmetic expression order to limit floating-point drift.

Numeric `total` is `u64` and increments with `wrapping_add(1)`. Weighted `total` is `f64` and is recomputed before merging on every `add`. Weighted `add` must use explicit branch ordering equivalent to the Go defers: decay before trim for an existing/interior value, but only trim after a largest-value append.

Implement `Display` with exactly one total line and one line per current bin, all newline-terminated. The bar width is conversion after `count / total * 200.0`, which truncates toward zero for ordinary nonnegative counts. Match the source's spaces around the literal tab. Add focused formatting tests so an accidental idiomatic redesign cannot change this contract.

No serialized records or generated files are part of any milestone. The binary contract is successful startup with empty stdout/stderr.

### Boundary and error-handling strategy

There are no external boundaries requiring adapters. The only source-library substitutions are mechanical:

- `fmt.Sprintln` becomes writes to a Rust formatter/string.
- Go slice operations become `Vec` operations.
- Go interface dispatch becomes `dyn Histogram` or generic `H: Histogram`.
- Go's implicit pointer mutability becomes explicit `&mut self`.

Do not introduce an application error enum, exception-catching layer, logger, mock service, or fallback behavior. Propagate `fmt::Error` only through the required `Display::fmt` signature. Preserve IEEE NaN results and source sentinels. Preserve panics for impossible merges instead of catching them; a clear internal assertion is preferable to arithmetic underflow, provided it occurs for the same invalid state.

### Unit-test strategy and mockable seams

The direct translations should remain integration tests against only the public crate API:

- Port the 14,999-value fixture exactly.
- Port `approx` with strict `< 0.2`.
- Port both source tests and all stated assertions without relaxing tolerances or reducing data.
- Add a compile-only example covering every concrete method and both constructors.

No production mock trait is warranted: the complete system is already deterministic and in-memory, and no source test mocks a boundary. `Histogram` itself is the domain polymorphism seam, not an infrastructure adapter. Add a small trait-dispatch test using both real implementations; a test-local fake may be used only if a future consumer needs one, and must not enter the production crate.

Add module-local tests, where private bins can be inspected, for behavior omitted by the Go suite:

1. Empty behavior: count/mean/variance are zero, quantile is `-1`, CDF is NaN, and display is `Total: 0\n`.
2. Ordered insertion and exact duplicate aggregation.
3. Trimming, weighted-centroid calculation, repeated trimming, and leftmost tie selection.
4. Quantile boundaries (`q <= 0`, `q == 1`, `q > 1`, and NaN) and CDF endpoints.
5. Mean and population variance on a small exact distribution; after a merge, assert statistics over bins rather than raw-sample variance.
6. Numeric wrapping increment behavior at an injected near-overflow internal state.
7. `ewma` arithmetic and weighted updates with `alpha < 1`, separately covering existing-value, interior-insert, and largest-append branches. Explicitly assert that the largest append does not decay prior bins.
8. Weighted `total` recomputation, weighted merge behavior, and `alpha == 1` parity with numeric behavior.
9. Exact display layout, tab spacing, trailing newlines, and bar truncation for both histogram types.
10. Zero `maxbins` panic behavior and ordinary post-add `len <= maxbins` invariants.

Tests stay entirely offline and require no environment variables or mutable global state.

### Observable contract and milestone mapping

| Milestone | Source functionality delivered | Required contract/tests |
|---|---|---|
| 1. Crate foundation and numeric histogram | Cargo crate, `Histogram`, `Bin`, full `NumericHistogram`, root exports/constructors, numeric `Display` | Direct `TestHistogram` translation plus empty, insertion, merge/tie, statistics, quantile-boundary, overflow, and formatting tests. `cargo build` and the relevant Cargo tests must pass before claiming the milestone. |
| 2. Weighted histogram | Full `WeightedHistogram`, `ewma`, branch-specific decay, total recomputation, merge, trait implementation, weighted `Display` | Direct `TestWeightedHistogram` translation plus alpha-1 parity, alpha-below-1 branch tests, weighted statistics/merge, empty, panic, and formatting tests. |
| 3. Package-surface parity | Compiling example, silent `cmd` binary, adapted README, MIT license, complete re-exports and cross-implementation trait usage | Full `cargo build --manifest-path Cargo.toml` and `cargo test --manifest-path Cargo.toml`; validation is the same complete Cargo test command. Confirm no application data files are emitted and the binary remains silent. |

This design covers the source research and test gaps, requires no third-party runtime library or invented scaffolding, and maps every source API and observable behavior to a traceable Rust crate surface.
