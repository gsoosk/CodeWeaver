# Authoritative design: Python `bst` to JavaScript

## 1. Source Project Research

### Overview and structure

The entire source project is the single 808-line file `source/source.py`; there are no separate packages, fixtures, dependency manifests, or test files. It implements a recursive binary search tree whose nodes retain parent pointers. It also contains a small generated SKEL object/type runtime, an example program, plain-function behavioral tests, and an unconditional call to the aggregate `test()` function.

| Source path / lines | Responsibility |
|---|---|
| `source/source.py:1-36` | SKEL runtime helpers: `user_get_type`, `user_check_type`, and `SkelClass`. |
| `source/source.py:50-64` | `Node(param_0, param_1)` object factory. |
| `source/source.py:67-399` | `BinarySearchTree()` object factory and all tree operations. |
| `source/source.py:402-427` | `_get_binary_search_tree()`, which builds the canonical ten-node test tree. |
| `source/source.py:431-694` | The source's plain-function behavioral tests. |
| `source/source.py:698-781` | `binary_search_tree_example()`, including deterministic stdout. |
| `source/source.py:785-806` | Aggregate `test()` and the unconditional module-level `test()` call. |

There is no input parsing, persistence, network access, clock, randomness, concurrency, or environment-dependent behavior. Running or importing the module builds trees, prints the example, and executes assertions because `test()` is called unconditionally at `source/source.py:806`.

### SKEL runtime and object model

This is not conventional Python class syntax:

- `SkelClass(class_name, super_class=None)` creates and returns an instance of a dynamically declared class tagged with `_class_name`. Its optional `super_class` path supplies Python inheritance, although this project never uses that path.
- `Node(label, parent)` is a callable factory, not a class constructor. It creates one tagged object and installs an exposed `__init__` closure on it. Each node has mutable `label`, `parent`, `left`, and `right` attributes; both child fields start as `None`.
- `BinarySearchTree()` is likewise a zero-argument factory. It creates one tagged object, installs closures as own method attributes, invokes its exposed `__init__`, and starts with `root = None`.
- Every installed method closes over that factory invocation's `class_var`; methods do not depend on a dynamic receiver. Consequently, separate trees have separate state and even a detached method reference continues to operate on its originating tree.
- `Node.__init__` can reinitialize its originating node, and `BinarySearchTree.__init__` can reset its originating tree. These exposed properties are part of the source object's observable surface.
- `user_get_type(obj)` returns the exact descriptor string `<function NAME >` for tagged objects, using the first semicolon-delimited name, and otherwise returns Python's native type object.
- `user_check_type(obj, _type)` recognizes Python `dict`/`object` types, semicolon-delimited SKEL function descriptors, and the synthetic `func_dict` descriptor. One tagged-object branch intentionally falls through to `None`. Neither helper is called by the BST implementation or its tests.

The JavaScript port must preserve the callable factory API; replacing `Node(...)` or `BinarySearchTree()` with ES classes requiring `new` would break the source contract.

### Tree API and behavior

All labels are accepted without explicit validation and are ordered with the source's `<` and `>` branch sequence. If neither comparison is true, insertion treats the label as a duplicate. The intended and tested domain is homogeneous numeric labels.

| Symbol | Contract |
|---|---|
| `empty()` | Sets `root` to `None`; returns `None`. |
| `is_empty()` | Returns whether `root is None`. |
| `put(label)` | Recursively inserts a unique label, sets every new node's parent, and updates `root`; returns `None`. |
| `_put(node, label, parent)` | Returns the resulting subtree root. A missing subtree creates `Node(label, parent)`. |
| `search(label)` | Returns the exact matching `Node` object or propagates the missing-node exception. |
| `_search(node, label)` | Recurses left or right according to ordering and returns the matching node. |
| `remove(label)` | Searches first, then removes a leaf, a one-child node, or a two-child node; returns `None`. A missing label therefore has the same error as `search`. |
| `_reassign_nodes(node, new_children)` | Replaces `node` in its parent, or replaces the root, and repairs the replacement's parent pointer. It does not clear the removed node's stale fields. |
| `_get_lowest_node(node)` | Finds and detaches the minimum node in a subtree, promotes that node's right child in its former position, and returns the detached node. |
| `exists(label)` | Returns `True` when `search` succeeds and `False` after catching any Python `Exception` from `search`. |
| `get_max_label()` | Iteratively follows `right` pointers and returns the maximum label. |
| `get_min_label()` | Iteratively follows `left` pointers and returns the minimum label. |
| `inorder_traversal()` | Returns a lazy generator yielding `Node` references in left/node/right order. An empty tree yields no values. |
| `preorder_traversal()` | Returns a lazy generator yielding `Node` references in node/left/right order. An empty tree yields no values. |

For a two-child deletion, `remove` uses the inorder successor: `_get_lowest_node(node.right)` first detaches the successor, then the successor receives the removed node's left and current right subtrees, parent pointers are repaired, and `_reassign_nodes` places it at the removed node's old position. This detail matters when the successor is the immediate right child and when a deeper successor has its own right child.

The structural invariants visible to callers are:

- `root.parent is None`.
- Every non-null `left` child has a smaller label and `left.parent` points back to its owner.
- Every non-null `right` child has a larger label and `right.parent` points back to its owner.
- Labels are unique.
- Traversals yield live nodes, not copied labels or serialized records.

The canonical helper inserts, in order, `8, 3, 6, 1, 10, 14, 13, 4, 7, 5`. Its inorder labels are `[1, 3, 4, 5, 6, 7, 8, 10, 13, 14]`; its preorder labels are `[8, 3, 1, 6, 4, 5, 7, 10, 14, 13]`.

### Errors and return-value conventions

The source raises generic `Exception` values with exact messages:

| Condition | Message |
|---|---|
| Duplicate `put(label)` | `Node with label LABEL already exists` |
| Missing `search(label)` or `remove(label)` | `Node with label LABEL does not exist` |
| Minimum or maximum of an empty tree | `Binary search tree is empty` |

There is no recovery except the deliberate Boolean conversion in `exists`. Python's own comparison errors propagate from `put` and `search`; `exists` converts such an `Exception` to `False`. Mutators and initializers return Python `None`; public links use `None` as their empty value.

### Observable output contract

No tables, files, serialized records, or other artifacts are produced. The only external output is stdout from `binary_search_tree_example()`, called first by `test()`. The remaining test functions are silent when successful. The output comprises:

1. The literal initial-tree diagram from `source/source.py:731-743`.
2. `Label 6 exists: True`
3. `Label 13 exists: True`
4. `Label -1 exists: False`
5. `Label 12 exists: False`
6. `Inorder traversal: [1, 3, 4, 5, 6, 7, 8, 10, 13, 14]`
7. `Preorder traversal: [8, 3, 1, 6, 4, 5, 7, 10, 14, 13]`
8. `Max. label: 14`
9. `Min. label: 1`
10. A blank line followed by `Deleting elements 13, 10, 8, 3, 6, 14`.
11. The literal post-deletion diagram from `source/source.py:758-766`.
12. `Inorder traversal after delete: [1, 4, 5, 7]`
13. `Preorder traversal after delete: [4, 1, 7, 5]`
14. `Max. label: 7`
15. `Min. label: 1`

The diagram literals include leading/trailing blank lines, indentation, and backslashes. The post-deletion diagram visually places `5` on the right of `7`, but the implementation and both traversals establish that `5` is `7.left`; tree behavior and assertions take precedence over that drawing, while the literal drawing remains part of stdout.

Python formatting is observable: booleans are `True`/`False`, and lists have no space immediately inside their brackets. Raw Node.js inspection of booleans or arrays does not reproduce those strings.

### Shipped behavioral tests

The tests do not use `unittest.TestCase`, pytest fixtures, mocks, or dependency substitution. They are plain top-level functions invoked manually by `test()`:

| Test | Coverage |
|---|---|
| `test_put` (`source/source.py:431-486`) | Empty start, root/left/right/deeper insertion, labels, parent identity, and an attempted duplicate. |
| `test_search` (`source/source.py:490-501`) | Two successful searches and an attempted missing search. |
| `test_remove` (`source/source.py:505-590`) | Sequentially removes `13`, `7`, `6`, `3`, and `4`, asserting topology and parent links after leaf, one-child, and two-child cases. |
| `test_remove_2` (`source/source.py:594-622`) | Removes `3` from a fresh canonical tree and checks the deeper inorder-successor replacement. |
| `test_empty`, `test_is_empty` | Root reset and empty-state transitions. |
| `test_exists` | Present and absent Boolean results. |
| `test_get_max_label`, `test_get_min_label` | Canonical extrema and attempted empty-tree errors. |
| `test_inorder_traversal`, `test_preorder_traversal` | Exact canonical traversal label arrays. |

`binary_search_tree_example()` runs before those tests, and `test()` invokes all listed tests in a fixed order. The source's docstring suggests `python -m unittest`, but that runner discovers zero tests; importing the module merely triggers the unconditional manual suite. Method docstrings contain examples but are nested inside the factory and are not a dependable standalone discovery mechanism.

The duplicate, missing-search, and empty-extrema checks use `try/except: pass` without an `else` failure, so they do not prove that an exception was raised or that its message was correct. The target unit suite must retain the positive assertions and strengthen these weak checks with explicit throw assertions. There are no external boundaries to mock.

## 2. Third-Party Library Analysis

There are no third-party Python dependencies and no need for an npm runtime or test dependency.

| Python facility | Source use | JavaScript counterpart | Scaffolding status |
|---|---|---|---|
| `from __future__ import annotations` | No annotations are declared, so this has no runtime effect. | Omit it; neither TypeScript nor a transpiler is justified. | Native JavaScript is sufficient. |
| `collections.abc.Iterator` | Imported at `source/source.py:48` but never referenced. | ECMAScript's built-in iterator protocol and generator functions. | Built into Node.js; do not add a package. |
| Python recursion and `yield from` | Recursive insertion/search and lazy traversals. | Ordinary recursive functions plus generator delegation. | Built into JavaScript. |
| `Exception`, `assert`, and `print` | Domain errors, embedded test checks, and example stdout. | Built-in `Error`, `node:assert/strict` for tests, and `console.log` with explicit Python-compatible value formatting. | `Error`, console, and Node test modules are built in. |
| Local `SkelClass` helpers | Generated object/type emulation. | A local JavaScript object factory/tag implementation in the translated module. | This is source logic, not a library or scaffold to replace. |

The project brief names no functional target scaffolding and no high-level service calls. At analysis time `pipeline/target` does not exist. The only supplied integration constraints are in `codeweaver.toml`: the target entry file must be `pipeline/target/index.js`, syntax is checked with `node --check index.js`, and tests run through `npm test --silent`. Therefore the Translator should create only the minimal Node package metadata and source/test files described below; it must not invent repositories, adapters, logging frameworks, comparator packages, class libraries, or build tooling.

## 3. Target Project Design

### Overview and translation requirements

Implement a dependency-free CommonJS Node.js port. CommonJS avoids requiring a module-mode flag and gives the oracle a straightforward `require` surface. Preserve the source's names and callable factory style, including snake_case identifiers and underscore-prefixed helpers. Do not redesign the project as a generic configurable BST, add balancing, add value payloads, normalize labels, or replace parent-linked nodes with arrays.

Functional equivalence requires:

- The same tree topology, object identity, parent links, mutation order, returns, traversal order, and errors for the tested domain.
- `null` for Python `None` stored in `root`, `parent`, `left`, and `right`; JavaScript `undefined` for Python functions that return `None` only by falling through.
- Generic `Error` objects with the exact source messages.
- JavaScript generator objects for both traversal APIs.
- Synchronous execution only; there are no Python threads/tasks to map.
- The source's unconditional aggregate `test()` evaluation must remain observable when `index.js` is evaluated. Do not silently add a main-only guard that changes import-time behavior.
- Direct execution must emit the same example values and literal diagrams. Format booleans as `True`/`False` and arrays as brackets around comma-space-joined values rather than relying on Node's inspector formatting.

### Source-to-target structural mapping

| Source | Target | Design |
|---|---|---|
| `source/source.py` | `pipeline/target/index.js` | One-to-one translation of all runtime factories, BST methods, canonical-tree helper, example, embedded test functions, aggregate `test`, and global invocation. |
| No Python package manifest | `pipeline/target/package.json` | Minimal private CommonJS package with an `npm test` script; no dependencies. |
| Embedded plain tests | `pipeline/target/test/source.test.js` | Standalone `node:test` coverage that mirrors and strengthens the embedded tests without changing the oracle. |

`index.js` should export all source module-level symbols so the JavaScript module has the closest practical equivalent to Python module attribute access: `user_get_type`, `user_check_type`, `SkelClass`, `Node`, `BinarySearchTree`, `_get_binary_search_tree`, every `test_*` function, `binary_search_tree_example`, and `test`.

Within `index.js`:

- Keep `Node(param_0, param_1)` and `BinarySearchTree()` as normal factory functions callable without `new`.
- Preserve one closure-local `class_var` per factory invocation. Installed methods must refer to that closed object rather than dynamic `this`, preserving detached calls and instance isolation.
- Keep exact property names: `_class_name`, `__init__`, `label`, `parent`, `left`, `right`, `root`, and every public/private method name.
- `SkelClass` returns a tagged object and preserves optional prototype inheritance for its unused `super_class` case. `user_get_type` must return the exact SKEL descriptor for tagged objects. `user_check_type` must parse semicolon-delimited tags, map Python `dict`/`func_dict` to plain JavaScript dictionary objects, map Python `object` to JavaScript objects, and return `undefined` for the source's implicit-`None` path.
- Use strict identity for node and parent comparisons. Preserve the `<` branch, then the `>` branch, then duplicate error; do not pre-coerce or stringify labels for comparison.
- Translate `_inorder_traversal` and `_preorder_traversal` as recursive generators that yield node objects. Public traversal methods return those generators without eagerly materializing arrays.
- Preserve deletion ordering exactly. In particular, detach the successor before reading the removed node's now-current right subtree, then repair child parents and finally replace the removed node.
- Do not clear a removed node's fields or return it; the source does neither.

### Contract and boundary strategy

There are no infrastructure boundaries and therefore no production interface/adapter layer is warranted. The only process boundary is stdout:

- The real implementation remains the direct console output corresponding to Python `print`.
- Unit tests capture it in a fresh child process using Node's built-in `child_process` API. This avoids modifying production signatures or requiring a logger mock.
- API tests that load `index.js` should temporarily record console calls during the one required import-time `test()` execution and restore the console in a `finally` block.
- No network, filesystem, database, clock, random, or asynchronous mock implementation is needed.

Errors should be thrown at the same decision points as Python. `exists` is the one intentional broad conversion boundary: it invokes `search`, returns `true` on success, and returns `false` for an exception, matching `except Exception`. All other errors propagate. Native recursion/stack failures must not be swallowed or reshaped as successful results.

### Unit-test strategy

Use only `node:test` and `node:assert/strict`; do not add Jest, Mocha, or assertion dependencies. Never use `console.assert`, because it does not reliably fail the process. Tests live in `pipeline/target/test/source.test.js` and run via the package's `npm test` script.

Translate source coverage one-to-one:

- `test_put`: assert every label and parent identity, then use `assert.throws` for the exact duplicate message and verify topology is unchanged.
- `test_search`: assert returned node identity/label and the exact missing-node error.
- `test_remove` and `test_remove_2`: retain every topology and parent assertion after the same removal sequences.
- `test_empty` and `test_is_empty`: verify transitions and that `empty` returns `undefined`.
- `test_exists`: verify both Boolean values.
- Extrema tests: verify values plus exact errors after `empty`.
- Traversal tests: verify exact canonical arrays and that empty traversals are iterable generator objects yielding no nodes.

Add focused tests where the shipped suite is weak or silent:

- A fresh root, leaf removal, root with only a left child, and root with only a right child.
- Two-child removal where the successor is the immediate right child.
- A deeper successor that itself has a right child, proving promotion and all parent links.
- Missing `remove`, exact error messages, and unchanged tree state after failed operations.
- A recursive invariant helper that checks ordering, root parent nullity, and every child-to-parent back-reference after each deletion.
- Two simultaneous trees and detached method calls, proving closure-local rather than shared or `this`-bound state.
- Direct `Node` field initialization and the exposed initializer behavior.
- SKEL tag/type helper behavior, including semicolon-delimited tags and the implicit-`undefined` branch.
- A child-process execution test that checks exit status and the complete stdout contract, including Python-style booleans/arrays and literal diagrams.

No live infrastructure is involved, so all tests are standalone. The configured build, unit-test, and validation commands remain read-only acceptance gates; later agents must run them and retain their actual output before making any parity claim.

### Milestone mapping

| Milestone | Source functionality | Required contract and tests |
|---|---|---|
| 1. Runtime and data model | `user_get_type`, `user_check_type`, `SkelClass`, `Node`, `BinarySearchTree.__init__`, `empty`, `is_empty` | Callable factories, exact fields/tags, null links/root, isolated closure state, initializer/reset behavior; translated `test_empty` and `test_is_empty` plus SKEL/factory tests. |
| 2. Ordered operations and traversal | `put`, `_put`, `search`, `_search`, `exists`, extrema, both traversal pairs, `_get_binary_search_tree` | Exact duplicate/missing/empty errors, canonical topology, parent links, lazy node-yielding iterators, exact inorder/preorder arrays; translated put/search/exists/extrema/traversal tests. |
| 3. Deletion | `remove`, `_reassign_nodes`, `_get_lowest_node` | Leaf, one-child, root, immediate-successor, deep-successor, and successor-with-right-child behavior; translated `test_remove`/`test_remove_2` plus invariant and error tests. |
| 4. Executable integration | `binary_search_tree_example`, all embedded `test_*` functions, aggregate `test`, global invocation, exports, package test wiring | Exact deterministic stdout and zero-error suite execution through the configured Node/npm commands; child-process output test and full translated unit suite. |

**Artifact confirmation:** `/opt/codeweaver-gpt-sol-comparison/runs/full/skel__bst/rep0/pipeline/analysis.md` exists. Section 1 records the one-file Python implementation, API, data/error/output contracts, and shipped tests; Section 2 establishes that built-in Node facilities satisfy every dependency need and that no functional scaffold exists; Section 3 defines the authoritative CommonJS structure, behavioral mappings, test seams, and four implementation milestones.
