# Authoritative analysis and Python target design

Source basis: `source/` is Apache Commons FileUpload 1.5 after the AlphaTrans benchmark reduction. There is no separate reference directory. The Java tree and its tests are read-only inputs.

## 1. Source Project Research

### 1.1 Overview and scope

The project is a library, not an executable. Its intended domain is RFC 1867/MIME `multipart/*` upload handling, with:

- low-level bounded-buffer multipart parsing in `MultipartStream`;
- parsing of MIME parameters, part headers, and RFC 2047 encoded words;
- upload configuration, metadata interfaces, progress callbacks, and custom exceptions;
- disk-item metadata/factory classes and legacy aliases;
- servlet and portlet package facades.

The concrete AlphaTrans source is materially smaller than upstream Commons FileUpload 1.5. Many upstream methods remain only as Javadocs and have no declaration or body. In particular, this tree has no concrete `parseRequest`, `getItemIterator`, `readBodyData`, `discardBodyData`, `skipPreamble`, stream-copy/string helpers, disk body storage, `createItem` implementation, servlet adapter behavior, or serialization behavior. The port must translate declarations and executable bodies that actually exist; it must not reconstruct methods merely mentioned by stale Javadocs, the website, or upstream knowledge.

This distinction also affects the type graph:

- `DiskFileItem` does **not** implement `FileItem`.
- `DiskFileItemFactory` does **not** implement `FileItemFactory` and has no `createItem`.
- `FileUploadBase.FileItemIteratorImpl` does **not** implement `FileItemIterator` and contains no iteration methods.
- `FileUploadBase.FileItemIteratorImpl.FileItemStreamImpl` contains only header accessors; its documented constructor and content methods are absent.
- `ServletRequestContext` is an empty class.
- `PortletFileUpload` contains only construction behavior inherited from `FileUpload`.

Those are observable properties of this benchmark source, not gaps to fill.

### 1.2 Repository and file responsibilities

Top-level runtime/build material:

| Path | Responsibility |
|---|---|
| `pom.xml` | Declares Commons FileUpload 1.5, Java 8, JUnit 4.13.2, provided servlet/portlet APIs, Commons IO 2.11.0, and Maven/Jacoco packaging configuration. |
| `README.md` | Upstream project description; it is not an API oracle where it conflicts with executable source. |
| `src/main/java/` | The 36 Java production files to map to Python. |
| `src/test/java/` | Thirteen test/support files, containing 39 active `@Test` methods in six classes. |
| `src/changes/`, `src/site/`, `src/checkstyle/`, `src/main/assembly/` | Release, website, style, and distribution metadata. They have no runtime behavior and should not be ported. |

Every production Java file:

| Source file | Responsibility and concrete symbols |
|---|---|
| `org/apache/commons/fileupload/package-info.java` | Upstream package narrative. Several examples name classes/methods absent from this reduced tree. |
| `DefaultFileItem.java` | Deprecated subclass of `DiskFileItem`; only forwards its six constructor arguments. |
| `DefaultFileItemFactory.java` | Deprecated subclass of `DiskFileItemFactory`; explicit constructor plus `DefaultFileItemFactory1()`, which unusually creates a factory with threshold `0` and repository `null`. |
| `FileCountLimitExceededException.java` | `FileUploadException` carrying an exceeded file-count `limit`. |
| `FileItem.java` | Interface declaring body/metadata operations: `getInputStream`, content/name/size access, `get`, `getString0`, `getString1`, `write`, `delete`, field/form flags, output stream, and headers. No concrete class in this tree implements it. |
| `FileItemFactory.java` | Interface with `createItem(fieldName, contentType, isFormField, fileName)`. |
| `FileItemHeaders.java` | Case-insensitive header lookup interface with first-value, all-values, and header-name iterators. |
| `FileItemHeadersSupport.java` | Header getter/setter interface. |
| `FileItemIterator.java` | Java-shaped `hasNext()`/`next()` streaming interface. No concrete implementation is exposed in this tree. |
| `FileItemStream.java` | Streaming item interface and nested `ItemSkippedException`; documents the one-pass item-stream contract. |
| `FileUpload.java` | Concrete `FileUploadBase` subclass holding a `FileItemFactory`. Its `(constructorId, factory)` constructor assigns the factory only when `constructorId == 1`. |
| `FileUploadBase.java` | Upload constants/configuration; multipart detection; boundary, filename, field-name, and header parsing; deprecated map helpers; partially reduced private iterator types; upload exception hierarchy; progress-listener access. High-level request parsing methods are absent. |
| `FileUploadException.java` | Base checked-style exception with explicit cause storage, two static constructor substitutes, and two stack-trace output variants. |
| `InvalidFileNameException.java` | Runtime exception retaining a filename that contains NUL. |
| `MultipartStream.java` | Constant-memory buffered multipart primitive: constructors, header reads, boundary reads/replacement, KMP boundary search, byte reads, progress notification, and `ItemInputStream`. Body-copy/discard/preamble APIs documented in comments are absent. |
| `ParameterParser.java` | Stateful name/value parser supporting quoted separators and escapes, lower-cased names, four overload-substitute methods (`parse0` through `parse3`), and MIME encoded-word decoding. |
| `ProgressListener.java` | Synchronous `update(bytesRead, contentLength, items)` callback interface. |
| `RequestContext.java` | Request metadata/input-stream interface with 32-bit `getContentLength`. |
| `UploadContext.java` | `RequestContext` extension adding 64-bit `contentLength()`. |
| `disk/package-info.java` | Stale upstream disk-storage narrative. |
| `disk/DiskFileItem.java` | Metadata-only disk item in this tree: content type/charset/name, field/form state, headers, default charset, and memoized temporary-path generation. Body I/O methods are absent. |
| `disk/DiskFileItemFactory.java` | Repository, size-threshold, and default-charset configuration. `DiskFileItemFactory1()` supplies threshold `10240` and no repository. Item creation and cleanup tracking are absent. |
| `portlet/package-info.java` | Portlet package narrative. |
| `portlet/PortletFileUpload.java` | `FileUpload` subclass. Its constructor calls `super(0, fileItemFactory)`, so the supplied factory is ignored by the concrete source; `PortletFileUpload1()` supplies `null`. |
| `servlet/package-info.java` | Servlet package narrative referring to absent `ServletFileUpload`. |
| `servlet/ServletRequestContext.java` | Empty placeholder class; all request-adapter methods remain only as comments. |
| `util/package-info.java` | Utility package narrative. |
| `util/Closeable.java` | `close()`/`isClosed()` interface. |
| `util/FileItemHeadersImpl.java` | Serializable ordered, case-insensitive, multi-value header collection. `addHeader` is synchronized. |
| `util/LimitedInputStream.java` | Abstract filtering stream whose explicit `read0`/`read1` methods count bytes and invoke `raiseError` after `count > sizeMax`; tracks closure. |
| `util/Streams.java` | Contains `DEFAULT_BUFFER_SIZE` and `checkFileName` only. Copy and string conversion methods are comments without implementations. |
| `util/mime/package-info.java` | Notes that the MIME decoder was vendored from Apache Geronimo. |
| `util/mime/Base64Decoder.java` | Package-private permissive Base64 decoder with strict chunk/padding/truncation checks and a byte-count return value. |
| `util/mime/MimeUtility.java` | Public RFC 2047 text decoder supporting uppercase `B` and `Q` markers, encoded-word whitespace folding, and Java charset aliases. |
| `util/mime/ParseException.java` | Package-private encoded-word syntax exception. |
| `util/mime/QuotedPrintableDecoder.java` | Package-private RFC 2047 Q decoder with underscore-to-space conversion, hex escapes, and soft line breaks. |

### 1.3 Key API and behavioral contracts

#### Upload configuration and header interpretation

`FileUploadBase` exposes these concrete API groups:

- constants `CONTENT_TYPE`, `CONTENT_DISPOSITION`, `CONTENT_LENGTH`, `FORM_DATA`, `ATTACHMENT`, `MULTIPART`, `MULTIPART_FORM_DATA`, `MULTIPART_MIXED`, and deprecated `MAX_HEADER_SIZE`;
- `isMultipartContent(RequestContext)`, which only checks whether a non-null content type starts with `multipart/`, case-insensitively;
- abstract `getFileItemFactory`/`setFileItemFactory`;
- unvalidated getters/setters for request-size, file-size, file-count, header-encoding, and progress-listener settings; `-1` means unlimited;
- `getBoundary`, which parses the earliest `;` or `,` separator and returns ISO-8859-1 bytes, or `null`;
- overload-substitute helpers `getFileName0`, `getFileName1`, `getFieldName0`, `getFieldName2`, deprecated `createItem`, `getParsedHeaders`, deprecated `parseHeaders`, `newFileItemHeaders`, and deprecated `getHeader`.

Filename parsing accepts `form-data` or `attachment`. A present `filename` parameter with no value becomes the empty string, while an absent parameter remains `null`. Field names are accepted only for `form-data`. Both are trimmed but otherwise preserved.

Part headers:

- are terminated by an empty CRLF line;
- allow continuation lines beginning with space or tab, normalized to one joining space;
- use lower-case names and preserve first-name insertion order;
- preserve repeated values in insertion order;
- ignore a malformed line with no colon;
- raise an illegal-state error if CRLF termination is missing;
- join repeated values with `,` and no added space in deprecated `parseHeaders`.

`FileUpload` has no no-argument constructor in executable source. Its selector constructor must retain the `constructorId == 1` behavior rather than being normalized into a conventional constructor.

#### Parameter and MIME parsing

`ParameterParser` maintains mutable parser indices and is not thread-safe. Its contract includes:

- `null` input, `null` character arrays, or no separators produce an empty map;
- `parse0` chooses whichever supplied separator first occurs earliest in the input;
- leading/trailing Java whitespace and one pair of surrounding quotes are removed;
- quoted separators are retained, escaped quotes do not toggle quote state, and backslashes are not unescaped;
- omitted or empty values map to `null`;
- duplicate names overwrite earlier values;
- lower-casing applies to names only;
- a value is passed through `MimeUtility.decodeText`; an unsupported encoding is caught narrowly and leaves the original value unchanged;
- `parse3(charArray, offset, length, separator)` assigns its end index to `length`, not `offset + length`. This source behavior must remain unchanged.

`Base64Decoder.decode` ignores every non-alphabet/non-padding byte, including whitespace and arbitrary junk. It processes independent four-symbol chunks, so concatenated padded Base64 values decode successfully. Padding in either of the first two positions, a non-padding fourth position after padding in the third, or a trailing partial chunk raises an I/O error with the source message. This differs from both strict and lenient modes of Python's `base64.b64decode`.

`QuotedPrintableDecoder.decode` maps `_` to a space, decodes upper- or lower-case hex, removes `=\r\n` soft breaks, and rejects truncated escapes, invalid hex, and `=\r` not followed by LF. Its returned count intentionally does not increment for underscore-produced spaces, although the space is written.

`MimeUtility.decodeText`:

- returns the original object value immediately if it contains no `=?`;
- decodes whitespace-delimited RFC 2047 words;
- suppresses linear whitespace between adjacent successfully decoded words;
- retains malformed words by catching only internal `ParseException`;
- propagates unsupported transfer encodings and charsets;
- ignores suffix text in the same whitespace-delimited word after the first `?=`;
- maps the source aliases, notably `us-ascii`/`x-us-ascii` to ISO-8859-1.

Using Python's `email.header`, `base64`, or `quopri` behavior wholesale would not preserve these edge cases.

#### Multipart stream

`MultipartStream` stores the effective delimiter as `CRLF--` plus the caller boundary and builds a KMP table. The custom-buffer constructor:

- rejects a null boundary;
- rejects a requested buffer smaller than `boundary length + 4 + 1`;
- then allocates `max(requested size, 2 * effective boundary length)`;
- retains the caller's binary input and optional nested `ProgressNotifier`.

The named constructor substitutes must remain callable: `MultipartStream0`, `MultipartStream1`, `MultipartStream2`, and `MultipartStream3`. Notably, `MultipartStream0()` eventually supplies a null boundary and therefore raises the same illegal-argument error as the main constructor.

`readByte` refills the whole internal buffer and notifies progress by the raw refill count. `readBoundary` assumes the head is positioned at a delimiter, skips its full length, and accepts LF alone, CRLF for another part, or `--` for the final part; other/truncated markers become `MalformedStreamException`. `setBoundary` permits replacement only with the same token length. `readHeaders` returns bytes through and including CRLFCRLF, decodes with the selected encoding or the platform fallback, and rejects headers over 10,240 bytes or premature EOF.

`ItemInputStream` exposes Java-shaped `read0`, buffer-mutating `read1`, `skip`, `available`, `close0`, `close1`, `getBytesRead`, and `isClosed`. Advancing the outer parser or closing an item makes later reads raise `FileItemStream.ItemSkippedException`. Soft close drains to the next delimiter; hard close closes the underlying input. The inherited Java `close()` is not overridden in this reduced source, so the port must not silently substitute an unrelated body-reading API for the named close methods.

#### Data models and other observable values

There are no tables, records, reports, or CLI output.

- `FileItemHeadersImpl` is an insertion-ordered mapping from lower-case header name to an ordered list of original string values. First-value lookup returns `null` if absent; all-values/name lookups return empty iterators when appropriate.
- `DiskFileItem` stores field name, content type, form-field flag, original filename, threshold, optional repository, optional headers, and default charset (`ISO-8859-1`). It also initializes the reduced source's otherwise dormant `size = -1` and `cachedContent = null` fields. `getName` validates NUL through `Streams.checkFileName`. `getCharSet` parses a case-insensitive `charset` parameter.
- `DiskFileItem.getTempFile` memoizes a path but does not create it. The name is `upload_<process-class-UID>_<counter>.tmp`; the UID is one UUID with hyphens replaced by underscores, and counters below 100,000,000 are eight-digit zero-padded values. A null repository selects the system temporary directory.
- `DiskFileItemFactory` stores only repository, threshold, and default charset.
- `MultipartStream.ProgressNotifier` emits synchronous triples `(cumulative raw bytes read, configured content length, item count)`.

Thread-sensitive source behavior is limited to synchronized header insertion and the atomic disk-item filename counter. There are no worker threads, tasks, or network clients.

### 1.4 Error handling

Source-defined exception metadata is part of the API:

| Exception | Contract |
|---|---|
| `FileUploadException` | Message plus explicit nullable cause; `FileUploadException0/1` are constructor substitutes. |
| `FileCountLimitExceededException` | Adds `getLimit`. |
| `InvalidFileNameException` | Retains the original NUL-containing name via `getName`; its message renders each NUL as the two characters `\0`. |
| `FileUploadBase.FileUploadIOException` | I/O wrapper whose cause is a `FileUploadException`. |
| `FileUploadBase.InvalidContentTypeException` | Message/cause upload error; only the two-argument constructor exists. |
| `FileUploadBase.IOFileUploadException` | Upload error retaining an I/O cause. |
| `FileUploadBase.SizeException` | Abstract upload error with actual and permitted sizes. |
| `UnknownSizeException` | Deprecated message-only upload error. |
| `SizeLimitExceededException` | Request-size error plus `SizeLimitExceededException0/1` constructor substitutes. |
| `FileSizeLimitExceededException` | Size metadata plus mutable filename and field name. |
| `MultipartStream.MalformedStreamException` | Malformed/truncated multipart I/O error. |
| `MultipartStream.IllegalBoundaryException` | Different-length nested boundary I/O error. |
| `FileItemStream.ItemSkippedException` | Read-after-item-advance/close I/O error. |
| `util.mime.ParseException` | Internal malformed encoded-word error, selectively swallowed by `decodeText`. |

The port should preserve only the source's intentional fallback points: malformed encoded words remain literal, unsupported parameter-value decoding leaves the value literal, an unparseable private part content length becomes `-1`, and an unavailable requested header charset falls back to the platform charset. Other errors must propagate with their metadata and source message.

### 1.5 Dependencies

The production POM declares Commons IO 2.11.0 and provided servlet/portlet APIs, but the reduced production Java has no imports from any of them. All executable imports are JDK classes or classes within this project. Commons IO's `FileCleaningTracker` and servlet/portlet types occur only in comments. The MIME code is vendored source, not a runtime dependency.

The active tests depend only on JUnit 4 and JDK streams/collections. Maven/Jacoco are build and coverage tooling.

### 1.6 Shipped unit tests and boundary mocking

There are exactly 39 active JUnit tests:

| Test/support file | Active tests and asserted behavior |
|---|---|
| `FileItemHeadersTest.java` | 1; lower-case insertion order, case-insensitive first/all lookup, repeated-value order, and empty missing-header iteration. |
| `ParameterParserTest.java` | 5; optional/quoted/escaped values, earliest separator, lower-case names, empty tokens, and adjacent MIME words in a filename. |
| `MultipartStreamTest.java` | 3; minimum valid custom buffer, too-small rejection, and `MultipartStream2` construction. Uses `ByteArrayInputStream`; no live request boundary. |
| `util/mime/Base64DecoderTestCase.java` | 13; RFC 4648 vectors, concatenated padded blocks, junk filtering, strict truncation/padding errors, and non-ASCII replacement input. |
| `util/mime/QuotedPrintableDecoderTestCase.java` | 11; plain/escaped data, lower-case hex, underscores, soft breaks, malformed CR, invalid hex, and truncation. |
| `util/mime/MimeUtilityTestCase.java` | 6; no-op text, UTF-8 Q/B, adjacent ISO encoded words with folded whitespace/trailing text, and unsupported encoding. |
| `DefaultFileItemTest.java` | No active `@Test`; constants and a private string helper remain after reduction. |
| `DiskFileItemSerializeTest.java` | No active `@Test`; byte/serialization helpers remain, but `DiskFileItem` is not serializable in this source. |
| `ProgressListenerTest.java` | No active `@Test`; contains a recording/asserting listener helper only. |
| `Constants.java` | Test constant `multipart/form-data; boundary=---1234`. |
| `Util.java` | Empty support class after reduction. |
| `MockHttpServletRequest.java` | Handwritten request fake with bytes, content type, length, read-limit state, and mostly null/default servlet stubs. Its outer `getInputStream` body is absent, so active tests do not use it. |
| `portlet/MockPortletActionRequest.java` | Handwritten portlet fake with attributes, parameters, metadata, and a `ByteArrayInputStream`; active tests do not use it. |

There is no Mockito or other mocking library. Boundaries are represented by `ByteArrayInputStream`, `ByteArrayOutputStream`, small handwritten fakes, and an inner `ProgressListenerImpl`. This favors structural protocols and in-memory test doubles in Python rather than framework integration or live infrastructure.

## 2. Third-Party Library Analysis

### 2.1 Source dependencies and Python counterparts

| Java dependency/facility | How this source uses it | Recommended Python counterpart | Scaffolding status |
|---|---|---|---|
| Commons IO 2.11.0 | No executable use. `FileCleaningTracker` is mentioned only in stale disk Javadocs; deferred/temp body streams and copy helpers have been removed. | No dependency. Use `io`, `pathlib`, and `tempfile` only for behavior that exists. Do not create a cleanup tracker or body-storage layer. | No project scaffold supplies it, and none is needed. |
| Servlet API 2.4 | No imports or executable adapter behavior. `ServletRequestContext` is empty. | No Flask, Django, Werkzeug, or WSGI dependency. Preserve the empty namespace class and use the generic `RequestContext` protocol for tests. | No servlet/web scaffold is provided. |
| Portlet API 1.0 | No imports. `PortletFileUpload` is only a constructor facade; the test fake is standalone. | No Python dependency. Preserve the package facade and use test doubles. | No portlet scaffold is provided. |
| JUnit 4.13.2 | Assertions, expected-exception annotations, and test discovery. | `pytest`, with `pytest.raises` for expected exceptions and plain assertions. | **Already supplied:** the configured command is `/opt/codeweaver-venv/bin/python -m pytest -q`. Do not add or vendor a runner. |
| Java I/O (`InputStream`, `OutputStream`, `ByteArray*`, `FilterInputStream`) | All parser/codec byte boundaries. | `io.BytesIO` and injected binary readable/writable objects. Add thin internal adaptation for Java's integer-byte and buffer-mutating read contracts. | Python 3.12 standard library is available; no project-specific wrapper is provided. |
| Java files/temp APIs | Memoized path construction only in executable disk code. | `pathlib.Path`, `tempfile.gettempdir`, `uuid.uuid4`, and a lock-protected counter. | Standard library; no file scaffold exists. |
| Java collections/concurrency | Ordered multi-map, ordinary maps/lists, synchronized insertion, atomic counter. | Built-in insertion-ordered `dict`, `list`, `threading.RLock`/`Lock`, and an integer counter. | Standard library. |
| Java charset APIs | ISO/UTF decoding, Java alias mapping, fallback/default encoding, unsupported-encoding errors. | `codecs.lookup`, explicit alias normalization, `locale.getpreferredencoding(False)` only where the source requests platform fallback. | Standard library. |
| Vendored Geronimo MIME decoder | Exact permissive Base64, strict Q decoding, and RFC 2047 token handling. | Faithful local translation of the source algorithms. Python `base64`, `quopri`, and `email.header` may assist only after proving identical behavior for a path; they cannot replace the public algorithms wholesale. | No MIME scaffold is provided. |
| Maven compiler/Jacoco | Java compilation and coverage only. | None. | **Already replaced by harness:** `compileall` is the build check and pytest is unit/validation. |

Local comparison confirms why direct standard-codec substitution is unsafe: Python's lenient Base64 decoder stops after the first padded block, strict mode rejects concatenation, lenient mode accepts an extra `=` that the source calls truncated, `quopri` does not raise the source's malformed-input errors, and `email.header.decode_header` preserves suffix text that this source discards.

### 2.2 Dependency decision

No new runtime package is justified. The target should be standard-library-only. The only provided scaffolding is the Python 3.12 environment, pytest runner, `compileall` build command, and `pipeline/target` working directory. There is no supplied application framework, request adapter, file-item implementation, MIME helper, or package skeleton to extend. Consequently, no high-level framework calls replace Java servlet/portlet calls; those calls do not exist in the executable source.

## 3. Target Project Design

### 3.1 Translation requirements

The target root is `pipeline/target`. Functional equivalence is measured against the concrete AlphaTrans Java bodies and the shipped behavioral tests, not against upstream Commons FileUpload documentation.

Mandatory rules for later agents:

1. Keep `source/` and all Java tests unchanged.
2. Preserve Java public class names, constants, camelCase methods, nested exception qualification, and AlphaTrans overload names such as `parse0`, `read1`, `close0`, and `MultipartStream2`.
3. Preserve selector/static-constructor behavior exactly. Do not normalize away `constructorId`, the `*1()` factories, or their surprising defaults.
4. Do not add absent upstream APIs such as `parseRequest`, `ServletFileUpload`, disk body storage, stream copying, or serialization.
5. Use Python type hints and structural protocols/ABCs, but do not make `DiskFileItem` or `DiskFileItemFactory` satisfy interfaces their Java declarations do not satisfy.
6. Keep all parsing synchronous and streaming; do not introduce threads, async code, or unbounded multipart-body buffering.
7. Preserve exact error categories, metadata, and tested message fragments.

### 3.2 Source-to-target structural mapping

Use namespace packages rooted at `org/apache/commons/fileupload`, one snake-case module per executable Java file, and `__init__.py` files for each Java `package-info.java`. Re-export public Java-style names from package `__init__.py` files so callers can use either the traceable module or package API.

```text
pipeline/target/
  org/
    __init__.py
    apache/
      __init__.py
      commons/
        __init__.py
        fileupload/
          __init__.py
          default_file_item.py
          default_file_item_factory.py
          file_count_limit_exceeded_exception.py
          file_item.py
          file_item_factory.py
          file_item_headers.py
          file_item_headers_support.py
          file_item_iterator.py
          file_item_stream.py
          file_upload.py
          file_upload_base.py
          file_upload_exception.py
          invalid_file_name_exception.py
          multipart_stream.py
          parameter_parser.py
          progress_listener.py
          request_context.py
          upload_context.py
          disk/
            __init__.py
            disk_file_item.py
            disk_file_item_factory.py
          portlet/
            __init__.py
            portlet_file_upload.py
          servlet/
            __init__.py
            servlet_request_context.py
          util/
            __init__.py
            closeable.py
            file_item_headers_impl.py
            limited_input_stream.py
            streams.py
            mime/
              __init__.py
              base64_decoder.py
              mime_utility.py
              parse_exception.py
              quoted_printable_decoder.py
  tests/
    support.py
    test_file_item_headers.py
    test_parameter_parser.py
    test_multipart_stream.py
    test_base64_decoder.py
    test_quoted_printable_decoder.py
    test_mime_utility.py
    test_upload_base.py
    test_disk_and_facades.py
    test_stream_utilities.py
```

Direct structural rules:

- Java interfaces become non-instantiable `typing.Protocol` or `abc.ABC` contracts with the same method names. `UploadContext` extends `RequestContext`; `FileItem` extends header support.
- `FileUploadBase` and `LimitedInputStream` remain abstract. `FileUpload` supplies the two factory methods.
- Java nested public classes remain reachable as attributes such as `MultipartStream.ProgressNotifier`, `MultipartStream.ItemInputStream`, `FileUploadBase.SizeLimitExceededException`, and `FileItemStream.ItemSkippedException`. They may be defined at module scope internally if Python class-definition ordering requires it, but their public qualification must be bound.
- Java package-private MIME classes remain importable by sibling modules and tests but are not re-exported as public package API.
- Java private iterator classes become module-private/nested implementation details; only the concrete header access and private content-length behavior present in source are translated.
- Deprecated markers become docstrings/deprecation metadata only; deprecated methods remain functional.
- `ServletRequestContext` remains an empty placeholder. No `ServletFileUpload` module is created because there is no source file.

### 3.3 Type and idiom mapping

| Java concept | Python design |
|---|---|
| `null` | `None`, represented with `Optional[...]`. |
| `byte[]` | `bytes` for immutable inputs/results and `bytearray` for destination buffers/internal mutable storage. Preserve byte values modulo 256 and Java signed-byte behavior where a public method returns `byte`. |
| `InputStream`/`OutputStream` | Injected binary readable/writable objects. Internal helpers bridge Python `read(n) -> bytes` to Java `read0() -> int/-1` and `read1(buffer, off, len) -> count/-1`. |
| `File` | `pathlib.Path`; accept `str`/path-like values at boundaries only if normalized once. |
| `Map<String,String>` | `dict[str, Optional[str]]`. Parameter-map order is not a contract; header-map order is. |
| Java iterator | Python iterator for header names/values. Keep Java-shaped `hasNext`/`next` declarations on `FileItemIterator`. |
| Java checked `IOException` | `OSError`/`IOError` subclasses for custom stream exceptions. |
| `IllegalArgumentException` | `ValueError`. |
| `IllegalStateException` | `RuntimeError`. |
| `NoSuchElementException` | `StopIteration` for actual Python iteration, while retaining `next()` if implemented by a source-backed class. |
| `UnsupportedEncodingException` | `LookupError` (or a narrowly defined subclass) with source-compatible messages. |
| `RuntimeException` for invalid filename | Source-named `InvalidFileNameException`, preferably also a `ValueError`. |
| Java explicit exception cause | Store a nullable cause and expose `getCause`; set Python chaining when raised without losing explicit access. |
| `synchronized`/`AtomicInteger` | Locks around header mutation and unique counter increments only. |
| Java default encoding | `locale.getpreferredencoding(False)` only in source fallback paths; all protocol encodings remain explicit. |
| `Character.isWhitespace` | A small Java-compatible whitespace predicate. Python `str.isspace()` is broader and must not silently change token parsing. |

Do not rename methods to snake case. Optional Python conveniences may be additive only when they cannot change Java-shaped behavior. In particular, `ItemInputStream.read()` with no arguments must retain the source's single-byte integer result; any Python-sized read convenience must dispatch without changing that case.

### 3.4 Module behavior and observable contract

#### MIME and parameter modules

Translate the decoding loops, not merely their happy paths. Preserve:

- Base64 junk skipping, concatenated padded chunks, returned byte count, and all padding/truncation branches;
- quoted-printable underscore output/count mismatch, soft-break handling, and error text;
- encoded-word token boundaries, adjacent-token whitespace suppression, trailing-suffix behavior, case-sensitive `B`/`Q`, and charset alias map;
- parameter parser's mutable state, quote/escape logic, null values, earliest-separator rule, exact `parse3` length behavior, and narrow unsupported-encoding fallback.

Encoding helpers must use replacement behavior where Java's named `getBytes` replaces unmappable characters. They must not globally choose permissive decoding.

#### Header/security modules

`FileItemHeadersImpl` uses a lock-protected insertion-ordered dictionary of lists. Lookups lower names with English/ASCII-compatible `.lower()`, return first values without copying semantics that reorder them, and yield empty iterators for misses. `Streams.checkFileName` returns `None` unchanged, returns a valid name unchanged, and raises with the original name plus escaped-NUL message otherwise.

#### Multipart module

Keep a fixed-size internal `bytearray`, KMP boundary table, `head`/`tail`, keep-region, and notifier state. Reads from injected streams must tolerate ordinary short reads while preserving source refill/progress accounting. EOF maps to `-1` internally where Java expects it.

`ItemInputStream` must share and mutate the outer stream's buffer positions. It is not an independent copy. `close1(False)` drains only the current item; `close1(True)` owns and closes the underlying stream. Reads after its source `closed` flag is set raise the nested skipped exception. No missing body-copy or preamble methods are to be synthesized.

#### Upload/disk/facade modules

`FileUploadBase` should expose only concrete source helpers and configuration. A protected-method test subclass can make header/boundary helpers observable in tests. Factory creation remains a call through the injected `FileItemFactory`; no default factory is invented.

Preserve these non-obvious constructor outcomes:

- `FileUpload(1, factory)` stores `factory`; every other selector leaves it `None`.
- `PortletFileUpload(factory)` leaves its inherited factory `None` because it selects `0`.
- `PortletFileUpload1()` also has no factory.
- `DiskFileItemFactory1()` has threshold `10240`.
- `DefaultFileItemFactory1()` has threshold `0`.
- `MultipartStream0()` raises for its null boundary.

`DiskFileItem` remains metadata/path-only. Its temp path is lazy, stable per instance, unique across instances, and not created by `getTempFile`. Do not implement the body methods represented only by comments or make the class pickle-compatible based on the inactive serialization fixture.

### 3.5 Boundary and error-handling strategy

There is no provided high-level application scaffold to call. Boundary replacements are therefore direct and explicit:

| Source boundary | Target boundary |
|---|---|
| Caller-provided Java `InputStream` | Caller-provided Python binary readable object, normally `io.BytesIO` in unit tests. |
| Caller-provided Java `OutputStream` | Caller-provided Python binary writable object. Decoder internals write one-byte `bytes` values, not integers. |
| `RequestContext`/`UploadContext` | Structural protocol supplied by caller; tests use a fake with metadata and `io.BytesIO`. No HTTP server is involved. |
| `FileItemFactory` | Structural protocol; tests inject a recording stub. No default disk factory is substituted because the source disk factory lacks `createItem`. |
| `ProgressListener` | Structural protocol/object with synchronous `update`; tests inject a recorder. |
| Java temp directory/property and `File` | `tempfile.gettempdir()` and `pathlib.Path`; tests inject `tmp_path` repositories. |
| Maven/JUnit commands | Harness-provided `compileall` and `python -m pytest -q`. |

Catch only exceptions caught by source at the same boundary. Codec lookup failures, malformed streams, invalid boundaries, NUL names, and limit violations must remain failures, not success-shaped fallbacks. When converting a low-level exception, retain it in `getCause` and use Python exception chaining. Error-message tests should assert the source's stable text fragments rather than Python traceback formatting.

Resource ownership must be explicit. Multipart construction does not close the caller stream. `ItemInputStream.close1(True)` does; soft close does not. Temporary paths are not created or deleted by the executable disk-item source.

### 3.6 Unit-test strategy

Translate all 39 active source tests one-for-one into the six corresponding pytest modules. Preserve vectors and assertions, including exception message substrings. Java tests with no `@Test` are not direct test cases:

- do not create serialization tests from `DiskFileItemSerializeTest`;
- do not infer disk body-storage tests from `DefaultFileItemTest`;
- reuse the intent of `ProgressListenerImpl` only as a recorder for behavior that exists;
- keep `Constants`, `Util`, and request fakes as support only where useful.

Put reusable doubles in `tests/support.py`:

| Test double | Seam and assertions |
|---|---|
| `FakeRequestContext` / `FakeUploadContext` | Supplies encoding, content type, 32/64-bit length, and an `io.BytesIO`; supports `isMultipartContent` and future helper tests without servlet infrastructure. |
| `RecordingProgressListener` | Captures update triples and checks cumulative bytes/items are monotonic and bounded as in `ProgressListenerTest.ProgressListenerImpl`. |
| `RecordingFileItemFactory` and minimal `FileItem` stub | Records `createItem` arguments for `FileUploadBase.createItem`; avoids pretending `DiskFileItemFactory` implements the interface. |
| `ChunkedBinaryIO` | Returns controlled short chunks to force boundary overlap, refill, progress, and header-limit paths. |
| `FailingBinaryIO` / failing writer | Raises deterministic `OSError` to verify propagation and wrapping. |

Add focused tests for executable source not covered by active Java tests:

- `FileUploadBase`: defaults/setters, multipart detection, earliest-separator boundaries, filename/field rules, folded and repeated headers, ignored malformed lines, missing CRLF, deprecated map combination, and exception metadata.
- `MultipartStream`: null boundary, all constructor substitutes, `readByte`, progress refills, `readBoundary` marker variants, same/different-length replacement, header charset/fallback/size/EOF, KMP overlap, item reads/skips, soft/hard close, and read-after-close.
- utilities: exact-limit and limit-plus-one `LimitedInputStream` reads, closure state, valid/NUL filenames, ordered concurrent header insertion at the lock seam.
- disk/facades: metadata mutation, charset parsing, stable/unique temp paths under `tmp_path`, no path creation, exact factory defaults, selector constructor behavior, and empty servlet placeholder.
- exceptions: message, cause, actual/permitted/limit values, and mutable file/field metadata.

Tests remain fully local: `io.BytesIO`, deterministic fake streams, and pytest's `tmp_path`. No servlet container, portlet runtime, network, subprocess, clock, database, or live filesystem location is required.

### 3.7 Milestone and oracle mapping

No milestones are predeclared in `codeweaver.toml`; use this dependency-ordered plan:

| Milestone | Source functionality | Observable contract | Source tests landing here |
|---|---|---|---|
| 1. MIME codecs | `Base64Decoder`, `QuotedPrintableDecoder`, `ParseException`, `MimeUtility` | Exact decoded bytes/text, byte counts, adjacent-word folding, charset behavior, and malformed-input errors. | All 13 Base64, 11 quoted-printable, and 6 MIME tests (30). |
| 2. Parameters, headers, and filename safety | `ParameterParser`, header interfaces/implementation, `Streams`, `InvalidFileNameException` | Optional/quoted values, earliest separators, MIME parameter decoding, ordered case-insensitive multi-headers, and NUL rejection. | All 5 parameter and 1 header tests (6), plus new filename tests. |
| 3. Multipart streaming and progress | `MultipartStream`, `ProgressListener`, `Closeable`, `LimitedInputStream`, `FileItemStream` | Constructor validation, fixed-buffer/KMP parsing, header/boundary results, stream state, limit failures, and progress triples. | All 3 multipart tests, plus focused stream/progress tests. |
| 4. Upload API and exceptions | `RequestContext`, `UploadContext`, `FileItem*` protocols, `FileUploadException`, `FileCountLimitExceededException`, `FileUploadBase`, `FileUpload` | Constants/defaults, selector factory behavior, header/boundary interpretation, factory delegation, and complete exception metadata. | No active source test directly covers this reduced surface; add the focused tests above. |
| 5. Disk metadata, legacy aliases, and facades | `DiskFileItem`, `DiskFileItemFactory`, `DefaultFileItem`, `DefaultFileItemFactory`, `PortletFileUpload`, `ServletRequestContext` | Metadata/charset values, lazy non-created temp paths, exact default thresholds, legacy inheritance, ignored portlet factory, and empty servlet class. | Inactive Java fixtures inform data vectors only; add exact-source tests, then run the complete 39-test translation and all added tests together. |

Each milestone must first pass its targeted pytest modules. Final parity requires the configured `compileall`, full `pytest -q`, and validation commands against `pipeline/target`; this document makes no unexecuted parity claim.
