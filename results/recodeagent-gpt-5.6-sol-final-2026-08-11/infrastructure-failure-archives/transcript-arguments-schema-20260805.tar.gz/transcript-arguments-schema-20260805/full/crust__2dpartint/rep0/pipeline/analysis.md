# 2dpartint C-to-Rust Analysis and Target Design

## 1. Source Project Research

### Scope and evidence

The local source is a partial snapshot. The implemented C kernel is in
`source/src/functions.c` and `source/src/collisions.c`; the remaining local
modules are represented only by headers under `source/src/include/`.
`source/Makefile` still references absent `src/cpp/{config,csv,debug,initialization,main}.cpp`
files and an undefined `SRC_CXX_DIR`, so the local tree is not a complete
standalone application build. There is no supplied reference directory. The
README, sample configuration, C files, headers, and tests are nevertheless
enough to establish the numerical kernel, collision ordering, data model, and
declared I/O surface. The immutable Rust scaffold is the authority where its
observable test contract differs from the C test driver.

The project models equal-radius circular particles in a two-dimensional
geotechnical simulation. Each step conceptually:

1. bins particles by center into a rectangular spatial grid;
2. emits directed contacts for strictly overlapping particles;
3. accumulates normal and tangential contact forces and gravity;
4. derives acceleration, velocity, and accumulated displacement;
5. moves particles, converting displacement by a factor of 1000; and
6. clamps particles to the floor at `y = radius`.

The README also declares configuration parsing and ParaView-compatible CSV
output. The omitted driver is referenced by the Makefile but is outside the
provided C implementation and outside the scaffold's executable interface.

### Directory and file responsibilities

| Path | Responsibility |
|---|---|
| `source/src/functions.c` | Numerical mechanics: distance, overlap, gravity, contact force integration, acceleration, velocity, displacement, movement, and floor correction. |
| `source/src/collisions.c` | Grid coordinate lookup, particle binning through per-cell linked lists, and directed contact discovery. |
| `source/src/include/data.h` | `Particle`, `ParticleProperties`, `Vector`, and `Contact` records. |
| `source/src/include/functions.h` | Public numerical API. It also declares `size_triangular_matrix`, for which this snapshot has no C definition. |
| `source/src/include/collisions.h` | Public grid-filling and contact-discovery API. The helper functions are implemented in C even though they are not declared here. |
| `source/src/include/config.h` | Fourteen-field `Config` record and `parse_config` declaration. |
| `source/src/include/initialization.h` | `initialize`, which returns the initialized particle count; implementation is absent locally. |
| `source/src/include/csv.h` | Folder creation and three output writers: simulation particles, grid cells, and particles traversed from the grid. |
| `source/src/include/debug.h` | Debug header/value/file writers; this C++-oriented header accepts `std::ofstream`. |
| `source/test/functions_spec.c` | Hand-written behavioral tests for the numerical kernel. |
| `source/example_simulation_config.txt` | A valid configuration containing every mandatory key. |
| `source/README.md` | Program purpose, build/CLI usage, grid-domain semantics, and configuration grammar. |
| `source/Makefile` | C11/C++11 build, `-lm`, coverage flags, optional debug/profiling modes, and the C test target. |
| `source/simulacion.gif` | Documentation asset; it has no runtime role. |

### Data model and API surface

- `Config` contains `simulation_time`, `dt`, particle and grid dimensions,
  `square_in_grid_length`, `radius`, normal/tangential rigidities `kn`/`ks`,
  density `rho`, `thickness`, initial falling velocity `v0`, and falling radius
  `r0`. The README says all keys are mandatory and may appear in any order.
- `Particle` contains `x_coordinate`, `y_coordinate`, `radius`, a mutable
  singly-linked `next` pointer used only while binned, and stable integer `idx`.
- `ParticleProperties` contains `mass`, `kn`, and `ks`.
- `Vector` contains `x_component` and `y_component`.
- `Contact` contains directed particle indices `p1_idx` and `p2_idx` plus the
  positive geometric `overlap`.
- The grid is a flat row-major array of cell heads, accompanied during filling
  by a parallel array of cell tails. Particle centers outside the grid are not
  considered for collision discovery, but the README says their existing
  forces remain in effect.
- Normal and tangential histories are full row-major `n * n` matrices. For a
  directed contact `p1 -> p2`, the C kernel uses offset
  `p1_idx * particles_size + p2_idx`. `Contact.overlap` is recorded but is not
  consumed by `compute_forces`; distance is recomputed from particle positions.

### Numerical behavior that must be preserved

- `compute_distance` evaluates `sqrt(dx*dx + dy*dy)` in that operation order.
  `compute_overlap` returns `p1.radius + p2.radius - distance`; zero means
  touching but not overlapping.
- `apply_gravity` subtracts `mass * 9.81` from each existing Y force. It does
  not clear the force buffer.
- A directed collision uses the normal `(p1.position - p2.position) / distance`
  and relative velocity `v2 - v1`. It increments prior normal and tangential
  histories by `normal_velocity * kn_destination * dt` and
  `tangent_velocity * ks_destination * dt`.
- A negative updated normal force resets both histories to zero. Tangential
  force is capped to `normal * 0.5773502691896257`, preserving its sign. The
  exact literal, rather than a newly evaluated tangent, should be retained.
- The resulting force is added to the destination particle. Histories for
  absent contacts are retained unchanged.
- The current C `compute_forces` processes one direction per `Contact`, then
  applies gravity. `compute_contacts` emits both directions for every physical
  pair, so the complete C simulation obtains both reactions from two records.
- Acceleration is component-wise `force / mass`. Velocity and displacement are
  additive: `v += a*dt` and `d += v*dt`.
- `displace_particle` adds `displacement * 1000` to both coordinates. It uses
  the accumulated displacement rather than resetting it.
- Despite the header comment mentioning both axes, `fix_displacement` only
  enforces the floor: if `y - radius < 0`, it sets `y = radius` and Y velocity
  to zero. It does not alter X or reset displacement.
- Floating-point degeneracies are not checked in C. Zero distance or mass
  therefore follows IEEE-754 `NaN`/infinity behavior; the Rust port must not
  silently substitute a physically different result.

### Collision behavior and ordering

- The X domain is
  `[-x_squares*square_length/2, x_squares*square_length/2)`; the left boundary
  is inclusive and the right boundary exclusive. `find_col` returns `-2`
  below the left boundary and `-1` at or beyond the right boundary.
- The Y domain is `[0, y_squares*square_length)` with corresponding `-2`
  below and `-1` at or above the top.
- `find_square` returns row-major `row*x_squares + col`, or `-1` for either
  out-of-domain coordinate.
- `fill_grid` resets every particle's `next`, skips out-of-domain centers, and
  appends in original particle order. The caller is responsible for clearing
  both grid arrays before each fill.
- `compute_contacts` visits cells row-major and particles in insertion order.
  For each particle it first compares every other particle in the same cell,
  then candidate cells in row-major order within the square bounding a
  `2*radius` neighborhood. It records only `overlap > 0`, excludes self-pairs,
  and emits both directed orientations as traversal reaches each particle.
  Contact order is observable and must remain deterministic.
- The C API has no output-capacity argument; an undersized contact buffer and
  invalid pointers/indices are undefined behavior.

### Observable files and records

The local headers establish these outputs, while the local snapshot omits their
implementations. The historical project behavior associated with these exact
headers is the design target for scaffold functions:

| Function | File and record contract |
|---|---|
| `ensure_output_folder` | Ensure the supplied directory and parents exist; return `0` on success and nonzero on failure. |
| `write_simulation_step` | Truncate `2DPartInt-Out.csv.{step}`. Header: `x coord, y coord, z coord, radius`. Emit one row per input particle in slice order: X, Y, literal `0`, radius. |
| `write_grid` | Truncate `2DPartInt-Out-GRID.csv`. Header: `x coord, y coord, length`. Emit one row per cell in row-major order using each cell's lower-left X/Y coordinate and `square_length`. |
| `write_particles_from_grid` | Truncate `2DPartInt-Out-FROM-GRID.csv.{step}`. Traverse cells row-major and particles in cell order. Historical behavior writes header `x coord, y coord, length` but four row fields: X, Y, literal `0`, radius; preserve that quirk if this surface is tested. |
| `write_debug_information` | Write `step_{step}_part_{particle_index}`. The report begins with `SIMULATION STEP: ... PARTICLE: ...`, then 16 fixed-width fields (`x_coor`, `y_coor`, `radius`, `mass`, `kn`, `ks`, normal/tangent force, force, acceleration, velocity, displacement components), followed by a `CONTACTS` table with `p1_idx`, `p2_idx`, and `overlap`. |

There is no target CLI in the scaffold, so these files are produced only when
their public library functions are called; no simulation loop or stdout
contract should be invented.

### Source error handling and dependencies

The C numerical code assumes valid pointers, dimensions, indices, matrix
lengths, and output capacity. It has no status/error type. Grid lookup uses
negative sentinels rather than exceptions. Invalid floating-point inputs
propagate naturally. The hand-written test executable returns failure if any
assertion failed.

The declared configuration and output APIs also have no rich error channel:
`parse_config` and writers return `void`, while folder creation returns an
integer status. The target must therefore use internal fallible helpers and
surface descriptive panics only where the immutable public signature cannot
return an error; it must not ignore failures.

Runtime dependencies are the C/C++ standard libraries and `libm`. The Makefile
uses GCC/G++, shell `mkdir`/`rm`, gcov-style coverage flags, and optionally
gperftools when `PROFILING` is set. There is no required third-party library.

### Behavioral tests and boundary mocking

`source/test/functions_spec.c` uses fixed in-memory records and a custom
absolute tolerance of `0.00005`. It defines tests for:

- acceleration with one and three particles;
- velocity with one and three particles;
- displacement-to-position conversion with one and three particles; and
- one-contact and three-contact force cases.

Only the six acceleration, velocity, and movement tests are called by the C
`main`. The two force tests are explicitly commented out because current
collision discovery emits both directed contacts while those fixtures supply
one contact and expect both reactions.

There are no mocks because every active source test exercises pure in-memory
math. No source tests cover collision discovery, configuration, initialization,
 CSV/debug output, error paths, gravity alone, overlap, floor correction, or
the declared-but-undefined `size_triangular_matrix`.

The immutable scaffold's `scaffold/src/bin/test.rs` is stricter than the C test
driver: it activates all eight tests, including both force fixtures, and uses
the same absolute tolerance. Consequently, the public Rust `compute_forces`
must apply both orientations for each supplied contact to satisfy the actual
oracle. This is an intentional scaffold adapter, not permission to alter the
directed helper or collision detector. The assertion's `NaN` comparison would
not fail, but the port must produce the finite expected values rather than
exploit that defect.

## 2. Third-Party Library Analysis

No new crate is warranted. `scaffold/Cargo.toml` and `Cargo.lock` intentionally
contain no dependencies, and the provided modules, records, signatures, and
test target already supply the architectural scaffold.

| C/C++ facility | Source use | Idiomatic Rust counterpart | Scaffold status / decision |
|---|---|---|---|
| `libm` (`sqrt`, `fabs`, `floor`) | Distance, friction cap, and grid indexing | Inherent `f64` operations: square root, absolute value, and floor | Available in `std`; preserve source expression order. Do not add a math crate. |
| `<stdlib.h>` allocation/free | Arrays and zero-initialized simulation buffers | Owned vectors, `Option`, and automatic drop | `data.rs` already fixes the public records, including `Option<Box<Particle>>`. No `libc`, FFI, or manual allocation. |
| Raw pointers and linked lists | Mutable output arrays and cell chains | Slices plus an internal vector of per-cell particle references/indices | Public slice/reference forms are already scaffolded. Do not add a linked-list crate. |
| `memset`/C array initialization | Clear forces and grid heads | Slice filling or freshly initialized vectors | Standard library only. Force histories must not be cleared accidentally. |
| C++ streams and numeric conversion | Config parsing and text output | `std::fs`, `std::io`, `std::path`, and standard numeric parsing | Public path strings and `std::fs::File` are already scaffolded. Use private fallible adapters; no parser framework. |
| Shell `mkdir -p` | Output directory creation | `std::fs::create_dir_all` | Replaces shell execution and avoids quoting/injection problems. No process crate. |
| Hand-written test/assert framework | Approximate numerical checks | Built-in `#[test]` and a local tolerance helper | `scaffold/src/bin/test.rs` already provides the oracle. Do not add `approx`. |
| Make/GCC/G++/gcov | Build and coverage | Cargo build/test profiles | Fully replaced by the supplied Cargo project. Do not reproduce the Makefile. |
| Optional gperftools | C profiling mode only | Cargo/release profiling outside functional code | Not part of the observable scaffold contract; add no profiling dependency. |

The trivial, fixed CSV layouts do not justify `csv` or `serde`. Manual writing
is both sufficient and more faithful to spacing, headers, ordering, and the
historical inconsistent grid-particle header.

## 3. Target Project Design

### Translation requirements and authority order

The target remains the supplied Rust 2021 crate named exactly `twoDPartInt`.
Do not rename the crate, modules, public records, fields, functions, argument
types, return types, or `src/bin/test.rs`. Do not add a production CLI absent
from the scaffold. Functional authority is:

1. immutable scaffold API and `scaffold/src/bin/test.rs`;
2. implemented local C behavior on valid inputs;
3. local headers and README for otherwise unimplemented surfaces; and
4. deterministic, explicit Rust failure behavior where C was undefined.

The configured build gate is `cargo build --manifest-path Cargo.toml`; both the
unit-test and validation gates are `cargo test --manifest-path Cargo.toml`,
executed from `pipeline/target`. These are required later gates, not claims made
by this analysis.

### Source-to-target structural mapping

| Source | Target | Required mapping |
|---|---|---|
| `include/data.h` | `src/data.rs` | Preserve all four scaffold structs and field types. C `NULL` maps to `None`; `size_t` maps to `usize`; `int` maps to `i32`. |
| `functions.c` / `functions.h` | `src/functions.rs` | Preserve every scaffold function. Use slices for arrays and private helpers for scalar in/out state. |
| `collisions.c` / `collisions.h` | `src/collisions.rs` | Preserve lookup sentinel values, row-major ordering, strict overlap, and directed duplicate contacts. |
| `config.h` | `src/config.rs` | Keep `Config`; replace C's out-parameter parser with scaffolded `Config::parse_config`. |
| `initialization.h` | `Config::initialize`, `Config::compute_mass`, and private helpers associated with `src/initialization.rs` | The scaffold moves initialization onto `Config`; do not add a competing public initializer. |
| `csv.h` | `src/csv.rs` | Preserve the four fixed public functions and exact output ordering. |
| `debug.h` | `src/debug.rs` | Replace `std::ofstream&` with the scaffolded `&mut std::fs::File`; keep format logic behind writer-generic private helpers. |
| C test driver | `src/bin/test.rs` plus module-local tests | The scaffold test binary is read-only. Add missing standalone coverage inside `#[cfg(test)]` modules only. |
| Omitted C++ `main`/globals | No public target counterpart | Use owned local state in helpers; do not recreate global mutable arrays or a CLI. |

No concurrency is present or needed. C pointer aliasing becomes borrowing and
owned collections; C/C++ exceptions or status codes become private `Result`
values. Public scaffold methods that cannot return `Result` terminate with a
descriptive panic after preserving the original error context.

### Module-level design

#### `data.rs`

Treat scaffold definitions as immutable API. `Particle.next` is an owned
recursive representation and cannot safely reproduce C's borrowed links into a
particle array. Collision logic should therefore use per-cell vectors and
stable `idx` values rather than cloning particle chains. `next` remains for
interface compatibility and CSV/debug traversal inputs.

#### `functions.rs`

Implement all scalar operations directly and preserve constants and evaluation
order. Add a private directed-collision helper that accepts mutable normal and
tangential history slots and a mutable destination force. It is the faithful
translation of C `collide_two_particles`.

The scaffolded public `collide_two_particles` cannot expose the C side effects:
its prior forces are passed by value, `forces_p2` is immutable, and it returns
nothing; it also adds an extra `properties_p1` parameter. Do not change that
signature. It may delegate to the private helper on local copies, while
`compute_forces` uses the real mutable helper.

For each prefix contact selected by `contacts_size`, public `compute_forces`
must invoke the directed helper twice, once in each orientation, updating
matrix offsets `p1*n+p2` and `p2*n+p1`. Apply gravity only after all contact
directions. This adapter is required by the immutable force tests. Validate
slice and checked `n*n` shape invariants before indexing, but retain IEEE
behavior for zero mass/distance.

Implement `size_triangular_matrix` as the number of unordered off-diagonal
pairs, `n*(n-1)/2`, with checked arithmetic and correct zero/one behavior. It is
declared but unused in the supplied C snapshot; full force-history storage
remains `n*n`.

#### `collisions.rs`

Use a private safe grid representation conceptually equivalent to a row-major
vector of cells, each containing particle references in input order.
`compute_contacts` can consume the scaffold's read-only vector-of-cell view
directly. It must write the caller's `Contact` slice in C traversal order,
return the number written, and fail explicitly if capacity is insufficient.

The public `fill_grid` signature is not capable of expressing its C contract
safely: it receives an immutable particle slice and shared references to
containers holding mutable references. Safe Rust cannot reset `Particle.next`
or mutably borrow those inner vectors through the shared outer references.
Do not use unsafe aliasing or change the public interface. Keep the symbol as a
compatibility adapter, put actual binning in a private safe builder, and do not
make the unusable adapter part of the simulation path. If a future oracle
requires observable mutation through this exact signature, report it as an
immutable-scaffold incompatibility rather than hiding a no-op.

#### `config.rs` and `initialization.rs`

Parse the `time` key into `simulation_time`; support all fourteen mandatory
keys in arbitrary order and skip empty lines. Duplicate recognized keys use
the last value, matching sequential assignment. Parse integer fields as
`i32`; preserve the historical single-precision conversion of `radius` before
storing it as `f64`, while other real fields parse as `f64`. Unknown or
malformed lines should carry line/key context. Build through an internal
fallible parser, then have the fixed infallible public method panic
descriptively for unreadable files, invalid numbers, or missing mandatory
fields instead of constructing partially initialized state.

`compute_mass` is `rho * thickness * PI * radius^2`. The observable
`initialize` result is `x_particles * y_particles + 1`, using checked
nonnegative conversions and arithmetic. A private state initializer may model
the historical packed particles for tests: ordinary particles begin at
`x = radius - x_particles*radius`, `y = radius`, use diameter spacing, and the
falling particle is index zero at X zero and
`y = 2*y_particles*radius + 4*radius` with initial Y velocity `v0`. The
historical initialization uses `radius` for every particle and does not use
`r0`; preserve that behavior. Do not introduce hidden process-global state
merely to imitate omitted C++ globals.

`initialization.rs` remains the scaffolded module location for private
initialization support; it must not export a second public API.

#### `csv.rs` and `debug.rs`

Use `Path` joining internally and truncate outputs. Keep deterministic
row-major/slice ordering and exact headers/file names listed in Section 1.
Implement formatting once in private writer-generic helpers so tests can use an
in-memory byte buffer. Public wrappers perform real filesystem operations.

The debug scaffold omits all simulation arrays that the original global-state
writer consumed. Do not add mutable globals or fabricate values. Separate
header formatting, snapshot-value formatting, and file creation internally;
the parameter-only public surface can reproduce only information actually
available to it unless called from a private path carrying a complete
snapshot. Do not terminate the entire Rust process from a reusable library
writer; debug-stop behavior belonged to the omitted driver.

`ensure_output_folder` maps successful `create_dir_all` to `0` and failure to a
stable nonzero status. Other fixed `()` writers must panic with path and I/O
operation context on failure because their signatures provide no error return.

### Observable oracle contract

All comparisons in `src/bin/test.rs` use absolute tolerance `0.00005`.
The kinematics cases require the exact source formulas and expected arrays
already encoded in that file. The force cases additionally require:

| Fixture | Required observable result |
|---|---|
| One contact, particles 0 and 1 | Resultant forces approximately `(-3.858892943, -93.03497946)` and `(3.858892943, 92.07359946)`; both history orientations become normal `92.53595901628790` and tangent `4.275960624`. |
| Three contacts from particle 1 to particles 0, 2, and 8 | Resultant forces for indices 1, 0, 2, 8 match the scaffold values; matrix offsets `1`, `19`, `73`, `9`, `11`, and `17` must match the scaffold's normal/tangent expectations. This proves both orientations, retained prior history, friction limiting, and gravity order. |

The port must also preserve mutation scope: only the selected indices/history
slots change, `forces` are accumulated rather than reset, and
`contacts_size` selects a prefix rather than assuming the entire contact slice.

### Boundary and error-handling strategy

- Add a private config-reader abstraction with a standard filesystem
  implementation and an in-memory test implementation.
- Add a private output-filesystem/sink abstraction for directory creation and
  writer creation. The production implementation uses `std::fs`; unit tests
  use an in-memory writer and injected failures.
- Make formatting helpers generic over `std::io::Write`; `Vec<u8>` is the mock
  sink. Public `write_header`/`write_values` remain exactly scaffolded.
- Keep numerical and collision functions pure over supplied records/slices;
  they need no mocks or live infrastructure.
- Assert memory-shape preconditions with useful messages before mutation so a
  malformed call cannot partially update buffers. Do not catch all errors,
  return success-shaped defaults, silently truncate contacts, or substitute
  zero for invalid physics.

### Unit-test strategy

Keep mocks and module tests in `#[cfg(test)]` submodules beside the relevant
implementation; do not add a live service, network dependency, or external
test crate.

- Translate the six active C tests directly into `functions.rs` tests, retaining
  constants and absolute tolerance. The immutable binary already covers them,
  but local tests make the source-to-target correspondence explicit.
- Treat the two scaffold force tests as authoritative adaptations. Add focused
  directed-helper tests for negative-normal reset, positive/negative Coulomb
  caps, history indexing, gravity-after-contact order, and unchanged unrelated
  slots.
- Add collision tests for every inclusive/exclusive boundary, out-of-grid
  centers, same-cell and neighboring-cell contacts, strict zero-overlap
  exclusion, directed duplication, deterministic order, and insufficient
  output capacity. Test the private safe grid builder rather than unsafe
  mutation through the defective public `fill_grid` signature.
- Add config tests using the in-memory reader for arbitrary ordering, blank
  lines, duplicate keys, every missing key, invalid numbers, unknown keys, and
  the sample file's exact values. Add mass/count/packed-layout tests for the
  private initializer, including zero/negative dimension rejection and `r0`
  remaining unused.
- Add golden-byte CSV tests for names, headers, spacing, row order, overwrite
  semantics, the four-field/header quirk, empty inputs, and injected create/
  write failures.
- Add debug writer tests against an in-memory buffer for the 16-column header,
  field widths/precision, and contacts table. Test public `File` wrappers with
  a uniquely named temporary file only; clean it up deterministically.

### Milestone mapping

| Milestone | Source functionality | Tests and contract delivered |
|---|---|---|
| 1. Data and scalar mechanics | `data.h`; distance, overlap, gravity, acceleration, velocity, displacement, movement, floor correction, triangular size | Six active C tests translated; new scalar/boundary tests. Preserve constants, accumulation, 1000 conversion, and Y-only floor. |
| 2. Contact force solver and oracle adapter | `collide_two_particles`, `compute_forces` | Both immutable force tests pass through two directed helper calls per scaffold contact; focused history/friction/gravity tests pass. This milestone completes the configured numerical oracle. |
| 3. Spatial grid and contact discovery | `collisions.c` | Boundary sentinel, safe private binning, contact order, strict overlap, directed duplication, and capacity tests pass. Public scaffold signatures remain unchanged. |
| 4. Configuration and initialization | `config.h`, `initialization.h`, README/sample grammar | Reader-mock parser tests, exact mass/count, private packed-state layout, deterministic invalid-input behavior, and no global state. |
| 5. CSV/debug boundaries and final integration | `csv.h`, `debug.h`, all module exports | In-memory/golden output and injected-failure tests pass; crate builds with no added dependencies; the immutable Cargo test target remains untouched. The Validator then runs the configured build, unit-test, and validation commands before making any parity claim. |

This document's three sections establish the local source behavior and gaps,
the dependency-free Rust library choices already supported by the scaffold,
and the authoritative module, boundary, test, output, and milestone design for
the port.
