# 1. Source Project Research

## Scope and overview

The supplied Java source is a function extraction rather than a complete buildable Java repository. `source/source_function.java:1-4` contains the entire source behavior for the Apache Milagro `big::set` task:

- It is a public instance method named `set`.
- It accepts an integer index and a signed 64-bit `long` value.
- It writes that value directly into the receiver's `w` storage at the requested index.
- It returns `void` and performs no arithmetic, normalization, masking, allocation, I/O, logging, or external call.

`source/target_contract.md` supplies the paper-provided target context: the Rust method signature, `Big { w: [Chunk; NLEN] }`, the architecture-specific integer aliases, and the surrounding imports. No separate reference material was provided.

## Source directory structure

| Path | Responsibility |
|---|---|
| `source/source_function.java` | Authoritative four-line Java behavior for `set(int i, long x)`. No enclosing package or class declaration is included in the extraction. |
| `source/target_contract.md` | Read-only dependency context fixing the Rust signature, `Big.w` representation, and existing imports/types that the port must use. |

There are no Java build files, manifests, production classes beyond the extracted method, test directories, fixtures, or generated records under `source/`.

## Key API, data model, and contract

The source API is `public void set(int i, long x)`. The only referenced state is the receiver's indexed field `w`. The target context makes that state concrete as `Big.w`, a fixed-length array of `Chunk` values:

- `NLEN` is the number of limbs and is computed in `scaffold/src/big.rs:30` from each feature module's `rom::MODBYTES` and `rom::BASEBITS`.
- `Chunk` is `i64` on 64-bit targets (`scaffold/src/arch/arch64.rs`) and `i32` on 32-bit targets (`scaffold/src/arch/arch32.rs`).
- `Big::get` at `scaffold/src/big.rs:128-130` exposes the corresponding read operation.
- The missing target is exactly `Big::set` at `scaffold/src/big.rs:135-137`.

For an in-range index, the observable postcondition is exact replacement of one limb: the selected element has the supplied `Chunk` value and every other element retains its previous value. The value is not constrained to `BMASK`, and the method must not call `norm`, propagate a carry, truncate bits beyond the already-fixed `Chunk` type, or alter the top limb specially. Repeated calls to the same index simply overwrite the prior value.

There are no tables, files, records, network messages, console output, or global-state effects. The only output is the receiver's in-memory mutation, observable through `Big::get`, the public `w` field, and downstream arithmetic.

## Error handling and language semantics

The Java method has no explicit validation or exception handling. Native Java array semantics raise `ArrayIndexOutOfBoundsException` for a negative index or an index at or beyond the array length, before any store occurs. A null array would raise `NullPointerException`, but the provided Rust model embeds `[Chunk; NLEN]` directly and therefore has no nullable-array state.

The fixed Rust signature uses `usize`, so negative indices are excluded by the type system. An index `i >= NLEN` should retain ordinary Rust fixed-array indexing behavior and panic; it must not be clamped, wrapped, ignored, converted into an `Option`/`Result`, or routed through `AmclError`. The exclusive `&mut self` receiver also replaces Java's unrestricted mutable receiver with Rust's compile-time aliasing guarantee. There are no threads, tasks, callbacks, or asynchronous concerns.

## Dependencies and surrounding consumers

The Java extraction contains no imports and uses no third-party dependency. It relies only on Java primitive types, instance-field access, and built-in array indexing.

The target context names existing internal modules (`DBig`, `RAND`, `rom`, and `arch`) and Rust standard-library facilities (`Ordering` and `fmt`), but `set` itself needs none of them beyond the already-declared `Chunk`, `Big.w`, and `NLEN` array type. Relevant existing consumers demonstrate why raw limb replacement must be preserved:

- `DBig::split` calls `Big::set` while constructing the high half (`scaffold/src/dbig.rs:63-75`); `FP` and `FF` reduction paths call `DBig::split`.
- `FF::set` stores a small integer into limb zero through `Big::set` (`scaffold/src/ff.rs:90-94`), and RSA code uses that higher-level setter.
- `Big::xor_top` and the rest of `big.rs` operate directly on the same limb representation.

## Source and scaffold test survey

No behavioral unit tests ship in `source/`: there are no JUnit annotations, test classes, test dependencies, fixtures, or mock definitions. Consequently, there is no source mocking pattern to translate and no external boundary to abstract.

The immutable Rust scaffold does contain the relevant standalone oracle surface:

- `scaffold/src/big.rs:1266-1277`, `test_get_set`, starts from zero and exercises every valid index in `0..NLEN`, checking each write through `get`.
- `scaffold/src/big.rs:1279-1289`, `test_xor_top`, uses `set` on `NLEN - 1` and verifies a subsequent top-limb XOR.
- `DBig::split`, `FF::set`, finite-field, elliptic-curve, pairing, BLS, MPIN, and RSA paths provide indirect integration coverage.

`src/big.rs` is reused under 29 feature-gated curve/RSA namespaces in `scaffold/src/lib.rs`; with `--all-features`, its seven inline tests are instantiated in every namespace (203 test instances), alongside the other project tests. `prepared.json` records an oracle total of 284 tests and 73 negative-control failures with the missing implementation, confirming that this small setter is exercised broadly. The direct `Big` tests allocate only local values and use no mock or live infrastructure.

# 2. Third-Party Library Analysis

## Java dependencies and Rust counterparts

There are no significant Java libraries to replace. The complete mapping is language/runtime functionality already provided by Rust and the scaffold:

| Java facility | Source use | Idiomatic Rust counterpart | Provisioning decision |
|---|---|---|---|
| `long` | Limb value passed without conversion | `crate::arch::Chunk`, fixed by the required signature | Already provided; use the parameter as-is. |
| `int` | Array index | `usize`, fixed by the required signature | Already provided; do not add casts or signed-index handling. |
| Java array field `w` | Indexed mutable limb storage | `Big.w: [Chunk; NLEN]` | Already provided; do not replace it with `Vec`, a big-integer crate, or a wrapper. |
| JVM array bounds check | Fail-fast invalid-index behavior | Native Rust fixed-array indexing panic | Provided by `core`; do not add a custom error dependency. |

The target contract's `DBig` and `RAND` are internal AMCL modules, while `std::cmp::Ordering` and `std::fmt` are standard-library APIs. They support other `Big` methods and require no translation or new abstraction for this setter.

## Existing scaffold dependencies

`scaffold/Cargo.toml` has no production `[dependencies]`. Its existing dev dependencies (`hex`, `serde`, `serde_derive`, `serde_json`, `criterion`, and `rand`) support the broader tests, vectors, and benchmarks; their transitive packages in `Cargo.lock` are unrelated to `Big::set`. All are already supplied by the immutable scaffold. The translation must not add, remove, upgrade, or reconfigure any crate. In particular, a general-purpose big-integer crate, bounds-checking helper, error crate, mocking crate, or property-testing crate would duplicate behavior already represented by the scaffold and violate the one-body-only scope.

# 3. Target Project Design

## Overview and translation requirements

Functional equivalence is measured by the configured full-project oracle, but the permitted production change is narrower: later agents must first copy `scaffold/` to `pipeline/target`, then replace only the explicit `panic!("RustRepoTrans translation required")` body in `pipeline/target/src/big.rs`. They must preserve the signature, visibility, documentation, imports, `Big` representation, feature wiring, manifests, lockfile, tests, benches, fuzz targets, and every other function byte-for-byte. They must not edit `source/` or `scaffold/`, and must not search for or recover the withheld golden Rust body.

The replacement must express one native indexed mutation and nothing else. It must preserve exact `Chunk` values, including zero, negative values, and architecture-specific extrema; preserve all nonselected limbs; return unit; and retain the target language's standard out-of-range panic.

## Source-to-target structural mapping

| Source construct | Target construct | Required semantic mapping |
|---|---|---|
| Extracted Milagro `big::set` instance method | `Big::set` in `pipeline/target/src/big.rs` | Keep the existing public method and name. |
| Implicit Java receiver | `&mut self` | Mutate the existing `Big` in place; no clone or replacement object. |
| `int i` | `usize i` | Use the required index directly. Negative Java indices have no representable target value. |
| `long x` | `Chunk x` | Store exactly the supplied target-native limb; no cast, mask, or normalization. |
| Receiver field `w` | `self.w: [Chunk; NLEN]` | Update exactly one fixed-array element and preserve the array shape and all other elements. |
| Java `void` | Rust unit return | Do not introduce a return value or error result. |
| Java array-bounds exception | Rust indexing panic | Use the built-in fail-fast boundary; do not catch or translate it to `AmclError`. |
| Java nullable references | Embedded Rust array and borrowed receiver | No `Option`, null sentinel, or null check is needed or permitted. |
| Java mutable object access | Exclusive Rust mutable borrow | No synchronization primitive, task, thread, or interior mutability is needed. |

Identifiers remain traceable: source `set`, `i`, `x`, and `w` correspond directly to the existing Rust method, parameters, and field. Rust's established `Big` CamelCase type name and snake_case module layout must remain unchanged.

## Target module structure

No module is to be added or moved. The relevant preserved structure in `pipeline/target` is:

- `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml`: existing package, dependency, feature, and toolchain metadata.
- `src/lib.rs`: exposes the shared `big.rs` under 29 feature modules: `anssi`, `bls24`, `bls48`, `bls381`, `bls383`, `bls461`, `bn254`, `bn254cx`, `brainpool`, `c25519`, `c41417`, `ed25519`, `fp256bn`, `fp512bn`, `goldilocks`, `hifive`, `nist256`, `nist384`, `nist521`, `nums256e`, `nums256w`, `nums384e`, `nums384w`, `nums512e`, `nums512w`, `rsa2048`, `rsa3072`, `rsa4096`, and `secp256k1`.
- `src/big.rs`: shared `Big` implementation and inline unit tests; this is the sole implementation file and sole function body in scope.
- `src/arch/arch32.rs` and `src/arch/arch64.rs`: existing `Chunk` aliases selected by target pointer width.
- `src/roms/*`: feature-specific `BASEBITS` and `MODBYTES`, which determine each `NLEN`.
- `src/dbig.rs` and `src/ff.rs`: direct consumers of `Big::set`.
- Remaining `src/*`, `benches/*`, and `fuzz/*`: unchanged indirect consumers and validation surfaces.

Because the same `big.rs` is compiled in every enabled namespace, the implementation must be independent of a particular curve, `MODBYTES`, `BASEBITS`, `NLEN`, or pointer width.

## Observable contract mapping

For every feature-specific `Big`, each successful call must satisfy all of these postconditions:

1. The limb at the requested in-range index equals `x` exactly.
2. Every limb at an index other than `i` is unchanged.
3. The value is not reduced modulo `BMASK`, normalized, shifted, sign-adjusted, or propagated to an adjacent limb.
4. The method has no returned payload, allocation, I/O, global mutation, or callback.
5. A later `get(i)` and direct inspection of public `w[i]` observe the same stored value.
6. An index at or above `NLEN` panics through ordinary fixed-array bounds checking without a successful mutation. Negative indices are excluded by `usize`.

On the current 64-bit build, `Chunk` is `i64`, matching Java `long`; on a supported 32-bit target, the scaffold intentionally defines the method over `i32`. No body-level architecture branch is required.

## Boundary and error-handling strategy

There is no infrastructure boundary. The Java primitive array store maps directly to the scaffold's fixed-array operation; no high-level service, filesystem, network, randomness, serialization, clock, environment, or database call needs replacement. `DBig`, `RAND`, and ROM constants must not be invoked by the setter.

The method remains infallible at the type-signature level for valid indices. Native panic behavior is the appropriate target equivalent for a programmer-supplied invalid index. `src/errors.rs::AmclError` describes unrelated cryptographic validation failures and must not be expanded or used. Adding preflight guards, silent early returns, `get_mut` fallbacks, custom panic text, `Option`, or `Result` would alter the established public contract.

## Unit-test strategy

No trait or mockable seam should be introduced: the operation is a pure in-memory state mutation with no external collaborator. A real/mock pair would add indirection without a boundary and would violate the immutable scaffold constraint. Mocks therefore live nowhere.

No Java tests exist to translate. No new Rust test should be added because the brief permits only replacement of the missing body and forbids rewriting the test oracle. The authoritative direct tests remain in `src/big.rs`'s existing `#[cfg(test)] mod tests`, especially `test_get_set` and `test_xor_top`; indirect tests remain in their existing modules. These tests already run without live infrastructure. Later agents must not weaken, skip, mock, delete, rename, or edit any of them.

Validation must use the exact configured commands from the repository root after the working copy and body replacement:

1. Build gate: `cd pipeline/target && cargo +nightly-2025-09-15 check --all --all-features`.
2. Full oracle: `cd pipeline/target && cargo +nightly-2025-09-15 test --all --all-features --release`.

The expected full-suite count recorded in `prepared.json` is 284. A narrower feature run, debug-only run, individual test selector, ignored-test change, or mock substitution is not an acceptable final gate.

## Milestone mapping

| Milestone | Allowed work | Source behavior and test coverage landed | Exit contract |
|---|---|---|---|
| 1. Materialize immutable target | Copy `scaffold/` to `pipeline/target` without editing either input tree. | No translation yet; all package layout, feature modules, direct tests, indirect tests, benches, and fuzz targets become the working copy. | The copied target differs from the scaffold only by filesystem location and still contains the single explicit translation panic. |
| 2. Translate `big::set` | Replace only the panic body in `pipeline/target/src/big.rs`; change no interface or other text. | The complete four-line Java method semantics land in the one Rust method. Existing `test_get_set` covers every valid limb, `test_xor_top` covers top-limb composition, and `DBig::split`/`FF::set` plus higher cryptographic tests cover consumers. | Exact one-limb replacement, preservation of other limbs, unit return, and native bounds panic hold for all 29 feature namespaces and both `Chunk` configurations. |
| 3. Full validation gate | Run the configured all-feature check and release test commands without altering tests or flags. | All translated behavior is exercised through the immutable 284-test project oracle. | Both commands exit successfully; no test is skipped, weakened, mocked, or rewritten, and no file outside the single permitted body has changed. |

This analysis establishes the source behavior, confirms that no third-party replacement is needed, and defines the one-body-only Rust design, unchanged test strategy, and full-project validation milestones.
