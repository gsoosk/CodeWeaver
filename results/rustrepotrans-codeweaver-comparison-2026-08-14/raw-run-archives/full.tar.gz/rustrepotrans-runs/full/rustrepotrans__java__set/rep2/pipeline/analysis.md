# 1. Source Project Research

## Scope and behavior

The supplied Java source is an extracted Apache Milagro `BIG` setter rather than a complete Java repository. `source/source_function.java` contains one public instance method:

- `set(int i, long x)` returns `void`.
- Its sole operation assigns `x` directly to `w[i]`.
- It does not copy, mask, normalize, validate, allocate, log, or perform arithmetic.
- The observable result is mutation of exactly the selected limb. Every other limb retains its previous value.

The declaring class and field declaration are not included in the Java fixture. The task name (`big::set`) and `source/target_contract.md` resolve the target context: the corresponding target object is `Big`, whose limb storage is `w`.

## Supplied structure and responsibilities

| Path | Responsibility |
| --- | --- |
| `source/source_function.java` | Authoritative source behavior: direct indexed limb replacement. |
| `source/target_contract.md` | Authoritative Rust signature and dependency/type context, including `Big { w: [Chunk; NLEN] }`. |
| `scaffold/src/big.rs` | Immutable target module shared by curve/RSA feature modules. Defines `Big`, `NLEN`, `get`, the missing `set`, and all big-integer operations. |
| `scaffold/src/arch/arch32.rs` | Existing 32-bit architecture aliases: `Chunk = i32`, `DChunk = i64`, `CHUNK = 32`. |
| `scaffold/src/arch/arch64.rs` | Existing 64-bit architecture aliases: `Chunk = i64`, `DChunk = i128`, `CHUNK = 64`. |
| `scaffold/src/lib.rs` | Selects the architecture module by pointer width and reuses `src/big.rs` under each enabled curve/RSA namespace. |
| `scaffold/src/roms/*.rs` | Existing per-feature `BASEBITS` and `MODBYTES` values used to derive `NLEN`. |
| `scaffold/src/dbig.rs` | Defines `DBig`; `DBig::split` calls `Big::set` for generated upper limbs. |
| `scaffold/src/ff.rs` | Defines multi-precision `FF`; `FF::set` calls `Big::set(0, ...)`. |

## Data model and API contract

The Java API accepts a signed 32-bit index and a signed 64-bit value. Java array assignment stores the `long` bit pattern without normalization. The target API is fixed by the brief as `Big::set(&mut self, i: usize, x: Chunk)`:

- `Big::w` is a fixed-size `[Chunk; NLEN]`.
- `NLEN` is `1 + (8 * MODBYTES - 1) / BASEBITS`, so its value varies with the enclosing feature's ROM.
- `Chunk` is selected by the existing architecture scaffold and must not be replaced with a new integer abstraction.
- `&mut self` expresses the source instance mutation; the implicit Rust return is unit, matching Java `void`.
- The source identifiers `set`, `i`, `x`, and `w` already map directly to the scaffold.

There are no records, tables, files, serialized values, stdout messages, or network effects. The complete output contract is the post-call contents of `Big::w` plus normal bounds-failure behavior.

## Error handling

The source performs no explicit validation or exception handling. Java's array access throws `ArrayIndexOutOfBoundsException` for a negative index or an index at least equal to the array length. In Rust, `usize` makes negative indices unrepresentable, while ordinary fixed-array indexing panics for `i >= NLEN`. The target must preserve that native bounds check rather than silently ignore, clamp, wrap, or return an error. Safe Rust references also remove Java's possible null-receiver state; no `Option`, `Result`, or custom error is needed.

## Dependencies

The extracted method has no imports and uses no third-party Java library. It relies only on Java primitive `int`/`long`, mutable instance state, and JVM array-index semantics. Although the broader scaffold is a cryptographic library, this setter does not call random-number generation, formatting, comparison, `DBig`, ROM arithmetic, or any cryptographic primitive.

## Behavioral tests and boundary mocking

The `source/` tree contains only the function and contract files. It ships no Java unit-test class, build manifest, fixtures, or mocking framework, so there are no source tests to translate and no mocked Java boundaries to reproduce.

The immutable Rust scaffold already supplies relevant standalone tests in `scaffold/src/big.rs`:

- `tests::test_get_set` starts from `Big::new`, traverses every valid index in `0..NLEN`, stores a distinct positive `Chunk`, and checks the value through `Big::get`.
- `tests::test_xor_top` seeds the highest valid limb through `set`, applies `xor_top`, and verifies the resulting limb.

Because `src/big.rs` is reused by enabled feature modules, these tests exercise the same setter against feature-specific `NLEN` values. `DBig::split` and `FF::set` provide integration call sites covered by the full project suite. No source or target boundary requires a live service, filesystem, clock, process, or network, so mocks are neither present nor appropriate.

# 2. Third-Party Library Analysis

There are no significant Java third-party dependencies to replace. All required equivalents are already provided by the scaffold:

| Source need | Idiomatic Rust counterpart | Scaffold status |
| --- | --- | --- |
| Java `long` limb value | Architecture-selected signed integer alias | Already provided as `crate::arch::Chunk`; use it unchanged. |
| Java limb array `w` | Fixed-size Rust array | Already provided as `Big::w: [Chunk; NLEN]`. |
| Java array bounds enforcement | Native Rust fixed-array indexing panic | Built into the language; no validation crate or helper is needed. |
| Mutable instance method | Exclusive mutable receiver | Already fixed as `&mut self`. |
| Java `void` | Rust unit return | Already represented by the signature's omitted return type. |

`scaffold/Cargo.toml` has no normal runtime dependencies. Its existing dev dependencies (`hex`, `serde`, `serde_json`, `serde_derive`, `criterion`, and `rand`) support unrelated tests and benchmarks and are not needed by `Big::set`. Likewise, the existing `DBig`, `RAND`, `Ordering`, `fmt`, and ROM imports in `big.rs` serve the rest of that shared module, not this method.

Do not add `num-bigint`, an indexing crate, a checked-access wrapper, a mocking crate, or any other dependency. Such additions would duplicate scaffold functionality, broaden the allowed edit, and risk changing the source contract.

# 3. Target Project Design

## Overview and translation requirements

The later translation stage must first copy `scaffold/` to `pipeline/target` without modifying `source/` or `scaffold/`. In the copy, it must replace only the explicit `panic!("RustRepoTrans translation required")` body of `Big::set` in `pipeline/target/src/big.rs`. All signatures, visibility, comments, constants, modules, manifests, lockfiles, feature definitions, tests, and unrelated implementation must remain byte-for-byte as supplied.

Functional equivalence requires one direct indexed replacement of the selected limb with `x`. The implementation must not mask with `BMASK`, normalize the `Big`, cast or transform `x`, alter another limb, add a pre-check, catch a panic, or return a status. It must not search for or recover a withheld golden Rust body.

## Source-to-target structural mapping

| Java source construct | Rust target construct | Required semantic mapping |
| --- | --- | --- |
| Enclosing `BIG` object (omitted from fixture) | `big::Big` | Preserve the existing Rust naming convention and scaffold type. |
| Mutable field `w` | `Big::w: [Chunk; NLEN]` | Use the existing fixed storage; do not replace or resize it. |
| `public void set(int i, long x)` | `pub fn set(&mut self, i: usize, x: Chunk)` | Preserve the supplied public interface exactly. |
| `w[i] = x` | Direct mutation of the same indexed target limb | Store exactly `x`, with no additional operation. |
| Java implicit receiver mutation | Rust `&mut self` | Exclusive mutation is enforced by the type system. |
| Java array exception | Rust indexing panic | Retain native failure for `i >= NLEN`; do not introduce `Result`. |
| Java nullability | Safe non-null Rust reference | No option type is necessary. |

The source uses no exceptions beyond implicit array bounds, nullable values, threads, tasks, callbacks, or interfaces. Therefore there is no exception-to-error enum, null-to-option conversion, concurrency mapping, or trait abstraction to design.

## Target module structure

The target remains the copied Cargo project:

```text
pipeline/target/
├── Cargo.toml
├── Cargo.lock
├── rust-toolchain.toml
└── src/
    ├── lib.rs
    ├── big.rs
    ├── dbig.rs
    ├── ff.rs
    ├── arch/
    │   ├── arch32.rs
    │   └── arch64.rs
    └── roms/
        └── existing feature-specific ROM modules
```

Only the placeholder body in `src/big.rs` is in scope. `lib.rs` must continue selecting `arch32` or `arch64` and mounting the shared `big.rs` under each feature namespace. No new module, trait, helper, test file, dependency, or public item is warranted.

## Observable contract

For every enabled module and its feature-specific `NLEN`:

1. Given a valid `i` in `0..NLEN`, the call returns unit after setting limb `i` to exactly `x`.
2. Every limb whose index differs from `i` remains unchanged.
3. Values are accepted across the full signed `Chunk` domain, including zero and negative values; no limb normalization or `BMASK` truncation occurs.
4. Repeated calls at the same index replace the prior value.
5. Index `NLEN` and every larger representable index panic through Rust's normal array bounds check.
6. There is no external output or side effect beyond mutation of the receiver.

These properties preserve direct callers: `Big::get` observes the assigned value, `xor_top` operates on a seeded top limb, `DBig::split` can populate each result limb, and `FF::set` can seed limb zero.

## Boundary and error-handling strategy

There is no external boundary to wrap. The existing fixed array is the storage boundary, and Rust's built-in indexing is the exact replacement for Java's array access. Do not use `get_mut`, conditional early returns, clamping, unsafe unchecked indexing, logging, or a custom error. A direct indexed mutation naturally preserves both success and out-of-range failure semantics.

The method is deterministic and allocation-free. It neither consumes randomness nor handles secrets through an external API. No provided high-level scaffold call needs replacement: the scaffold's `Big`, `Chunk`, `NLEN`, and native index operation already satisfy the complete need.

## Unit-test strategy

Tests are immutable under the project brief. No Java tests exist to translate, and the one-body edit rule prohibits adding target tests. The existing `big::tests::test_get_set` is the direct unit contract; `test_xor_top` is a dependent behavior check. Full-feature testing instantiates the shared module with varying ROM dimensions, while broader tests cover callers such as `DBig::split` and `FF::set`.

The acceptance oracle should be satisfied for first, middle, and last valid indices; zero, positive, negative, and architecture-limit `Chunk` values; preservation of non-target limbs; repeated replacement; and an index equal to `NLEN` panicking. These cases require no mocks: setup is an in-memory `Big`, mutation uses `set`, and observation uses `get` or the public `w` array.

Introducing a trait with real/mock implementations would be counterproductive because there is no external dependency to isolate and it would violate the permitted edit surface. The correct mockable-seam inventory is therefore empty.

## Milestone mapping

| Milestone | Source functionality and contract | Tests/validation |
| --- | --- | --- |
| 1. Immutable staging | Copy `scaffold/` to `pipeline/target`; preserve all supplied files and confirm the sole intended change site is the explicit setter placeholder. | Do not modify or run the read-only source. Do not alter any scaffold test. |
| 2. Setter translation | Replace only the placeholder body so `Big::set` performs the source's exact direct indexed limb replacement with native bounds behavior. | Existing `big::tests::test_get_set` maps directly to the behavior; `test_xor_top`, `DBig::split`, and `FF::set` remain integration-sensitive callers. |
| 3. Full validation | Preserve compilation on the configured Rust 1.77.1 toolchain and across all existing features and modules. | Run the configured Cargo build and the full immutable suite, including `cargo test --all --all-features --release`, before claiming implementation success. |
