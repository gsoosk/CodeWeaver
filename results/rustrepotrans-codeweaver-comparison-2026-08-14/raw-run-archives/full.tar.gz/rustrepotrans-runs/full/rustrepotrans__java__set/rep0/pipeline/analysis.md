# Analyzer Design: Java `big::set` to Rust

## 1. Source Project Research

### Scope, structure, and responsibilities

The supplied Java corpus is a deliberately isolated API fragment rather than a buildable Java project. No reference material was supplied.

| Path | Responsibility |
| --- | --- |
| `source/source_function.java` | Contains the complete source method `public void set(int i, long x)`. The method performs one indexed write to the receiver's `w` array and has no other statements (`source/source_function.java:1-4`). |
| `source/target_contract.md` | Defines the required Rust signature and the provided dependency context: `Big`, its fixed-size `w: [Chunk; NLEN]` storage, architecture-dependent chunk types, ROM constants, and surrounding imports (`source/target_contract.md:1-23`). |

There are no Java package declarations, enclosing class declarations, imports, build manifests, resources, command-line entry points, or test directories in `source/`. The project name and target contract identify the fragment as the setter for the Milagro multi-precision `Big` representation, but the design must not infer additional Java APIs that are not present in the supplied files.

### API, data model, and behavior

The source API is a public, mutating instance method:

- `i` is a Java `int` array index.
- `x` is a signed Java `long`.
- The return type is `void`.
- Receiver state is the array referenced by `w`.

Its complete observable behavior is a raw replacement of the element at index `i` with `x`. It does not allocate, return a value, normalize the number, propagate carries, mask `x` to a limb width, validate a cryptographic invariant, or modify any other element.

The provided Rust model is `Big { pub w: [Chunk; NLEN] }` (`scaffold/src/big.rs:38-41`). `NLEN` is derived from each feature module's `MODBYTES` and `BASEBITS` (`scaffold/src/big.rs:27-36`). Scaffold usage establishes that index zero is the least-significant limb (`Big::new_int`, `scaffold/src/big.rs:91-99`) and `NLEN - 1` is the top limb (`Big::xor_top`, `scaffold/src/big.rs:139-144`). The setter must nevertheless remain a raw limb operation; numeric interpretation is not part of its work.

There are no generated tables, files, records, logs, or standard-output messages. The sole output is the receiver's changed in-memory state. Because `w` is public in the target, the result is observable both through `Big::get` (`scaffold/src/big.rs:125-130`) and direct field inspection.

### Error handling and dependencies

The Java method declares no checked exceptions and contains no explicit validation. Java array semantics throw an unchecked `ArrayIndexOutOfBoundsException` when `i` is negative or at least the array length. A valid index always performs the assignment, including when `x` is negative or outside the normal `BASEBITS` limb mask.

The source has no third-party imports. Its only requirements are Java primitive integer and array semantics plus the receiver's existing `w` field. There are no nullable parameters, external services, filesystem operations, randomness, synchronization, threads, callbacks, or other boundaries.

The wider provided Rust `big.rs` module imports `DBig`, `RAND`, `Ordering`, and formatting support, but the setter itself needs only the already-defined `Big::w` storage and `Chunk` type. Relevant downstream consumers include:

- `DBig::split`, which writes computed upper limbs through `Big::set` (`scaffold/src/dbig.rs:59-75`).
- `FF::set`, which initializes the least-significant limb of its first `Big` (`scaffold/src/ff.rs:90-94`).

### Behavioral tests and mocking survey

The Java source ships no unit tests and no Java test dependency, so there are no source mocks or fixtures to translate. This is appropriate for a deterministic in-memory setter: it has no boundary that could usefully be mocked.

The immutable Rust scaffold already contains the directly relevant behavioral unit tests inline under `#[cfg(test)]` in `scaffold/src/big.rs:1184-1310`:

- `test_get_set` starts with a zero `Big`, visits every valid index from zero through `NLEN - 1`, writes a distinct `Chunk`, and verifies the value through `get` (`scaffold/src/big.rs:1266-1277`). This is the direct behavioral test for the source method.
- `test_xor_top` uses `set` to seed the highest limb before checking `xor_top`, providing an integration check for the top valid index (`scaffold/src/big.rs:1279-1289`).
- The surrounding `Big` tests use concrete in-memory values and `DBig`; none use mocks.

`src/big.rs` is included as the `big` module inside every enabled curve/RSA feature module. Consequently, the inline tests are instantiated with feature-specific `NLEN`, `BASEBITS`, and `MODBYTES`; an all-features test run checks the same setter contract across every scaffold configuration.

## 2. Third-Party Library Analysis

There are no third-party Java libraries to replace. The required facilities and their target mappings are:

| Source need | Source usage | Rust counterpart and scaffold status |
| --- | --- | --- |
| Java primitive `long` | Value stored without transformation | `crate::arch::Chunk`, already required by the target signature. It is `i64` on 64-bit targets and `i32` on 32-bit targets (`scaffold/src/arch/arch64.rs:20-22`, `scaffold/src/arch/arch32.rs:20-22`). The narrower 32-bit representation is authoritative scaffold behavior; no conversion library is needed. |
| Java primitive `int` index | Selects one array element | `usize`, already fixed by `source/target_contract.md:3-5`. No numeric-conversion crate is needed. |
| Java `long[]` indexing and bounds enforcement | Mutates `w[i]`; invalid indices throw at runtime | Rust fixed-array indexing on `[Chunk; NLEN]`, already supplied by `Big`. Native indexing provides the corresponding fail-fast panic for an index at least `NLEN`; no custom error crate or bounds helper is needed. |
| Milagro big-number representation | Supplies `w` and its limb count | Fully provided by `scaffold/src/big.rs`, feature-specific `rom` modules, and `crate::arch`. Do not add `num-bigint` or create a second big-number type. |

`scaffold/Cargo.toml` has no normal runtime dependencies. Its existing `hex`, `serde`, `serde_json`, `serde_derive`, `criterion`, and `rand` entries are development dependencies for unrelated tests and benchmarks (`scaffold/Cargo.toml:10-16`). The setter requires none of them. The module's `crate::rand::RAND` is also unrelated to this method. No dependency manifest changes or new libraries are justified.

All required architecture selection, fixed storage, curve/RSA feature wiring, constants, and test infrastructure are already met by the scaffold. The Translator must not reinvent or wrap them.

## 3. Target Project Design

### Overview and translation requirements

The downstream implementation phase must first copy the immutable `scaffold/` tree to `pipeline/target`, then change only the explicit placeholder body of `Big::set` in `pipeline/target/src/big.rs`. `source/`, `scaffold/`, manifests, tests, documentation, module declarations, signatures, visibility, attributes, and every other target body must remain unchanged.

Functional equivalence is exact state equivalence with the Java assignment for values representable by the prescribed target signature. The method must replace exactly one selected limb with the exact `Chunk` supplied. It must not mask, normalize, clamp, resize, convert, reject, or alter neighboring limbs. The existing public signature and unit return are authoritative.

### Source-to-target structural mapping

| Java source element | Rust target element | Required mapping |
| --- | --- | --- |
| Public instance method `set` | `Big::set` in `src/big.rs` | Preserve the identifier and public visibility. |
| Mutable Java receiver | `&mut self` | Use the scaffold's exclusive mutable receiver; no interior mutability or synchronization is needed. |
| `int i` | `i: usize` | Preserve the supplied target API. Negative indices are unrepresentable; indices at least `NLEN` retain native fail-fast behavior. |
| `long x` | `x: Chunk` | Store the value exactly as represented by the architecture-selected alias. Do not cast through another integer type. |
| Receiver field `w` | `Big::w: [Chunk; NLEN]` | Mutate the existing fixed array; do not add storage or an accessor abstraction. |
| Java `void` | Rust unit return | Do not introduce `Result`, `Option`, a returned old value, or a status flag. |
| Java array-bounds exception | Rust array-index panic | Rely on the existing language-level bounds behavior; do not clamp, wrap, silently ignore, or pre-normalize the index. |

There is no Java `null` case to map because both parameters are primitives; Rust's fixed array also cannot be absent. There are no Java exceptions beyond implicit bounds failure, no threads/tasks, and no asynchronous behavior.

### Target module structure

No new target files or modules are needed:

| Target path | Role in this translation |
| --- | --- |
| `pipeline/target/src/big.rs` | Shared `Big` implementation and inline tests. This is the only implementation file whose placeholder body may change. |
| `pipeline/target/src/lib.rs` | Existing feature-gated module wiring; must remain untouched. It includes the shared `big.rs` under each feature namespace. |
| `pipeline/target/src/arch/arch32.rs`, `arch64.rs` | Existing `Chunk`, `DChunk`, and `CHUNK` definitions; must remain untouched. |
| `pipeline/target/src/roms/*.rs` | Existing feature- and architecture-specific `BASEBITS`, `MODBYTES`, and constants; must remain untouched. |
| `pipeline/target/src/dbig.rs` | Existing `DBig::split` caller of `Big::set`; unchanged integration consumer. |
| `pipeline/target/src/ff.rs` | Existing `FF::set` caller of `Big::set`; unchanged integration consumer. |
| `pipeline/target/Cargo.toml`, `Cargo.lock`, `rust-toolchain.toml` | Existing package, dependency lock, feature matrix, and Rust 1.77.1 toolchain; all unchanged. |

The concrete public paths are feature-scoped, such as `amcl::bn254::big::Big`, rather than a root `amcl::big::Big`. The same `src/big.rs` is reused by the 29 feature modules declared in `src/lib.rs`: `bls48`, `bls461`, `bls383`, `bls381`, `fp512bn`, `fp256bn`, `bls24`, `anssi`, `brainpool`, `goldilocks`, `hifive`, `nist256`, `nist384`, `nist521`, `nums256e`, `nums256w`, `nums384e`, `nums384w`, `nums512w`, `nums512e`, `secp256k1`, `c25519`, `c41417`, `ed25519`, `bn254cx`, `bn254`, `rsa2048`, `rsa3072`, and `rsa4096` (`scaffold/src/lib.rs:24-568`). This shared-file architecture must be preserved.

### Observable contract

For a pre-state `old_w`, the oracle-facing contract is:

| Case | Required observable result |
| --- | --- |
| `0 <= i < NLEN` | The call completes with unit, limb `i` equals exactly `x`, and every limb `j != i` remains equal to `old_w[j]`. |
| Repeated write to the same valid index | The latest supplied `x` replaces the previous limb value; no accumulation occurs. |
| `x` is zero, negative, at the signed limit, or has bits above `BMASK` | The exact `Chunk` value is retained. `set` performs no normalization or masking. |
| `i == 0` or `i == NLEN - 1` | The least- and most-significant valid limbs are handled identically to interior limbs. |
| `i >= NLEN` | The call fails through Rust's normal array-index panic and must not be converted into success or a recoverable return value. |

There is no stdout/stderr protocol, serialization, file output, randomness, timing requirement, or live infrastructure. The mutation above is the complete contract. Maintaining it also preserves the behavior of `DBig::split`, `FF::set`, and any higher-level arithmetic or RSA operations that reach this shared primitive.

### Boundary and error-handling strategy

This method has no external boundary. It should use the scaffold's existing fixed-array operation directly, without a trait, adapter, allocator, unsafe block, helper function, cryptographic crate, or mock implementation. Native Rust indexing is the exact replacement for Java's indexed array write and supplies the intended bounds failure.

Do not add explicit validation that changes panic timing or type, and do not add logging, debug assertions, masking with `BMASK`, calls to `norm`, or error wrapping. The valid path is infallible and retains the existing unit-return API.

### Unit-test strategy

No Java tests translate directly because none were supplied. No mock seam is warranted: all inputs and state are local values, and introducing a trait would violate both the source architecture and the one-body-only constraint.

The immutable tests remain where they already live:

- Direct unit coverage: inline `big::tests::test_get_set` in `src/big.rs`.
- Boundary-index integration: inline `big::tests::test_xor_top` in `src/big.rs`.
- Downstream coverage: existing module tests exercising arithmetic, curves, pairings, and RSA through the unchanged scaffold.
- Withheld oracle: treated as read-only and never modified, skipped, mocked, or searched for a golden body.

No test files, mock implementations, fixtures, or dependencies should be added. The existing direct test covers every valid index; the full all-features suite exercises each feature-specific instantiation. The external oracle can additionally distinguish incorrect implementations by checking overwrite semantics, preservation of non-target limbs, raw negative/out-of-mask values, and out-of-range panic behavior.

The Validator should run from `pipeline/target` using the pinned toolchain. A focused diagnostic may run the existing `test_get_set`, but completion requires both a full all-features release build and the scaffold's configured full test command, `cargo test --all --all-features --release` (`scaffold/README.md:15-24`). No success claim is valid if any configured test is skipped or weakened.

### Milestone mapping

| Milestone | Source functionality and tests | Required result |
| --- | --- | --- |
| 1. Materialize target | No behavioral change yet | Copy `scaffold/` to `pipeline/target` without changing `source/` or `scaffold/`; preserve the complete module, feature, test, and dependency layout. |
| 2. Translate `set` | Java method in `source/source_function.java:1-4` | Replace only the explicit placeholder body in `pipeline/target/src/big.rs`; reproduce raw selected-limb replacement and native bounds failure while preserving the signature and all other code. |
| 3. Exercise direct behavior | Existing `test_get_set` and `test_xor_top` | Confirm all valid limb positions, including the top limb, accept and expose the supplied `Chunk` under every enabled feature instantiation. |
| 4. Validate integration | Existing full scaffold test suite, including callers such as `DBig::split` and `FF::set` | Run the full all-features release build and test suite with no test or feature disabled; all public APIs and unrelated behavior remain unchanged. |

**Artifact confirmation:** `/opt/codeweaver-related-papers/campaign/rustrepotrans/runs/full/rustrepotrans__java__set/rep0/pipeline/analysis.md` contains the completed analysis. Section 1 documents the source fragment, exact state contract, errors, dependencies, and tests; Section 2 establishes that the scaffold already supplies every required counterpart and that no new library is needed; Section 3 gives the authoritative structural mapping, immutable module plan, observable contract, boundary/test strategy, and milestone sequence for the Rust port.
