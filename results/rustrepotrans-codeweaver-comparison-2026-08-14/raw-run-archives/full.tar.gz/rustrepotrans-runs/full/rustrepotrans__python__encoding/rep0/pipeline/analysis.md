# Rust Port Design: `CharsetMatch::encoding`

## 1. Source Project Research

### Scope and overview

The supplied Python source is an extracted, single-method task rather than a complete Python package. `source/source_function.py:1-2` defines `encoding(self) -> str`, whose only behavior is to return `self._encoding`. It performs no detection, decoding, normalization, validation, allocation, mutation, logging, I/O, or concurrency.

No reference-material directory was supplied (`reference material: none`). `source/target_contract.md` is read-only dependency context for the Rust destination, not additional Python behavior.

### Source structure and responsibilities

| Path | Responsibility |
|---|---|
| `source/source_function.py` | Contains the complete source behavior: the `encoding` accessor returns the instance's `_encoding` string unchanged. |
| `source/target_contract.md` | Fixes the target signature and records the already-provided Rust `CharsetMatch` data model and surrounding imports. It is a contract, not an implementation source. |

There are no Python package manifests, modules, fixtures, or test files under `source/`.

### API, data model, and observable contract

The source API has one receiver and no explicit arguments. For a valid `CharsetMatch` instance:

- Input state: `self._encoding`, a Python `str`.
- Return value: that same string value, with spelling, case, punctuation, and emptiness preserved.
- Side effects: none.
- Produced tables, files, records, or serialized output: none.

The dependency context maps this state into the provided Rust model at `scaffold/src/entity.rs:88-99`: `CharsetMatch` owns `encoding: String` alongside `payload`, `mean_mess_ratio`, `coherence_matches`, `has_sig_or_bom`, `submatch`, and `decoded_payload`. `CharsetMatch::new` copies its `encoding: &str` argument into that field (`scaffold/src/entity.rs:158-178`), while `Default` stores `"utf-8"` (`scaffold/src/entity.rs:113-124`). The missing public accessor is already declared at `scaffold/src/entity.rs:198-200`.

The accessor must expose the stored value, not recompute or canonicalize it. Although normal detection paths generally store canonical IANA names, `CharsetMatch::new` accepts any valid Rust string, so values such as custom labels or the empty string remain part of the accessor's direct contract.

### Error handling

The Python method contains no explicit error handling and raises no domain error. Python attribute lookup could raise `AttributeError` only for an invalid object lacking `_encoding`; that failure mode does not need emulation because the Rust struct always contains its private `String` field after construction.

The Rust accessor therefore must be infallible and must not panic, return `Option`/`Result`, validate an IANA label, decode the payload, or consult an alias table. Rust's `String` invariant already guarantees valid UTF-8.

### Dependencies

`source/source_function.py` has no imports and no third-party Python dependencies. Its only language-level dependency is Python object attribute access and the built-in `str` type.

The broader Rust scaffold is already a complete charset-normalizer port:

- `src/lib.rs` implements byte/path detection through `from_bytes` and `from_path`.
- `src/entity.rs` owns result, settings, language, and CLI data types.
- `src/cd.rs` and `src/assets.rs` implement coherence/language analysis and static language data.
- `src/md.rs`, `src/md/plugins.rs`, and `src/md/structs.rs` implement mess detection.
- `src/consts.rs` supplies encoding names, aliases, signatures, and Unicode ranges.
- `src/utils.rs` supplies codec, IANA-label, Unicode, and test-data utilities.
- `src/normalizer.rs` and `src/performance.rs` are the CLI and optional performance binaries.

None of those broader facilities is needed to implement this accessor.

### Test survey and boundary mocking

The Python source bundle ships no behavioral unit tests, so there are no source tests to translate and no Python mocks or monkeypatches to reproduce.

The immutable Rust scaffold does contain behavioral coverage that acts as the target oracle:

- `scaffold/src/tests/entity.rs:9-64` constructs `CharsetMatch` values directly and asserts that the best match and indexed match report `"utf-8"` through `encoding()`. The same test uses the accessor to choose Unicode-range assertions at lines 125-134.
- `scaffold/src/tests/detection_base.rs` checks exact labels for empty, BOM/SIG, ASCII, UTF-8, and EUC-KR inputs.
- `scaffold/src/tests/detection_full.rs`, `detection_edge_case.rs`, and `detection_large_payload.rs` read local fixtures or use in-memory payloads and compare returned labels with expected encodings.
- Crate documentation in `scaffold/src/lib.rs:27-56` exercises `"gb18030"` and `"big5"` through the accessor as doctest examples.
- `scaffold/src/normalizer.rs:51-103` uses the accessor for JSON/minimal output, alternative filtering, UTF checks, and normalized filename suffixes. `scaffold/tests/normalizer.rs` invokes that binary with `assert_cmd`.

These tests do not mock the accessor or any live service. Unit tests use direct constructors and byte vectors; detection tests use repository fixtures; CLI tests spawn the local binary and use local files. There is no network, database, clock, or process boundary inside `encoding()` and therefore no mockable boundary to introduce.

## 2. Third-Party Library Analysis

### Source dependency mapping

There are no significant third-party Python dependencies to replace.

| Source need | Idiomatic Rust counterpart | Scaffold status |
|---|---|---|
| Python `str` stored on an object | Own the value as `String`; expose a lifetime-bound borrowed `&str` for a read-only accessor | Already provided by `CharsetMatch.encoding: String` and the fixed `pub fn encoding(&self) -> &str` signature |
| Python instance attribute access | An inherent method borrowing the struct's private field | Already provided by `impl CharsetMatch`; only the sentinel body is missing |
| Python garbage-collected reference lifetime | Rust lifetime elision ties the returned string slice to `&self`, preventing it from outliving the match | Already expressed by the fixed signature |

No crate should be added for this translation.

### Provided dependency context that must not be reinvented

`source/target_contract.md:24-37` lists surrounding imports already implemented by the scaffold. They are not dependencies of the accessor body:

- `crate::cd::{encoding_languages, mb_encoding_languages}`, `crate::consts::{IANA_SUPPORTED_ALIASES, TOO_BIG_SEQUENCE}`, and `crate::utils::{decode, iana_name, is_multi_byte_encoding, range_scan}` already provide internal detection and metadata facilities.
- The `encoding` crate and `DecoderTrap` already handle codec operations used by construction and detection.
- `clap`, `serde`, and `ordered-float` already support CLI parsing, output serialization, and ordered numeric settings.
- Standard-library formatting, ordering, hashing, indexing, paths, and durations are already imported for other `entity.rs` types.

Calling any decoder, alias map, IANA normalizer, or language detector from `encoding()` would add behavior absent from Python and would be incorrect. The existing `Cargo.toml` and `Cargo.lock` must remain unchanged.

## 3. Target Project Design

### Overview and translation requirements

The Translator must first copy `scaffold/` to `pipeline/target` without changing `source/` or `scaffold/`. In the copied project, the only source edit permitted is replacement of the explicit `panic!("RustRepoTrans translation required")` body in `pipeline/target/src/entity.rs`. All signatures, visibility, fields, modules, manifests, tests, fixtures, and other method bodies must remain byte-for-byte equivalent to the scaffold.

Functional equivalence is exact:

- `encoding()` returns a shared string slice borrowing the existing `encoding: String`.
- The bytes of the returned UTF-8 string are exactly those stored by `CharsetMatch::new` or `Default`.
- The call performs no allocation, clone, mutation, normalization, lookup, decoding, logging, or panic.
- Repeated calls on an unchanged `CharsetMatch` report the same stored value.
- The returned borrow is valid only as allowed by the borrow of `self`; no leaked or independently owned value is required.

### Source-to-target structural mapping

| Python source | Rust target | Required semantic mapping |
|---|---|---|
| Conceptual `CharsetMatch` instance | `crate::entity::CharsetMatch` | Reuse the provided struct; do not introduce a wrapper or parallel model. |
| Private `self._encoding` | Private `CharsetMatch.encoding: String` | Preserve private storage and its exact contents. |
| `def encoding(self) -> str` | Existing `pub fn encoding(&self) -> &str` | Preserve the public name and signature; borrow rather than clone the owned string. |
| Direct attribute return | Direct read-only borrow of the field | Do not call codec, alias, or canonicalization helpers. |
| Python implicit reference management | Rust shared borrow with an elided output lifetime tied to `&self` | No `unsafe`, global storage, or lifetime workaround. |

There are no source exceptions to map to a Rust error type, no source `None` to map to `Option`, and no threads/tasks to map to Rust concurrency.

### Target module structure

`pipeline/target` must mirror `scaffold`:

| Target path | Role in this task |
|---|---|
| `src/entity.rs` | Contains `CharsetMatch`; this is the sole editable implementation file and only the `encoding()` body may differ. |
| `src/lib.rs` | Constructs and exposes matches through `from_bytes`/`from_path`; unchanged downstream consumer. |
| `src/assets.rs`, `src/cd.rs`, `src/consts.rs`, `src/md.rs`, `src/md/**`, `src/utils.rs` | Existing detection support; unchanged and not called by the accessor. |
| `src/normalizer.rs`, `src/performance.rs` | Existing binaries that consume `encoding()`; unchanged. |
| `src/tests/**`, `tests/normalizer.rs`, `benches/**` | Read-only oracle and performance coverage; never weaken, skip, rewrite, or delete. |
| `Cargo.toml`, `Cargo.lock`, `rust-toolchain.toml` | Existing dependency graph and Rust 1.77.1 toolchain; unchanged. |

No new module, trait, helper, dependency, test fixture, or generated source is warranted.

### Observable output and contract mapping

The single implementation milestone must preserve both the direct API and every existing downstream observation:

| Observation | Required result |
|---|---|
| `CharsetMatch::new(..., "utf-8", ...).encoding()` | `"utf-8"` |
| `CharsetMatch::default().encoding()` | `"utf-8"` |
| A constructor supplied any other string | That exact string, without case folding, alias replacement, trimming, or validation |
| Detection result access in `src/tests/detection_*.rs` | The exact canonical label already selected and stored by detection |
| `normalizer` JSON/minimal output | The same stored label copied by the existing caller |
| Normalized filename and UTF-prefix decisions | Continue to use the exact accessor value |

The accessor itself creates no file, table, JSON object, or record. CLI serialization and filename changes are downstream behavior already implemented in the scaffold; returning the exact stored label is sufficient to preserve them.

### Boundary and error-handling strategy

There is no external boundary to abstract. The source attribute read maps directly to borrowing the provided field:

- Do not invoke `decode`, `iana_name`, `encoding_aliases`, `encoding_languages`, `mb_encoding_languages`, or any third-party crate.
- Do not add `Result`, `Option`, fallback values, assertions, or panic paths.
- Do not catch or suppress errors from unrelated code.
- Do not clone or allocate a new `String`; the fixed `&str` return type is intentionally a view into `self`.
- Do not expose the field publicly or add a setter.

The struct constructor and default implementation already establish the field invariant, so the accessor has no recoverable failure state.

### Unit-test strategy

No mock trait is appropriate: the method is a deterministic field accessor with no collaborators. Introducing a trait, fake decoder, or test-only seam would violate the one-body edit constraint and reduce traceability.

No test files may be added or edited. Existing coverage is sufficient to exercise the translated behavior:

1. `src/tests/entity.rs` is the direct unit-level check for a constructed match and a match retrieved from `CharsetMatches`.
2. `src/tests/detection_base.rs`, `detection_full.rs`, `detection_edge_case.rs`, and `detection_large_payload.rs` are integration-level checks across constructors and detection paths.
3. `tests/normalizer.rs` and crate doctests cover binary/public-API consumers.
4. Withheld tests may construct a match with an arbitrary label; exact passthrough and absence of panic must hold independently of whether that label is recognized by IANA helpers.

The later Validator must run the copied project's configured full build and test suite from `pipeline/target`, including all targets and doctests, without modifying or filtering tests. A final source diff must show that only the sentinel method body differs from `scaffold/src/entity.rs`.

### Milestone mapping

| Milestone | Source functionality delivered | Oracle/acceptance mapping |
|---|---|---|
| 1. Immutable staging | Copy the complete scaffold to `pipeline/target`; make no behavioral claim yet and preserve all files. | File comparison confirms no source/scaffold mutation and no target drift before translation. |
| 2. Accessor translation | Map Python's direct `_encoding` return to an infallible borrowed view of the existing Rust field by replacing only the sentinel body. | Direct `src/tests/entity.rs` assertions and arbitrary-label withheld tests return exact stored strings without panic or allocation-dependent behavior. |
| 3. Full validation | Preserve all existing detection, library, CLI, and documentation behavior. | Full-project build, all unit/integration tests, and doctests pass unmodified; final diff remains restricted to the one body. |

**Artifact status:** `/opt/codeweaver-related-papers/campaign/rustrepotrans/runs/full/rustrepotrans__python__encoding/rep0/pipeline/analysis.md` is this authoritative design. Section 1 records the exact source behavior and test context, Section 2 establishes that no new dependency is needed, and Section 3 fixes the one-body Rust mapping, boundaries, tests, and milestones.
