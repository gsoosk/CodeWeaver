# 1. Source Project Research

## Scope and behavior

The supplied Python source is an extracted, single-method slice rather than a complete Python package. `source/source_function.py:1-2` defines `encoding(self) -> str` and returns `self._encoding` directly. There is no computation, normalization, decoding, alias lookup, allocation requested by the source, I/O, or mutation. Its complete observable contract is therefore:

- return the exact string currently stored in the instance's `_encoding` attribute;
- accept no argument other than the instance;
- leave the instance unchanged;
- introduce no method-specific failure path.

The provided dependency context in `source/target_contract.md:3-21` fixes the Rust API and storage model: `CharsetMatch` owns an `encoding: String`, while the public method returns `&str`. The return value is the only direct output. The source method creates no table, file, serialized record, log message, or side effect.

## Supplied structure and responsibilities

| Path | Responsibility |
|---|---|
| `source/source_function.py` | Authoritative source behavior for the one translated method. |
| `source/target_contract.md` | Authoritative Rust signature, complete `CharsetMatch` field context, and already-selected Rust imports/dependencies. |

There are no Python package metadata files, supporting Python modules, fixtures, or test directories under `source/`.

The relevant contextual data model is `CharsetMatch`: original `payload` bytes, owned `encoding`, `mean_mess_ratio`, language `coherence_matches`, `has_sig_or_bom`, equivalent-encoding `submatch` entries, and optional `decoded_payload`. In the scaffold, `CharsetMatch::new` stores its `encoding` argument as an owned `String` (`scaffold/src/entity.rs:158-178`), and `Default` stores `"utf-8"` (`scaffold/src/entity.rs:113-124`). The field is private, so construction establishes the getter's invariant. The getter must expose that field's content, not derive an encoding from any other field.

`CharsetMatches` is the surrounding result container (`scaffold/src/entity.rs:296-394`). Detection in `from_bytes` constructs matches with the selected IANA label (`scaffold/src/lib.rs:473-529`), and `from_path` only adds file reading before delegating to `from_bytes` (`scaffold/src/lib.rs:580-597`). The getter is consequently the public path by which callers observe the detector's stored label.

## Error handling

The Python getter has no explicit exception handling and performs no operation that can independently fail once a valid `CharsetMatch` exists. The Rust counterpart must likewise remain infallible: it must not return `Result` or `Option`, panic, validate the label, or silently substitute a default. Decode failures handled by `CharsetMatch::new`, alias-map assumptions in `encoding_aliases`, and file errors returned by `from_path` are separate scaffold behavior and must remain unchanged.

## Dependencies

`source_function.py` has no imports and no third-party dependency. It relies only on ordinary Python instance attribute access and Python's built-in `str` type. The source method does not call the Python `charset-normalizer` package's detector, codecs, logging, filesystem, or concurrency facilities.

## Behavioral tests and boundary mocking

The supplied Python source ships no unit or behavioral tests, so there are no Python tests to translate and no Python mocks, monkeypatches, fixtures, or external-boundary substitutions to preserve.

The immutable Rust scaffold does ship behavioral coverage that acts as the local oracle:

- `scaffold/src/tests/entity.rs:3-138` constructs `CharsetMatch` values entirely in memory and directly expects `"utf-8"` through both `get_best().encoding()` and indexed access.
- `scaffold/src/tests/detection_base.rs` checks labels for empty input, BOM/SIG inputs, ASCII, UTF-8, and an isolated EUC-KR case.
- `scaffold/src/tests/detection_edge_case.rs`, `detection_full.rs`, and `detection_large_payload.rs` observe the getter for edge, fixture-corpus, and large-payload detections.
- `scaffold/tests/normalizer.rs` exercises the CLI as a subprocess with `assert_cmd`; normalization indirectly depends on the label because `src/normalizer.rs:51-103` places it in result records and generated filenames.
- The crate-level examples in `scaffold/src/lib.rs:27-56` call `encoding()` and therefore provide doctest coverage.

These tests do not mock the getter. Entity tests use direct construction, detector tests use in-memory bytes or repository fixtures, and CLI integration tests use real fixture files and a local subprocess. No live service or network infrastructure is involved.

# 2. Third-Party Library Analysis

There are no significant Python dependencies to map: the extracted source uses only `str` and attribute access. The idiomatic Rust counterpart for owned Python string state is the scaffold's existing `String`; the public read-only view is the already-fixed `&str` return type. Both are in Rust's standard library, so no crate is needed.

The imports listed in `source/target_contract.md:24-37` are paper-provided context already implemented by the scaffold, not missing dependencies for this translation:

| Existing dependency/context | Existing role | Design decision |
|---|---|---|
| `crate::cd` | Encoding-to-language inference for other `CharsetMatch` methods. | Already scaffolded; do not call or change it for the getter. |
| `crate::consts` | Static encoding aliases and size thresholds. | Already scaffolded; the getter must not perform alias lookup. |
| `crate::utils` | Decoding, IANA canonicalization, encoding classification, and Unicode range scans. | Already scaffolded; the source getter does none of these operations. |
| `encoding::DecoderTrap` | Decode policy used during `CharsetMatch::new`. | Already declared in `Cargo.toml`; irrelevant to reading the stored label. |
| `clap` | Derives CLI argument parsers elsewhere in `entity.rs`. | Already declared and unrelated. |
| `ordered-float` | Orderable thresholds in `NormalizerSettings`. | Already declared and unrelated. |
| `serde` / `serde_json` | Serializes CLI result records. | Already declared; consumers convert the borrowed label to owned output as needed. |
| `assert_cmd` / `predicates` | Existing CLI integration-test support. | Already present as dev-dependencies; no new test library is needed. |
| Rust `std` traits and types | Formatting, comparison, borrowing, collections, paths, and durations. | Already available; ordinary borrowing fully satisfies this method. |

No dependency manifest change is permitted or necessary. In particular, adding a codec, canonicalization, getter-generation, synchronization, or cloning utility would both duplicate the scaffold and change the source semantics.

# 3. Target Project Design

## Translation requirements

The later Translator must first copy `scaffold/` verbatim to `pipeline/target`, then change only the explicit `panic!("RustRepoTrans translation required")` body of `CharsetMatch::encoding` in `pipeline/target/src/entity.rs`. No source, scaffold, interface, test, manifest, formatting outside that body, or withheld implementation may be changed or consulted.

Functional equivalence is exact field access. The method must return a read-only borrowed view of the `CharsetMatch.encoding` field:

- content must be byte-for-byte the stored UTF-8 string, including case, punctuation, an empty value, or a noncanonical value accepted by `CharsetMatch::new`;
- it must not canonicalize through `iana_name`, inspect aliases, decode `payload`, select a submatch, or substitute `"utf-8"`;
- it must not clone or transfer ownership of the `String`;
- the returned reference must be tied to the immutable borrow of `self`, as required by the fixed signature;
- repeated calls on an unchanged value must observe the same field content and have no side effects;
- the placeholder panic must be eliminated without introducing another failure path.

## Source-to-target structural mapping

| Python source | Rust target | Required semantic mapping |
|---|---|---|
| Enclosing match object | `entity::CharsetMatch` | Preserve the existing scaffold type and visibility. |
| `_encoding: str` | private `encoding: String` | Preserve owned per-instance storage established by `new` or `default`. |
| `encoding(self) -> str` | `pub fn encoding(&self) -> &str` | Expose the stored content through an immutable borrow without allocation. |
| direct `self._encoding` access | direct view of `self.encoding` | No intermediary detector, normalization, alias lookup, or fallback. |
| Python exceptions | no getter error type | The getter is total for every valid `CharsetMatch`; do not add `Result`, `Option`, or panic. |
| Python `None` | not applicable | The encoding field is nonoptional in both the contract and scaffold. |
| Python tasks/threads | not applicable | The operation is synchronous, local, and read-only; no concurrency primitive is needed. |

## Target module structure

The copied scaffold layout is authoritative and must remain intact:

- `src/entity.rs`: owns `CharsetMatch`, `CharsetMatches`, settings, and CLI result/argument types. This is the only implementation file and the single function body that may change.
- `src/lib.rs`: public `from_bytes`/`from_path` detection flow; constructs `CharsetMatch` and consumes `encoding()` in fallback/reporting paths.
- `src/assets.rs`, `src/cd.rs`, and `src/consts.rs`: language assets, coherence detection, and static encoding metadata.
- `src/md.rs`, `src/md/plugins.rs`, and `src/md/structs.rs`: mess/chaos detection.
- `src/utils.rs`: codec, IANA-name, BOM/SIG, Unicode-range, and fixture helpers.
- `src/normalizer.rs` and `src/performance.rs`: CLI and optional performance binaries.
- `src/tests/*.rs`: in-crate unit and behavioral tests, including the direct entity and detector expectations.
- `tests/normalizer.rs`: black-box CLI integration tests.
- `benches/*.rs`, `Cargo.toml`, `Cargo.lock`, and `rust-toolchain.toml`: existing benchmarks, dependency/build configuration, lockfile, and pinned Rust 1.77.1 toolchain; all remain unchanged.

## Observable contract mapping

The method itself returns one string view and writes nothing. That value propagates unchanged to these existing public observations:

| Surface | Contract dependent on `encoding()` |
|---|---|
| Library callers | `CharsetMatches::get_best`, indexing, and iteration expose a match whose getter reports its stored detector label, such as `"utf-8"`, `"ascii"`, `"utf-16le"`, `"gb18030"`, `"euc-kr"`, or fixture-specific labels. |
| CLI JSON record | `CLINormalizerResult.encoding` receives an owned copy of the exact label. The surrounding unchanged record fields are `path`, `encoding_aliases`, `alternative_encodings`, `language`, `alphabets`, `has_sig_or_bom`, `chaos`, `coherence`, `unicode_path`, and `is_preferred` (`src/entity.rs:495-518`). |
| CLI minimal output | The same label is printed for each input path (`src/normalizer.rs:131-143`). |
| Normalized file output | For non-UTF encodings, the exact label becomes the inserted filename suffix; UTF-prefixed labels suppress unnecessary normalization (`src/normalizer.rs:85-104`). File contents still come from `decoded_payload`, not this getter. |
| Logs and performance output | Existing callers format or own the same stored label; the getter must not alter it. |

There are no new records, tables, or files to introduce.

## Boundary and error-handling strategy

This method has no external boundary. It must use only the state already owned by `CharsetMatch`; no trait, adapter, codec call, filesystem call, logger, cache, or allocation belongs in the path. Existing high-level scaffold calls remain mapped as follows: `from_bytes` selects and stores the encoding, `CharsetMatch::new` owns it, and `encoding()` only exposes it. `from_path` continues to own I/O errors, while decoding and IANA validation remain in their current constructor/detection utilities. The getter must neither catch nor manufacture errors.

## Unit-test strategy

No new mockable seam is warranted for a pure field accessor, and the hard constraint allowing only the placeholder body to change forbids adding mock types or test code. The real implementation is inherently standalone because its only boundary is private in-memory state.

There are no source tests to translate. Existing `src/tests/entity.rs::test_charset_matches` is the primary direct unit test and already checks values constructed with explicit encodings. Existing detection tests cover default construction, multiple concrete encodings, result selection, and large/edge inputs. Existing CLI tests cover downstream serialization/process behavior and the encoding-derived normalized filename. These tests must remain byte-for-byte unchanged, unfiltered, and unskipped.

Validation must run from `pipeline/target` after the one-body translation. The repository has no custom CI workflow, Makefile, or Justfile; use the pinned toolchain and locked dependency graph for a full all-target build followed by the full all-target test suite, without test selectors, ignored-test overrides, weakened assertions, or feature/test rewrites. A successful direct entity test alone is insufficient because the getter is used across library, doctest, binary, fixture, and integration-test surfaces.

## Milestone mapping

| Milestone | Source functionality and permitted change | Contract/tests |
|---|---|---|
| 1. Materialize immutable target | Copy `scaffold/` to `pipeline/target` exactly; make no source or scaffold edits. | Confirm the copied tree retains the sole explicit translation placeholder and all original tests/configuration. Do not claim functional completion at this baseline. |
| 2. Translate the getter | Replace only the placeholder body in `pipeline/target/src/entity.rs`; map Python's direct `_encoding` return to a nonallocating borrow of the existing Rust field. | The direct entity expectations must report their constructor/default labels exactly; no panic, normalization, clone, side effect, or error channel is allowed. |
| 3. Validate all downstream contracts | Make no additional implementation or test changes. | Run the configured full-project build and complete test suite. Detection labels, doctests, CLI JSON/minimal output, normalized filename behavior, and all unrelated scaffold behavior must remain passing. |

**Artifact confirmation:** `/opt/codeweaver-related-papers/campaign/rustrepotrans/runs/full/rustrepotrans__python__encoding/rep1/pipeline/analysis.md` is this authoritative design document. Section 1 records the exact source getter, model, errors, dependencies, and shipped-test situation; Section 2 establishes that all relevant Rust facilities are already scaffolded and no new library is needed; Section 3 fixes the one-body structural mapping, borrow/output contract, unchanged boundaries and modules, standalone test strategy, and milestone sequence.
