# Rust port analysis: `CharsetMatch::encoding`

## 1. Source Project Research

### Scope and behavior

The supplied source is a deliberately reduced extraction, not the full Python
`charset-normalizer` repository. There is no reference-material directory. The
complete source inventory is:

| Path | Responsibility |
| --- | --- |
| `source/source_function.py` | Defines `encoding(self) -> str`; its only operation is to return `self._encoding`. |
| `source/target_contract.md` | Read-only port context: the required Rust signature, the scaffold's `CharsetMatch` fields, and surrounding Rust imports. |

In the provided project context, this method belongs to a charset detector that
accepts unknown bytes or a file path, probes supported IANA encodings, and
returns ranked `CharsetMatch` candidates. The library API exposes detection
through `from_bytes` and `from_path`; the companion CLI reports a preferred
match and can write decoded Unicode content. The incremental task does not
translate those components: they are complete, immutable consumers of this one
accessor.

The source method is a pure accessor. Its observable result is exactly the
string already stored in `_encoding`. It performs no alias resolution,
canonicalization, case conversion, validation, decoding, allocation, mutation,
logging, or I/O. On a valid `CharsetMatch`, it has no failure path. Python could
raise `AttributeError` for an arbitrarily malformed object without `_encoding`,
but that dynamic-language state has no counterpart in the statically defined
Rust structure and is not part of the valid-object contract.

There are no tables, files, or records produced by this source method. Its sole
output is one encoding-name string, preserving the stored spelling exactly.
Repeated calls observe the same backing value.

### Relevant data model and API

`source/target_contract.md` establishes that the target object already exists
with these private fields:

| Field | Role |
| --- | --- |
| `payload: Vec<u8>` | Original input bytes. |
| `encoding: String` | Owned encoding name corresponding to Python `_encoding`; this is the only field read by the missing accessor. |
| `mean_mess_ratio: f32` | Chaos score used to rank matches. |
| `coherence_matches: CoherenceMatches` | Candidate languages and coherence scores. |
| `has_sig_or_bom: bool` | Whether a signature or byte-order mark was detected. |
| `submatch: Vec<CharsetMatch>` | Encodings that decode to the same text. |
| `decoded_payload: Option<String>` | Decoded text when available. |

The source API surface under translation is only
`CharsetMatch.encoding(self) -> str`. The supplied target context fixes its Rust
surface as `CharsetMatch::encoding(&self) -> &str`. The Rust scaffold confirms
that:

- `scaffold/src/entity.rs` defines `CharsetMatch`, `CharsetMatch::new`,
  `Default`, match ranking, metadata accessors, and `CharsetMatches`.
- `CharsetMatch::new` copies its `encoding: &str` argument into the private
  `String` field; `Default` stores `"utf-8"`.
- `CharsetMatches::get_best` and `get_by_encoding` expose matches while keeping
  the backing field private.
- `scaffold/src/lib.rs` exposes `from_bytes` and `from_path`; detection creates
  `CharsetMatch` values using canonical names from the scaffold's existing IANA
  tables.

The type annotation `str` in Python is advisory. In Rust, the existing
`String` field enforces valid owned UTF-8, while the required `&str` return type
represents a read-only view tied to the borrow of `self`.

### Error handling and dependencies

The Python function contains no imports, exception handling, external calls, or
third-party dependencies. Its only implicit dependencies are Python object
attribute lookup and the built-in immutable `str` type. No source-side file,
network, process, clock, randomness, or concurrency boundary exists.

The broader scaffold has error-bearing operations, but they are outside this
translation: decoding can fail, `from_path` returns `Result<CharsetMatches,
String>`, and the CLI reports file and argument errors. The accessor must not
inherit or introduce any of those failure modes.

### Test survey

The supplied `source/` tree ships no Python unit tests, test configuration,
fixtures, mocks, monkeypatches, or fake infrastructure. Consequently there are
no source tests to translate and no source mock boundaries to preserve.

The immutable Rust scaffold does provide the behavioral oracle:

- `scaffold/src/tests/entity.rs::test_charset_matches` directly constructs
  matches and asserts that `get_best().encoding()` and indexed
  `CharsetMatch::encoding()` return `"utf-8"`; it uses no mocks.
- `scaffold/src/tests/detection_base.rs` checks exact names for default,
  BOM/SIG, ASCII, UTF-8, and EUC-KR cases.
- `scaffold/src/tests/detection_edge_case.rs`,
  `detection_full.rs`, and `detection_large_payload.rs` exercise the accessor
  through edge cases, 19 local sample fixtures, 409 local large-set fixtures,
  and large payloads.
- The doctests in `scaffold/src/lib.rs` assert `"gb18030"` and `"big5"`.
- `scaffold/tests/normalizer.rs` launches the local `normalizer` binary with
  `assert_cmd` and local fixture files. It has no live service dependency.

Tests use direct constructors, in-process detector calls, local fixture files,
and a local child process. There is no network, database, or other infrastructure
to mock.

## 2. Third-Party Library Analysis

### Source dependency mapping

There are no significant Python packages to map: `source_function.py` has no
imports at all. The complete semantic dependency mapping is therefore:

| Source need | Python mechanism | Idiomatic Rust counterpart | Scaffold status |
| --- | --- | --- | --- |
| Store an encoding name | Built-in immutable `str` referenced by `_encoding` | Owned `String` in the entity | Already provided by the `CharsetMatch` field `encoding` in `scaffold/src/entity.rs`. |
| Return it without changing it | Direct attribute return | Borrowed `&str` tied to `&self` | Required by the existing public signature; the standard library is sufficient. |
| Guarantee the attribute exists | Python valid-object convention | Statically typed private field | Already enforced by the scaffold and its constructors. |

No new crate is justified. In particular, this accessor needs no codec,
normalization, alias, serialization, caching, or error-handling library.

### Existing Rust facilities that must not be reinvented

The full target is already implemented around the missing body. Its significant
facilities are supplied and must remain unchanged:

| Existing facility | Current scaffold use | Relevance to this task |
| --- | --- | --- |
| Rust standard library `String` / `str` | Owns the encoding name and permits a borrowed string view | Completely satisfies the missing accessor. |
| `encoding` | WhatWG label lookup plus strict encode/decode operations in `lib.rs`, `cd.rs`, and `utils.rs` | Must not be called by the accessor; the stored name is already authoritative. |
| `ahash`, `once_cell`, `regex` | Static IANA, Unicode, and language lookup data | Already scaffolded; no lookup belongs in the accessor. |
| `cached`, `counter`, `strsim`, `icu_normalizer`, `icu_properties`, `unicode_names2`, `bitflags` | Coherence and mess-detection utilities | Unrelated to returning the stored field. |
| `ordered-float` | Match/settings score ordering | Unrelated to the encoding-name accessor. |
| `clap`, `serde`, `serde_json`, `dialoguer`, `env_logger`, `log` | CLI parsing, result serialization, prompts, and diagnostics | Downstream consumers only; no accessor dependency. |
| `assert_cmd`, `predicates`, `criterion` | Existing integration tests and benchmarks | Already present as dev dependencies; no test tooling changes are allowed. |
| Optional `chardet` and `chardetng` | Performance comparison binary | Not part of the accessor implementation. |

`Cargo.toml` and `Cargo.lock` therefore require no changes. Adding a dependency,
codec lookup, alias table, `Cow`, cache, or helper abstraction would duplicate
scaffolding and violate the one-body scope.

## 3. Target Project Design

### Translation requirements and immutable workflow

Functional equivalence is exact: for every valid `CharsetMatch`, `encoding()`
must expose the contents of its private `encoding: String` as a borrowed string
slice, unchanged and without transferring ownership. The call must be
infallible, side-effect free, and allocation free.

The Translator must first copy `scaffold/` to `pipeline/target` as required by
the brief. It may then replace only the explicit
`panic!("RustRepoTrans translation required")` body in
`pipeline/target/src/entity.rs`. It must preserve the function signature,
visibility, struct layout, imports, all other bodies, manifests, lockfile,
fixtures, tests, binaries, and documentation. `source/` and `scaffold/` remain
immutable. No golden implementation may be sought.

### Source-to-target structural mapping

| Python source | Rust target | Required semantic mapping |
| --- | --- | --- |
| `CharsetMatch` instance | `entity::CharsetMatch` | Use the already provided target entity; create no parallel type. |
| Private `_encoding` attribute | Private `encoding: String` field | Preserve the exact stored value. The missing underscore follows Rust's private-field convention and is already fixed by the scaffold. |
| `self` | `&self` | Shared borrow only; the accessor cannot mutate or consume the match. |
| Python `str` result | Rust `&str` result | Return a view into the owned field, with lifetime elision tying the result to `self`; do not clone into a new `String`. |
| Valid Python call has no exception | Infallible Rust return | Do not add `Result`, `Option`, panic, fallback, or validation. |

No null mapping, exception conversion, asynchronous task, thread, lock, or trait
object is needed. `decoded_payload: Option<String>` and all detection error paths
are unrelated and remain unchanged.

### Target module structure

The existing package layout is authoritative and must be mirrored unchanged in
`pipeline/target`:

| Path | Responsibility |
| --- | --- |
| `Cargo.toml`, `Cargo.lock`, `rust-toolchain.toml` | Package/dependency graph and Rust 1.77.1 toolchain. |
| `src/lib.rs` | Public `from_bytes`/`from_path` detection workflow and module declarations. |
| `src/entity.rs` | `Language`, coherence models, `CharsetMatch`, `CharsetMatches`, settings, and CLI/performance data models; contains the sole missing body. |
| `src/assets.rs` | Static language and encoding-language data. |
| `src/consts.rs` | IANA aliases, supported encodings, BOM/SIG data, Unicode ranges, and detector constants. |
| `src/cd.rs` | Coherence/language detection and result merging. |
| `src/md.rs`, `src/md/plugins.rs`, `src/md/structs.rs` | Mess-ratio orchestration, detector plugins, and per-character classification. |
| `src/utils.rs` | Encoding, decoding, IANA normalization, BOM detection, Unicode scanning, and fixture discovery. |
| `src/normalizer.rs` | CLI detection, JSON/minimal output, and optional normalized-file writing. |
| `src/performance.rs` | Optional comparison binary against `chardet` and `chardetng`. |
| `src/tests/*.rs`, `tests/normalizer.rs` | Immutable unit, fixture-driven detection, doctest-adjacent, and CLI integration coverage. |
| `benches/*.rs` | Criterion benchmarks for large payloads and data sets. |

The one extracted Python method maps directly into the existing
`entity::CharsetMatch` implementation. No new module is appropriate.

### Observable contract and downstream mapping

The primary contract is:

1. A match created with an encoding name reports that exact name, including its
   spelling and case.
2. `CharsetMatch::default().encoding()` reports the scaffold's stored
   `"utf-8"` default.
3. The result borrows from the match and does not allocate, decode, normalize,
   resolve aliases, or mutate state.
4. Calling the method on any valid match does not panic or return a sentinel.

This accessor feeds several existing observable surfaces:

| Surface | Required preserved behavior |
| --- | --- |
| Library API | Callers of `get_best()`, indexing, and iteration receive the exact stored encoding via `&str`. |
| Detector results | Existing tests continue to observe exact names such as `ascii`, `utf-8`, `utf-16le`, `utf-16be`, `gb18030`, `euc-kr`, `big5`, and the fixture-accepted alternatives. |
| CLI JSON | `CLINormalizerResult.encoding: Option<String>` is populated from the accessor. The complete serialized record remains `path`, `encoding`, `encoding_aliases`, `alternative_encodings`, `language`, `alphabets`, `has_sig_or_bom`, `chaos`, `coherence`, `unicode_path`, and `is_preferred`; only the existing `encoding` value is sourced directly from this method. |
| CLI minimal output | Each input path prints its detected encoding (or the pre-existing `undefined` fallback), with alternatives joined by comma and space. |
| Normalized file naming | Non-Unicode output filenames continue to include the exact detected encoding between the base name and extension. |
| Performance binary | The charset-normalizer result continues to be converted to an owned string for comparison and reporting. |

The method itself creates no file or record. File creation, JSON shape,
alternative filtering, and fallback behavior are existing downstream contracts
and must not be changed.

### Boundary and error-handling strategy

There is no external boundary to abstract. The correct boundary is the private
field already owned by `CharsetMatch`. The accessor must not call
`utils::iana_name`, `utils::decode`, the `encoding` crate, alias maps, filesystem
APIs, logging, or serialization. Those would change exact-value semantics and
introduce unnecessary work or failure paths.

No trait, mock implementation, cache, unsafe code, synchronization, or broad
error catch is appropriate. The existing panic placeholder is the only failure
to remove. Existing errors from `from_path`, decoding, CLI argument validation,
and file writing remain at their current higher-level boundaries.

### Unit-test strategy

Tests are immutable under the project brief, so no test or mock file is to be
added or edited. No mockable seam is needed for a direct field accessor:

- The direct standalone seam is construction through `CharsetMatch::new` or
  `Default`, followed by `encoding()`. This is already covered in
  `src/tests/entity.rs`.
- `src/tests/detection_base.rs`, `detection_edge_case.rs`,
  `detection_full.rs`, and `detection_large_payload.rs` provide transitive
  coverage across default, signature, canonical-name, fixture, and payload-size
  paths.
- Library doctests cover public consumer usage.
- `tests/normalizer.rs` covers the local CLI boundary with `assert_cmd`,
  predicates, and repository fixtures. It uses no live infrastructure and
  performs its own normalized-file cleanup.

Because the Python extraction has no tests, none require translation. Because
the function has no external boundary, introducing a trait solely for mocking
would weaken the existing design and violate the allowed edit scope. Hidden
tests should be expected to construct a match with an arbitrary valid encoding
string and verify exact, non-panicking retrieval through the fixed signature.

### Milestone mapping

| Milestone | Functionality | Test/acceptance mapping |
| --- | --- | --- |
| 1. Prepare working copy | Copy the complete immutable `scaffold/` tree to `pipeline/target`; do not alter `source/`, `scaffold/`, or tests. | Confirm the working tree has the same package layout and only the known placeholder remains to translate. |
| 2. Translate accessor | Replace only the placeholder body so the existing method borrows and exposes the stored encoding unchanged. Add no dependencies, helpers, tests, or interface changes. | Direct contract: `src/tests/entity.rs`; transitive contract: detection tests, doctests, CLI, and performance call sites. |
| 3. Full configured validation | From the repository root run the configured `cd pipeline/target && cargo check`, then `cd pipeline/target && cargo test`. The configured validation command is also `cargo test`. | All unit, fixture-driven, doctest, and CLI integration tests must pass without skips, rewrites, mocks, or weakened assertions. Review the final diff to ensure only the allowed method body changed under `pipeline/target`. |

The Analyzer must not run the end-to-end harness or create Rust code; execution
of these milestones belongs to the later Translator and Validator.
