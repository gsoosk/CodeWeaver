# Rustine same-subject comparison: qsort

Translate the disclosed pre-refactoring C under `source/` into Rust using the
immutable generated package topology under `scaffold/`. This is subject
1 of 23 from Rustine, *Translating Large-Scale C Repositories to
Idiomatic Rust* (arXiv:2511.20617v1).

## Scientific integrity constraints

- Never edit or weaken `oracle/`, `scaffold/`, `immutable_evaluator.py`, Cargo
  targets, test drivers, or module wiring to gain credit.
- Implement production behavior in `pipeline/target`; do not replace fixed
  tests with generated success output or bypass assertions.
- The Rustine production translation is intentionally unavailable. Only the
  disclosed C preprocessing output, generated skeleton, and fixed test
  contract are present.
- Compilation is independently checked with `cargo build --all-targets`.
- Validation uses a temporary copy with pristine contract files and Cargo
  wiring restored before execution.
- Paper-comparable coverage includes only the production module graph and
  immutable Rust contract files; production-only coverage is retained
  separately in the raw evaluation.

Benchmark context: https://arxiv.org/abs/2511.20617
