use qsortrs::*;
use std::env;
pub fn main() {
    test_quickSort();
    println!("All tests passed successfully!");
}
